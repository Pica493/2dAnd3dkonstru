'use strict';
/* ---------- hero: frame animation from the concept sheets ---------- */
const HERO_H=104;
let HM=null,HS_W=1,HS_P=1;
function atlasCanvas(name){const m=HM.meta[name],c=mkCanvas(m[2],m[3]);c.getContext('2d').drawImage(IMG.hatlas,m[0],m[1],m[2],m[3],0,0,m[2],m[3]);return c}
function initHero(){
  HM=HMJSON;HS_W=HERO_H/HM.hh.w;HS_P=HERO_H/HM.hh.p;
  IMG.hero=atlasCanvas('p_idle');IMG.heroW=atlasCanvas('w_idle');
  const c=IMG.hero,h=mkCanvas(Math.round(c.width*.9),Math.round(c.height*.46)),g=h.getContext('2d');
  g.drawImage(c,c.width*.05,0,c.width*.9,c.height*.46,0,0,h.width,h.height);IMG.head=h;
}
const fsc=n=>n[0]==='w'?HS_W:HS_P;
function drawFrame(g,name,x,y,face,dx){
  const m=HM.meta[name],s=fsc(name);
  g.save();g.translate(x+(dx||0)*face,y);g.scale(face>0?1:-1,1);
  g.drawImage(IMG.hatlas,m[0],m[1],m[2],m[3],-m[4]*s,-m[5]*s,m[2]*s,m[3]*s);
  g.restore();
}
const WHIP_KF=[[0,'w_idle'],[.05,'w_draw'],[.13,'w_out'],[.2,'w_wind'],[.28,'w_strike'],[.37,'w_return'],[.44,'w_end'],[.5,'w_grab'],[.56,'w_appr'],[.62,'w_ready']];
function heroFrame(p){
  if(p.hurtT>.2)return'rig';
  if(p.whipOn){if(p.whipT>.66)return'rig';let n='w_idle';for(const [t,nm] of WHIP_KF)if(p.whipT>=t)n=nm;return n}
  if(p.throwT>.06)return'p_draw';
  if(p.weapon===1){
    if(inp.attack||p.aimHold>.2){if(p.shootT>.1)return'p_shot';return(p.aimT||0)<.1?'p_draw':'p_ready'}
    if(p.aimHold>0)return'p_hol';
  }
  return'rig';
}
function heroXF(p){
  const t=p.t,sp=Math.min(1,Math.abs(p.vx)/255);
  const xf={root:{x:0,y:0,sx:1,sy:1,r:0,rp:.55},body:{x:0,y:0,r:0,sx:1,sy:1},head:{x:0,y:0,r:0},legL:{r:0,y:0},legR:{r:0,y:0}};
  const R=xf.root,B=xf.body,Hd=xf.head,LL=xf.legL,LR=xf.legR;
  if(p.onGround){
    if(sp>.1){
      const ph=p.runPh,s=Math.sin(ph),c=Math.cos(ph);
      LL.r=-s*.5*sp;LR.r=s*.5*sp;LL.y=-Math.max(0,c)*4*sp;LR.y=-Math.max(0,-c)*4*sp;
      B.r=.03+.05*sp;B.y=-Math.abs(s)*3*sp;Hd.r=-B.r*.6+Math.sin(ph*2)*.015;Hd.y=-Math.abs(Math.sin(ph-.7))*1.5*sp;
    }else{const br=Math.sin(t*2.2);B.sy=1+br*.012;Hd.r=Math.sin(t*1.5)*.025;Hd.y=-br*1}
    R.sy=1-p.landSq;R.sx=1+p.landSq*.8;
  }else{
    if(p.vy<0){LL.r=-.6;LR.r=.32;LL.y=-4;B.r=.04;Hd.r=-.04}
    else{const w=Math.sin(t*12)*.04;LL.r=-.3+w;LR.r=.25-w;B.r=-.02;Hd.r=.05}
    R.sy=1+p.stretch*.45;R.sx=1/R.sy;
  }
  if(p.hurtT>0){const k=p.hurtT/.4;B.r-=.25*k;Hd.r-=.12*k}
  if(p.djT>0)R.r=(1-p.djT/.42)*Math.PI*2;
  return xf;
}
function muzzle(p){
  const m=HM.muz.p_ready,a=HM.meta.p_ready;
  return{x:p.x+p.face*((m[0]*.85-a[4])*HS_P+4),y:p.y-(a[5]-m[1]*.85)*HS_P}
}
function drawShieldBubble(p){}
function drawAlly(p){}
function drawWhip(){}
function drawRocket(q){}
function drawPose(g,name,cx,by,face,xf,a){
  g.globalAlpha=a;
  if(name==='rig'){
    const W0=P.weapon===0,rig=W0?RIG.heroW:RIG.hero,m=W0?HM.meta.w_idle:HM.meta.p_idle,s=W0?HS_W:HS_P;
    drawRig(g,rig,cx+(rig.w/2-m[4])*s*face,by,s,face,xf);
  }else drawFrame(g,name,cx,by,face,name==='w_strike'||name==='p_shot'?3:0);
  g.globalAlpha=1;
}
function drawPlayer(){
  const p=P;if(p.dead)return;
  const face=p.face>0?1:-1,xf=smoothXF(p,heroXF(p),22);
  const want=heroFrame(p);
  if(want!==p.fCur){p.fPrev=p.fCur||want;p.fCur=want;p.fMix=p.fPrev===want?1:0}
  p.fMix=Math.min(1,(p.fMix===undefined?1:p.fMix)+RDT/.04);
  const blink=p.inv>0&&mode==='play'&&((p.t*14)|0)%2;
  const alpha=blink?.4:1,flash=p.hurtT>.28?.85:0;
  drawShadow(p.x,p.y,44,1);
  if(Qe.glow){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.35+.15*Math.sin(p.t*3);ctx.drawImage(GL.yellow,p.x-34,p.y-HERO_H*.92,68,68);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
  const mx=p.fMix*p.fMix*(3-2*p.fMix);
  const fn=(g,cx,by)=>{
    if(mx<1&&p.fPrev&&p.fPrev!==p.fCur)drawPose(g,p.fPrev,cx,by,face,xf,1);
    drawPose(g,p.fCur,cx,by,face,xf,mx<1&&p.fPrev&&p.fPrev!==p.fCur?mx:1);
  };
  if(alpha<1||flash>0)drawBuffered(BUFS.s,p.x,p.y,alpha,flash,fn);else fn(ctx,p.x,p.y);
  if(p.jetT>0){
    ctx.globalCompositeOperation='lighter';const f=.6+.4*Math.random();ctx.globalAlpha=Math.min(1,p.jetT*3);
    ctx.drawImage(GL.orange,p.x-16,p.y-10,32,26*f+12);ctx.drawImage(GL.blue,p.x-9,p.y-8,18,16*f+8);
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  if(p.fCur==='w_strike'&&Qe.glow){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.45;ctx.drawImage(GL.green,p.x+face*150-24,p.y-70,48,48);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
}

