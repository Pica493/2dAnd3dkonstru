'use strict';

const SRC={
 "hatlas": "assets/images/hero/hero_atlas.png",
 "beetle": "assets/images/enemies/beetle.png",
 "fly": "assets/images/enemies/flytrap.png",
 "bg": "assets/images/backgrounds/city.jpg",
 "menu": "assets/images/ui/menu.jpg",
 "golem": "assets/images/enemies/golem_boss.png",
 "drone": "assets/images/enemies/drone.png",
 "rat": "assets/images/enemies/rat.png",
 "spider": "assets/images/enemies/spider.png",
 "spit": "assets/images/enemies/spitter.png",
 "bg2": "assets/images/backgrounds/metro.jpg",
 "icons": "assets/images/ui/icons.png",
 "bg6": "assets/images/backgrounds/arena.jpg"
};
const IMG={};

const W=960,H=540,GRAV=1900,GY=470;
const $=id=>document.getElementById(id);
const cv=$('cv'),ctx=cv.getContext('2d',{alpha:false});
const isTouch=('ontouchstart' in window)||(navigator.maxTouchPoints>0);
if(isTouch)document.body.classList.add('touch');
