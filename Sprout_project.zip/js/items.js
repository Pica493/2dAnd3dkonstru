'use strict';
/* ---------- items ---------- */
function updateItems(dt){
  const cx=P.x,cy=P.y-36,mr=100+35*G.up.mag;
  for(const o of LV.items){
    if(o.got)continue;
    o.ph+=dt*3;
    const dx=cx-o.x,dy=cy-(o.y),d=Math.hypot(dx,dy);
    if(o.t!=='heart'&&d<mr&&d>1){const s=240*dt;o.x+=dx/d*s;o.y+=dy/d*s}
    if(d<28){
      if(o.t==='heart'&&P.hp>=P.maxHp)continue;
      if(o.t==='kit'&&G.kits>=3)continue;
      o.got=true;
      if(o.t==='coin'){G.coins++;G.totalCoins++;G.lvCoins++;G.coinPop=1;G.score+=10;sfx('coin');burst(o.x,o.y,5,['#ffe45c','#fff'],90,.35,0,2.5,true)}
      else if(o.t==='orb'){P.en=Math.min(P.maxEn,P.en+30);G.orbs++;G.score+=5;sfx('orb');burst(o.x,o.y,8,['#8dff6a','#fff'],110,.45,0,3,true);ftext(o.x,o.y-20,L('+энергия'),'#9dff7a')}
      else if(o.t==='gem'){G.gems++;G.score+=25;sfx('gem');burst(o.x,o.y,12,['#7fd8ff','#fff'],140,.5,0,3,true);ftext(o.x,o.y-20,L('+кристалл'),'#9fd8ff')}
      else if(o.t==='kit'){G.kits++;G.score+=15;sfx('heal');burst(o.x,o.y,10,['#8dff6a','#fff'],120,.5,0,3,true);ftext(o.x,o.y-20,L('+аптечка'),'#9dff7a')}
      else{P.hp=Math.min(P.maxHp,P.hp+1);sfx('heal');burst(o.x,o.y,12,['#ff6a6a','#fff'],130,.5,0,3,true);ftext(o.x,o.y-20,L('+сердце'),'#ff9a9a')}
    }
  }
}

