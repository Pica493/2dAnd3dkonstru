'use strict';
/* ---------- living world ---------- */
function drawGear(cx,cy,r,rot,col){
  const n=12;ctx.fillStyle=col;ctx.beginPath();
  for(let i=0;i<n;i++){const a0=rot+i*Math.PI*2/n,a1=a0+Math.PI/n*.55,a2=a0+Math.PI/n;
    ctx.lineTo(cx+Math.cos(a0)*r,cy+Math.sin(a0)*r);ctx.lineTo(cx+Math.cos(a1)*r*1.14,cy+Math.sin(a1)*r*1.14);ctx.lineTo(cx+Math.cos(a2-.04)*r*1.14,cy+Math.sin(a2-.04)*r*1.14);ctx.lineTo(cx+Math.cos(a2)*r,cy+Math.sin(a2)*r)}
  ctx.closePath();ctx.fill();ctx.globalCompositeOperation='destination-out';ctx.beginPath();ctx.arc(cx,cy,r*.3,0,7);ctx.fill();ctx.globalCompositeOperation='source-over';
}
function drawLife(){
  const t=G.time,th=LV.theme;
  if(th==='green'||th==='glass'){
    ctx.globalAlpha=.2;
    for(let i=0;i<4;i++){const x=((i*330+t*(6+i*2.5)-cam*.05)%1400+1400)%1400-220;ctx.drawImage(GL.white,x,28+i*26,280,70)}
    ctx.globalAlpha=1;
    ctx.strokeStyle='rgba(28,38,48,.6)';ctx.lineWidth=1.8;ctx.beginPath();
    for(let i=0;i<5;i++){const bx=((t*(46+i*7)+i*260-cam*.12)%1200+1200)%1200-120,by=70+i*26+Math.sin(t*1.7+i)*9,w=Math.sin(t*9+i*2)*5;ctx.moveTo(bx-8,by-w);ctx.quadraticCurveTo(bx-3,by-2,bx,by);ctx.quadraticCurveTo(bx+3,by-2,bx+8,by-w)}
    ctx.stroke();
    if(th==='glass'&&Qe.glow){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.07;for(let i=0;i<5;i++){const x=((i*260+t*14-cam*.2)%1300+1300)%1300-200;ctx.drawImage(GL.white,x,300+Math.sin(t+i)*30,260,120)}ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
  }else if(th==='metro'){
    const ph=(t%24)/24;
    if(ph<.55){
      const x=W+80-(ph/.55)*(W+1500);ctx.fillStyle='rgba(8,14,16,.8)';
      for(let k=0;k<6;k++){const cx=x+k*240;if(cx>W||cx<-240)continue;ctx.fillRect(cx,246,226,66);ctx.fillRect(cx+226,270,14,10);
        for(let w=0;w<5;w++){ctx.fillStyle=((k*7+w)%4)?'rgba(255,190,100,.8)':'rgba(60,40,30,.6)';ctx.fillRect(cx+12+w*42,258,30,18)}ctx.fillStyle='rgba(8,14,16,.8)'}
      if(Qe.glow){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.06+.04*Math.sin(t*30);ctx.fillStyle='#ffb36a';ctx.fillRect(0,0,W,H);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
    }
  }else if(th==='swamp'){
    ctx.globalAlpha=.2;for(let i=0;i<4;i++){const x=((i*420-cam*.3+t*11)%1600+1600)%1600-340;ctx.drawImage(GL.mist,x,H-230+Math.sin(t*.4+i)*14,560,230)}ctx.globalAlpha=1;
    ctx.fillStyle='rgba(120,180,40,'+(.04+.03*Math.sin(t*.8))+')';ctx.fillRect(0,0,W,H);
  }else if(th==='core'){
    ctx.fillStyle='rgba(255,40,20,'+(.05+.045*Math.sin(t*1.6))+')';ctx.fillRect(0,0,W,H);
    for(let i=0;i<3;i++){const gx=((i*520+200-cam*.18)%1560+1560)%1560-260;drawGear(gx,230+i*40,120+i*20,t*(i%2?-.18:.2),'rgba(14,4,6,.6)')}
    ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.25+.15*Math.sin(t*2);ctx.strokeStyle='#ff4a2a';ctx.lineWidth=2;
    for(let i=0;i<5;i++){const x=((i*230-cam*.3)%1150+1150)%1150-100;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
}
function drawPit(p){
  const g=ctx.createLinearGradient(0,GY,0,H);g.addColorStop(0,'rgba(0,0,0,.05)');g.addColorStop(1,'rgba(0,0,0,.92)');
  const th=LV.theme,t=G.time;
  if(th==='metro'){
    ctx.fillStyle='#07181c';ctx.fillRect(p.x,GY+20,p.w,H-GY);
    ctx.fillStyle='rgba(110,190,200,.22)';for(let k=0;k<5;k++){const x=p.x+((k*53+t*18)%p.w);ctx.fillRect(x,GY+26+k*7,22,2)}
    ctx.fillStyle='#6b5a48';ctx.fillRect(p.x,GY+54,p.w,4);ctx.fillRect(p.x,GY+66,p.w,4);
    ctx.fillStyle='#3a2c20';for(let x=p.x+6;x<p.x+p.w;x+=26)ctx.fillRect(x,GY+58,14,8);
    ctx.fillStyle=g;ctx.fillRect(p.x,GY,p.w,H-GY);
  }else if(th==='swamp'){
    ctx.fillStyle='#0f2a10';ctx.fillRect(p.x,GY+14,p.w,H-GY);
    ctx.fillStyle='rgba(150,255,60,.28)';for(let k=0;k<6;k++){const x=p.x+((k*41+t*14)%p.w);ctx.fillRect(x,GY+20+k*6,20,2)}
    if(Qe.glow){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.3;ctx.fillStyle='#7aff3a';ctx.fillRect(p.x,GY+10,p.w,16);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
    ctx.fillStyle='rgba(180,255,120,.7)';for(let k=0;k<4;k++){const bx=p.x+((k*61+t*9)%p.w),by=GY+46-((t*30+k*18)%40);ctx.beginPath();ctx.arc(bx,by,2+k%3,0,7);ctx.fill()}
    ctx.fillStyle=g;ctx.fillRect(p.x,GY,p.w,H-GY);
  }else if(th==='core'){
    const gr=ctx.createLinearGradient(0,GY,0,H);gr.addColorStop(0,'#ff8a3a');gr.addColorStop(.4,'#c0300a');gr.addColorStop(1,'#300806');
    ctx.fillStyle=gr;ctx.fillRect(p.x,GY+16,p.w,H-GY);
    ctx.fillStyle='rgba(255,220,120,.5)';for(let k=0;k<5;k++){const x=p.x+((k*47+t*20)%p.w);ctx.fillRect(x,GY+22+k*6,26,3)}
    if(Qe.glow){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.4;ctx.drawImage(GL.orange,p.x-30,GY-40,p.w+60,90);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
  }else if(LV.arena){
    const gr=ctx.createLinearGradient(0,GY,0,H);gr.addColorStop(0,'#3fd0c8');gr.addColorStop(.5,'#1f9aa8');gr.addColorStop(1,'#0b4a5a');
    ctx.fillStyle=gr;ctx.fillRect(p.x,GY+14,p.w,H-GY);
    ctx.fillStyle='rgba(255,255,255,.35)';for(let k=0;k<6;k++){const x=p.x+((k*37+t*16)%p.w);ctx.fillRect(x,GY+20+k*7,18,2)}
    for(let k=0;k<3;k++){const lx=p.x+p.w*(k+.5)/3+Math.sin(t+k)*6;ctx.fillStyle='#2f8a4a';ctx.beginPath();ctx.ellipse(lx,GY+20,16,5,0,0,7);ctx.fill();ctx.fillStyle='#ff8ab8';ctx.beginPath();ctx.ellipse(lx,GY+15,6,6,0,0,7);ctx.fill()}
  }else{ctx.fillStyle=g;ctx.fillRect(p.x,GY,p.w,H-GY)}
}
function drawItems(c0,c1){
  const A=IMG.icons,M=ICM;
  for(const o of LV.items){
    if(o.got||o.x<c0||o.x>c1)continue;
    const by=Math.sin(o.ph)*3;
    if(o.t==='coin'){
      const sw=Math.max(.18,Math.abs(Math.cos(o.ph*.8))),m=M.coin;
      if(Qe.glow){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.5;ctx.drawImage(GL.yellow,o.x-17,o.y+by-17,34,34);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
      ctx.drawImage(A,m[0],m[1],m[2],m[3],o.x-10*sw,o.y+by-10,20*sw,20);
    }else{
      const nm=o.t==='orb'?'leaf':o.t==='gem'?'gem':o.t==='kit'?'medkit':'heart',m=M[nm],s=o.t==='kit'?28:o.t==='heart'?26:24;
      ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.55;ctx.drawImage(o.t==='orb'?GL.green:o.t==='gem'?GL.blue:o.t==='heart'?GL.red:GL.green,o.x-22,o.y+by-22,44,44);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
      ctx.drawImage(A,m[0],m[1],m[2],m[3],o.x-s/2,o.y+by-s/2,s,s);
    }
  }
}

