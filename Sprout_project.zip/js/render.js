'use strict';
/* ---------- rendering ---------- */
function strip(img,w,off,a,sh){
  const x0=((off%w)+w)%w,sw=Math.min(W,w-x0);
  ctx.globalAlpha=a;
  if(sh){ctx.save();ctx.transform(1,0,sh,1,0,0)}
  ctx.drawImage(img,x0,0,sw,H,0,0,sw,H);
  if(sw<W)ctx.drawImage(img,0,0,W-sw,H,sw,0,W-sw,H);
  if(sh)ctx.restore();
  ctx.globalAlpha=1;
}
function drawBG(){
  ctx.fillStyle=LV.sky;ctx.fillRect(0,0,W,H);
  const im=IMG[LV.bgKey||'bg'];
  if(im){
    const bh=H,bw=im.width*bh/im.height,off=cam*.22;
    for(let i=Math.floor(off/bw);i*bw-off<W;i++){
      const x=i*bw-off;
      if(i&1){ctx.save();ctx.translate(x+bw,0);ctx.scale(-1,1);ctx.drawImage(im,0,0,bw,bh);ctx.restore()}
      else ctx.drawImage(im,x,0,bw,bh);
    }
  }
  if(LV.theme==='dark'){
    ctx.fillStyle='rgba(6,16,14,.72)';ctx.fillRect(0,0,W,H);
    for(let i=-1;i<8;i++){
      const x=((i*260-cam*.5)%2080+2080)%2080-200;
      ctx.fillStyle='rgba(14,22,20,.92)';ctx.fillRect(x,0,46,H);
      ctx.fillStyle='rgba(60,40,30,.9)';ctx.fillRect(x-6,0,58,14);
      const fl=.6+.4*Math.sin(G.time*3+i);
      ctx.fillStyle='rgba(255,170,70,'+(.5*fl)+')';ctx.fillRect(x+10,34,26,6);
    }
  }else if(LV.theme==='glass'){
    ctx.fillStyle='rgba(150,220,255,.2)';ctx.fillRect(0,0,W,H);
    ctx.strokeStyle='rgba(255,255,255,.28)';ctx.lineWidth=2;ctx.beginPath();
    for(let i=-1;i<7;i++){const x=((i*220-cam*.35)%1540+1540)%1540-200;ctx.moveTo(x,0);ctx.lineTo(x+110,H);ctx.moveTo(x+110,0);ctx.lineTo(x,H)}
    ctx.moveTo(0,70);ctx.lineTo(W,70);ctx.moveTo(0,300);ctx.lineTo(W,300);ctx.stroke();
  }
  if(LV.theme==='metro'){ctx.fillStyle='rgba(6,14,14,.3)';ctx.fillRect(0,0,W,H)}
  if(LV.theme==='swamp'){ctx.fillStyle='rgba(14,30,10,.3)';ctx.fillRect(0,0,W,H)}else if(LV.theme==='core'){ctx.fillStyle='rgba(30,4,4,.25)';ctx.fillRect(0,0,W,H)}
  if(Qe.mid&&LV.mid){strip(LV.mid,1800,cam*.55,1);if(LV.vines)strip(LV.vines,1800,cam*.55,.9,Math.sin(G.time*.7)*.025)}
  drawLife()
  if(Qe.rays&&LV.theme!=='dark'){
    ctx.globalCompositeOperation='lighter';
    for(let k=0;k<4;k++){const x=((k*330-cam*.3+Math.sin(G.time*.3+k)*20)%1320+1320)%1320-260;ctx.globalAlpha=.8+.2*Math.sin(G.time*.6+k*2);ctx.drawImage(GL.ray,x,0)}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
}
function spr(img,cx,by,dw,dh,flip,rot,sx,sy){
  if(!img)return;
  ctx.save();ctx.translate(cx,by);if(rot)ctx.rotate(rot);ctx.scale((flip?-1:1)*(sx||1),sy||1);
  ctx.drawImage(img,-dw/2,-dh,dw,dh);ctx.restore();
}
function drawGate(){
  const gx=LV.world-190,gy=GY;
  if(gx+200<cam||gx-30>cam+W)return;
  ctx.save();
  for(const px of [gx-26,gx+120]){
    const g=ctx.createLinearGradient(px,0,px+30,0);g.addColorStop(0,'#5a3219');g.addColorStop(1,'#8a5530');
    ctx.fillStyle=g;ctx.fillRect(px,gy-230,30,230);
    ctx.fillStyle='#5aa62f';ctx.fillRect(px-2,gy-232,34,8);
    for(let k=0;k<6;k++)leaf(ctx,px+15,gy-210+k*34,16,5,k%2?.4:Math.PI-.4,'#79c943');
  }
  ctx.fillStyle='#6a3f20';ctx.fillRect(gx-26,gy-246,176,22);
  ctx.fillStyle='#5aa62f';ctx.fillRect(gx-28,gy-250,180,8);
  if(!G.open){
    ctx.strokeStyle='#3b7a22';ctx.lineWidth=5;ctx.beginPath();
    for(let k=0;k<7;k++){const x=gx+6+k*15;ctx.moveTo(x,gy-224);for(let y=0;y<224;y+=28)ctx.lineTo(x+Math.sin(y*.1+k+G.time*1.5)*7,gy-224+y+28)}
    ctx.stroke();
    ctx.fillStyle='#c0392b';for(let k=0;k<14;k++){const x=gx+4+(k%7)*15,y=gy-200+((k*37)%180);ctx.beginPath();ctx.moveTo(x-4,y);ctx.lineTo(x,y-9);ctx.lineTo(x+4,y);ctx.fill()}
  }else{
    ctx.globalCompositeOperation='lighter';
    const g=ctx.createLinearGradient(0,gy-224,0,gy);g.addColorStop(0,'rgba(160,255,120,.05)');g.addColorStop(1,'rgba(160,255,120,'+(.45+.15*Math.sin(G.time*3))+')');
    ctx.fillStyle=g;ctx.fillRect(gx+4,gy-224,112,224);
    ctx.globalCompositeOperation='source-over';
    ctx.fillStyle='#fffbd0';ctx.font='bold 34px Trebuchet MS,sans-serif';ctx.textAlign='center';ctx.fillText('→',gx+60,gy-100+Math.sin(G.time*5)*5);
  }
  if(LV.theme==='metro'){ctx.fillStyle='#0e2a22';rrect(ctx,gx-6,gy-290,140,34,6);ctx.fill();ctx.strokeStyle='#8fd14f';ctx.lineWidth=2;ctx.stroke();ctx.fillStyle='#d8f5b0';ctx.font='bold 20px Trebuchet MS,sans-serif';ctx.textAlign='center';ctx.fillText(L('Выход')+' →',gx+64,gy-266)}
  ctx.restore();
}
function drawWorld(){
  const c0=cam-80,c1=cam+W+80;
  for(const p of LV.pits){if(p.x+p.w<c0||p.x>c1)continue;drawPit(p)}
  drawProps(c0,c1);
  for(const s of LV.solids){
    if(s.x+s.w<c0-30||s.x>c1+30)continue;
    if(Qe.shadows&&!s.ground){ctx.globalAlpha=.22;ctx.drawImage(GL.shadow,s.x-14,s.y+24,s.w+28,30);ctx.globalAlpha=1}
    const a=s.art;ctx.drawImage(a.c,s.x-a.pad,s.y-a.top,a.cw,a.ch);
  }
  drawGate();
  drawItems(c0,c1);
  drawEnemies(c0,c1);
  for(const q of proj){
    if(q.k==='rocket'){drawRocket(q);continue}
    if(q.k==='abolt'){ctx.globalCompositeOperation='lighter';ctx.drawImage(GL.blue,q.x-14,q.y-14,28,28);ctx.globalCompositeOperation='source-over';ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(q.x,q.y,3,0,7);ctx.fill();continue}
    if(q.k==='seed'){
      ctx.globalCompositeOperation='lighter';ctx.drawImage(GL.green,q.x-14,q.y-14,28,28);ctx.globalCompositeOperation='source-over';
      ctx.fillStyle='#fff7b0';ctx.beginPath();ctx.ellipse(q.x,q.y,5,3,0,0,7);ctx.fill();
    }else{
      ctx.save();ctx.translate(q.x,q.y);ctx.rotate(q.rot);
      ctx.fillStyle='#3b9fb8';ctx.beginPath();ctx.arc(0,2,9,0,7);ctx.fill();
      ctx.fillStyle='#8be6ff';ctx.beginPath();ctx.arc(-3,0,3.5,0,7);ctx.fill();
      ctx.fillStyle='#6a4a28';ctx.fillRect(-3,-12,6,6);
      ctx.restore();
      ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.5;ctx.drawImage(GL.green,q.x-18,q.y-18,36,36);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
    }
  }
  drawPlayer();drawAlly(P);
  for(const d of deb){
    ctx.save();ctx.translate(d.x,d.y);ctx.rotate(d.r);ctx.scale(d.flip,1);ctx.globalAlpha=Math.min(1,d.life*1.6);
    ctx.drawImage(d.c,-d.w/2,-d.h/2,d.w,d.h);ctx.restore();
  }
  ctx.globalAlpha=1;
  let addMode=false;
  for(const p of parts){
    const a=clamp(p.life/p.max,0,1);
    if(p.leaf){if(addMode){ctx.globalCompositeOperation='source-over';addMode=false}ctx.globalAlpha=a;leaf(ctx,p.x,p.y,p.s*2.6,p.s,p.rot,p.c);continue}
    if(p.add!==addMode){ctx.globalCompositeOperation=p.add?'lighter':'source-over';addMode=p.add}
    ctx.globalAlpha=a;ctx.fillStyle=p.c;ctx.beginPath();ctx.arc(p.x,p.y,p.s*(.4+.6*a),0,7);ctx.fill();
  }
  ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  for(const f of fx){
    const u=f.t/f.life;ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1-u;
    ctx.strokeStyle=f.c;ctx.lineWidth=8*(1-u)+1;ctx.beginPath();ctx.arc(f.x,f.y,f.r+(f.max-f.r)*(1-Math.pow(1-u,2)),0,7);ctx.stroke();
  }
  ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  const nf=Math.min(flies.length,Qe.flies);
  if(nf>0){
    ctx.globalCompositeOperation='lighter';
    for(let i=0;i<nf;i++){
      const f=flies[i];if(f.x<c0||f.x>c1)continue;
      const x=f.x+Math.sin(G.time*f.sp+f.ph)*20,y=f.y+Math.cos(G.time*f.sp*.8+f.ph)*14;
      ctx.globalAlpha=.35+.65*Math.abs(Math.sin(G.time*f.sp*1.5+f.ph));ctx.drawImage(GL.yellow,x-7,y-7,14,14);
    }
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  ctx.textAlign='center';
  for(const t of texts){
    ctx.font=t.big?'bold 22px Trebuchet MS,sans-serif':'bold 17px Trebuchet MS,sans-serif';
    ctx.globalAlpha=clamp(1.1-t.t,0,1);ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillText(t.s,t.x+1,t.y+1);ctx.fillStyle=t.col;ctx.fillText(t.s,t.x,t.y);
  }
  ctx.globalAlpha=1;
}
function drawDarkness(dk,dkc){
  const g=dk;
  g.globalCompositeOperation='source-over';g.globalAlpha=1;g.clearRect(0,0,480,270);
  g.fillStyle='rgba(2,6,6,.93)';g.fillRect(0,0,480,270);
  g.globalCompositeOperation='destination-out';
  const L=(x,y,r,a)=>{const X=(x-cam)/2,Y=y/2,R=r/2;if(X<-R||X>480+R)return;g.globalAlpha=a;g.drawImage(GL.white,X-R,Y-R,R*2,R*2)};
  const fl=1+Math.sin(G.time*7)*.03;
  L(P.x,P.y-80,330*fl,1);L(P.x,P.y-80,200*fl,1);
  for(const o of LV.items){if(!o.got&&(o.t==='orb'||o.t==='heart'))L(o.x,o.y,80,.9)}
  for(const q of proj)L(q.x,q.y,120,.95);
  for(const f of fx)L(f.x,f.y,260,.9);
  if(P.whipOn)L(P.x+P.face*80,P.y-52,130,.8);
  if(LV.props)for(const o of LV.props)if(o.t==='lamp')L(o.x,o.y+20,300,.95);
  for(const h of haz)if(h.k==='fire'||h.k==='puddle')L(h.x,h.y-10,150,.8);
  for(const q of eproj)L(q.x,q.y,130,.9);
  for(const e of enemies){if(e.boss)L(e.x,e.y-e.dh*.6,400,.9);if(e.type==='drone')L(e.x+e.face*24,e.y-30,110,.8);if(e.beam)for(let k=1;k<8;k++)L(e.beam.x+e.beam.dx*k*110,e.beam.y+e.beam.dy*k*110,170,.9)}
  g.globalAlpha=1;g.globalCompositeOperation='source-over';
  ctx.drawImage(dkc,0,0,W,H);
  for(const e of enemies){const x=e.x-cam;if(x<-90||x>W+90||e.spawnT>0||e.boss)continue;ctx.save();ctx.translate(-cam,0);eyeGlows(e,.95,1.2);ctx.restore()}
}

function drawBanner(){
  const b=G.banner;if(!b)return;
  const e=Math.min(1,b.t/.45),ease=1-Math.pow(1-e,3),a=b.t>2.1?Math.max(0,(2.6-b.t)/.5):Math.min(1,b.t/.25),s=1+(1-ease)*.45;
  ctx.save();ctx.globalAlpha=a;ctx.translate(W/2,150);ctx.scale(s,s);ctx.textAlign='center';
  ctx.font='bold 54px Trebuchet MS,sans-serif';ctx.lineWidth=8;ctx.strokeStyle='#3a2110';ctx.lineJoin='round';
  ctx.strokeText(b.title,0,0);
  const g=ctx.createLinearGradient(0,-40,0,6);g.addColorStop(0,'#fff6a0');g.addColorStop(1,'#e8b820');ctx.fillStyle=g;ctx.fillText(b.title,0,0);
  if(b.sub){ctx.font='bold 22px Trebuchet MS,sans-serif';ctx.lineWidth=5;ctx.strokeText(b.sub,0,34);ctx.fillStyle='#e9f7c8';ctx.fillText(b.sub,0,34)}
  ctx.restore();
}
const dkc=document.createElement('canvas');dkc.width=480;dkc.height=270;const dkg=dkc.getContext('2d');
function render(){
  ctx.setTransform(K,0,0,K,0,0);
  let sx=0,sy=0;
  if(G.trauma>0){const tr=G.trauma*G.trauma*14;sx=(Math.sin(G.time*47)+Math.sin(G.time*31+1))*.5*tr;sy=(Math.sin(G.time*53+2)+Math.sin(G.time*29))*.5*tr}
  ctx.save();ctx.translate(sx,sy);
  drawBG();
  ctx.save();ctx.translate(-Math.round(cam),0);drawWorld();ctx.restore();
  if(Qe.mist){
    for(let i=0;i<4;i++){const x=((i*310-cam*.8+G.time*14)%1400+1400)%1400-260;ctx.globalAlpha=.13;ctx.drawImage(GL.mist,x,H-120+Math.sin(G.time*.5+i)*10,440,160)}
    ctx.globalAlpha=1;
  }
  if(Qe.fg&&LV.fg)strip(LV.fg,2400,cam*1.4,.92);
  const nd=Math.min(drift.length,Math.round(Qe.leaves||0));
  for(let i=0;i<nd;i++){const d=drift[i];leaf(ctx,d.x,d.y,d.s*2.2,d.s,d.r,d.c)}
  ctx.drawImage(GL.vig,0,0);
  if(LV.dark)drawDarkness(dkg,dkc);
  ctx.restore();
  drawHUD();drawBanner();
  if(G.fade>0){ctx.globalAlpha=Math.min(1,G.fade);ctx.fillStyle='#04100a';ctx.fillRect(0,0,W,H);ctx.globalAlpha=1}
}

