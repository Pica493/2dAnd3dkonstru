'use strict';
/* ---------- input ---------- */
addEventListener('keydown',e=>{
  initAudio();
  if(rebind){
    e.preventDefault();
    if(e.code!=='Escape'){CFG.binds[rebind.a]=[e.code];saveCfg()}
    rebind=null;settingsPanel('ctl');return;
  }
  const gk=[].concat.apply([],Object.keys(CFG.binds).map(k=>CFG.binds[k]));
  if(mode!=='menu'&&(gk.indexOf(e.code)>=0||e.code==='Space'))e.preventDefault();
  if(e.repeat)return;
  keys[e.code]=true;
  const b=CFG.binds;
  if(mode==='play'){
    for(let i=0;i<3;i++)if(b['w'+(i+1)].includes(e.code))setWeapon(i);
    if(b.next.includes(e.code))nextWeapon(1);
    for(const id of ['dash','med','nova','shield','ally'])if(b[id].includes(e.code))useAbility(id);
    if(b.pause.includes(e.code))pauseGame();
  }else if(mode==='paused'&&b.pause.includes(e.code))resume();
});
addEventListener('keyup',e=>{keys[e.code]=false});
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;if(mode==='play'&&CFG.autopause)pauseGame()});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&mode==='play'&&CFG.autopause)pauseGame()});
function readInput(){
  inp.left=down('left')||!!tch.left;inp.right=down('right')||!!tch.right;
  const jump=down('jump')||!!tch.jump;inp.jump=jump;
  inp.attack=down('attack')||!!tch.attack||!!keys.Mouse;
  inp.jumpPressed=jump&&!jumpPrev;jumpPrev=jump;
}
document.querySelectorAll('#touch .tb').forEach(el=>{
  const k=el.dataset.k;
  const dn=e=>{e.preventDefault();initAudio();try{el.setPointerCapture(e.pointerId)}catch(_){}
    if(k==='cycle'){if(P&&mode==='play')nextWeapon(1)}else if(k==='dash'){useAbility('dash')}else tch[k]=1;el.classList.add('on')};
  const up=e=>{e.preventDefault();if(k!=='cycle'&&k!=='dash')tch[k]=0;el.classList.remove('on')};
  el.addEventListener('pointerdown',dn);el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);el.addEventListener('lostpointercapture',up);
});
cv.addEventListener('pointerdown',e=>{
  initAudio();
  const r=cv.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*W,y=(e.clientY-r.top)/r.height*H;
  if(mode==='play')for(const h of HUDHIT){if(Math.hypot(x-h.x,y-h.y)<h.r){h.fn();return}}
  if(!isTouch&&e.button===0)keys.Mouse=true;
});
addEventListener('pointerup',()=>{keys.Mouse=false});
cv.addEventListener('contextmenu',e=>e.preventDefault());
$('pauseBtn').addEventListener('click',()=>{initAudio();pauseGame()});
document.addEventListener('gesturestart',e=>e.preventDefault());

/* ---------- layout & loop ---------- */
function layout(){
  const vw=innerWidth,vh=innerHeight;
  const mw=Math.min(vw,vh*2.2222),mh=mw/2.2222,m=$('menu');
  m.style.width=mw+'px';m.style.height=mh+'px';m.style.setProperty('--fs',Math.round(mw*.0195)+'px');
  const sc=Math.min(vw/W,vh/H),cw=Math.floor(W*sc),ch=Math.floor(H*sc);
  cv.style.width=cw+'px';cv.style.height=ch+'px';
  const pw=Math.max(480,Math.round(cw*(Qe.dpr||1)));
  if(cv.width!==pw){cv.width=pw;cv.height=Math.round(pw*H/W)}
  const nk=cv.width/W;
  if(nk!==K||!BUFS){K=nk;BUFS={s:mkBuf(170,190),l:mkBuf(340,260),xl:mkBuf(470,430)}}
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality=(Qe.tier==='low')?'low':'high';
}
addEventListener('resize',layout);
let last=0,fpsS=60,ftA=0,ftN=0,warm=0;
function loop(ts){
  requestAnimationFrame(loop);
  if(!last)last=ts;
  let d=(ts-last)/1000;last=ts;if(d<=0)return;if(d>.1)d=.1;
  fpsS+=(1/d-fpsS)*.05;RDT=Math.min(d,.05);
  if(mode==='menu'||!LV)return;
  if(mode==='play'&&isTouch&&innerHeight>innerWidth)pauseGame();
  if(mode==='play'){
    if(CFG.quality==='auto'){
      warm+=d;
      if(warm>3){ftA+=d;ftN++;if(ftN>=90){const avg=ftA/ftN;ftA=0;ftN=0;if(avg>.03&&autoTier!=='low'){autoTier=autoTier==='high'?'med':'low';applyQuality();toast(L('Графика снижена для плавности'));warm=0}}}
    }
    let dt=d;
    if(G.hitstop>0){G.hitstop-=d;dt=d*.04}else if(G.slow>0){G.slow-=d;dt=d*.4}
    readInput();
    const n=dt>1/45?2:1;
    for(let i=0;i<n;i++){update(dt/n);inp.jumpPressed=false}
  }else if(mode==='over'){
    G.overT+=d;G.time+=d;updateFX(d);
    if(G.overT>1.1&&$('panel').style.display!=='flex')showOver();
  }
  render();
}
function buildMenu(){
  const m=$('menu');m.style.backgroundImage='url('+SRC.menu+')';
  const spec=[[7.2,42.6,24.6,10.3,levelSelect],[6.95,54.1,26,9.8,()=>settingsPanel('audio',hidePanel)],[7.5,65.6,27.5,9.8,()=>collectionPanel(0)],[7.5,76.9,29.7,9.8,exitPanel]];
  spec.forEach((s,i)=>{
    const b=document.createElement('button');b.className='hot';
    b.style.cssText='left:'+s[0]+'%;top:'+s[1]+'%;width:'+s[2]+'%;height:'+s[3]+'%';
    b.appendChild(document.createElement('span'));
    b.addEventListener('click',()=>{initAudio();sfx('click');s[4]()});
    b.addEventListener('mouseenter',()=>sfx('swap'));
    m.appendChild(b);
  });
  $('langBtn').onclick=()=>{CFG.lang=CFG.lang==='ru'?'en':'ru';saveCfg();initAudio();sfx('click');applyLang()};
  applyLang();
}
function loadAll(){
  return Promise.all(Object.keys(SRC).map(k=>new Promise(res=>{const im=new Image();im.onload=()=>{IMG[k]=im;res()};im.onerror=()=>res();im.src=SRC[k]})));
}
addEventListener('blur',audioSuspend);addEventListener('focus',audioResume);addEventListener('pagehide',audioSuspend);addEventListener('pageshow',audioResume);
document.addEventListener('visibilitychange',()=>{document.hidden?audioSuspend():audioResume()});
document.addEventListener('freeze',audioSuspend);document.addEventListener('resume',audioResume);
loadCfg();loadProg();
loadAll().then(()=>{initGfx();buildMenu();applyQuality();applyTouch();requestAnimationFrame(loop)});
window.__sprout={get cam(){return cam},get LVx(){return LV},useAbility,G,get AC(){return AC},startLevel,spawnEnemy,AI,haz,go,render,applyQuality,G,CFG,get P(){return P},get enemies(){return enemies},get LV(){return LV},keys,get mode(){return mode},get Qe(){return Qe}};

