'use strict';
/* ---------- settings ---------- */
const DEFBIND={left:['ArrowLeft','KeyA'],right:['ArrowRight','KeyD'],jump:['Space','ArrowUp','KeyW'],attack:['KeyJ','KeyX','KeyZ'],w1:['Digit1'],w2:['Digit2'],w3:['Digit3'],next:['KeyQ'],pause:['Escape','KeyP'],dash:['ShiftLeft','KeyL'],med:['KeyH'],nova:['KeyE'],shield:['KeyR'],ally:['KeyF'],w4:['Digit4']};
const DEF={lang:((navigator.language||'ru').toLowerCase().indexOf('ru')===0?'ru':'en'),master:85,music:55,sfx:80,amb:50,quality:'auto',res:100,part:100,shake:100,rays:true,flies:true,fg:true,shadows:true,glow:true,mist:true,flash:true,fps:false,diff:1,dmgnum:true,hints:true,autopause:true,touchSize:100,touchOp:60,lefty:false,vibr:true};
let CFG=Object.assign({},DEF,{binds:JSON.parse(JSON.stringify(DEFBIND))});
const mem={};
const store={get(k){try{return localStorage.getItem(k)}catch(e){return mem[k]||null}},set(k,v){try{localStorage.setItem(k,v)}catch(e){mem[k]=v}}};
function loadCfg(){try{const s=JSON.parse(store.get('sprout.cfg')||'null');if(s){for(const k in DEF)if(k in s&&typeof s[k]===typeof DEF[k])CFG[k]=s[k];if(s.binds)for(const a in DEFBIND)if(Array.isArray(s.binds[a])&&s.binds[a].length)CFG.binds[a]=s.binds[a]}}catch(e){}}
function saveCfg(){store.set('sprout.cfg',JSON.stringify(CFG))}
function toast(s){const t=$('toast');t.textContent=s;t.style.opacity=1;clearTimeout(toast.h);toast.h=setTimeout(()=>{t.style.opacity=0},2200)}
function vib(ms){if(CFG.vibr&&navigator.vibrate){try{navigator.vibrate(ms)}catch(e){}}}

