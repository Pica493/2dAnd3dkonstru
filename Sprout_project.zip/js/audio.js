'use strict';
/* ---------- audio engine ---------- */
let AC=null;const A={v:0};
function mtof(m){return 440*Math.pow(2,(m-69)/12)}
function initAudio(){
  if(AC){if(AC.state==='suspended')AC.resume();return}
  try{AC=new (window.AudioContext||window.webkitAudioContext)()}catch(e){AC=null;return}
  A.master=AC.createGain();A.comp=AC.createDynamicsCompressor();A.master.connect(A.comp);A.comp.connect(AC.destination);
  A.sfx=AC.createGain();A.mus=AC.createGain();A.amb=AC.createGain();
  A.musF=AC.createBiquadFilter();A.musF.type='lowpass';A.musF.frequency.value=18000;
  A.mus.connect(A.musF);A.musF.connect(A.master);A.sfx.connect(A.master);A.amb.connect(A.master);
  const n=Math.floor(AC.sampleRate*1.9),b=AC.createBuffer(2,n,AC.sampleRate);
  for(let c=0;c<2;c++){const d=b.getChannelData(c);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2.8)}
  A.verb=AC.createConvolver();A.verb.buffer=b;A.verbG=AC.createGain();A.verbG.gain.value=.4;A.verb.connect(A.verbG);A.verbG.connect(A.master);
  A.sM=AC.createGain();A.sM.gain.value=.55;A.mus.connect(A.sM);A.sM.connect(A.verb);
  A.sS=AC.createGain();A.sS.gain.value=.2;A.sfx.connect(A.sS);A.sS.connect(A.verb);
  const nl=AC.sampleRate*2,nb=AC.createBuffer(1,nl,AC.sampleRate),nd=nb.getChannelData(0);
  for(let i=0;i<nl;i++)nd[i]=Math.random()*2-1;A.nb=nb;
  applyVolumes();
  if(mode==='menu')musicStart(0);
}
function applyVolumes(){
  if(!AC)return;const t=AC.currentTime;
  A.master.gain.setTargetAtTime(CFG.master/100,t,.05);A.sfx.gain.setTargetAtTime(CFG.sfx/100,t,.05);
  A.mus.gain.setTargetAtTime(CFG.music/100*.9,t,.05);A.amb.gain.setTargetAtTime(CFG.amb/100,t,.05);
}
function muffle(on){if(AC)A.musF.frequency.setTargetAtTime(on?420:18000,AC.currentTime,.08)}
function tone(o){
  if(!AC||AC.state!=='running'||A.v>44)return;
  const t=o.at!==undefined?o.at:AC.currentTime+(o.delay||0);
  const osc=AC.createOscillator(),g=AC.createGain();
  osc.type=o.type||'sine';osc.frequency.setValueAtTime(o.f,t);
  if(o.f2)osc.frequency.exponentialRampToValueAtTime(Math.max(20,o.f2),t+o.dur);
  const a=o.a||.005;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(o.vol||.1,t+a);g.gain.exponentialRampToValueAtTime(.0001,t+o.dur);
  let n=osc;if(o.lp){const f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=o.lp;osc.connect(f);n=f}
  n.connect(g);g.connect(o.bus||A.sfx);osc.start(t);osc.stop(t+o.dur+.05);A.v++;osc.onended=()=>{A.v--};
}
function nz(o){
  if(!AC||AC.state!=='running'||A.v>44)return;
  const t=o.at!==undefined?o.at:AC.currentTime+(o.delay||0);
  const s=AC.createBufferSource();s.buffer=A.nb;s.loop=true;
  const f=AC.createBiquadFilter();f.type=o.type||'bandpass';f.frequency.setValueAtTime(o.f||1000,t);
  if(o.f2)f.frequency.exponentialRampToValueAtTime(o.f2,t+o.dur);f.Q.value=o.q||1;
  const g=AC.createGain(),a=o.a||.004;g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(o.vol||.1,t+a);g.gain.exponentialRampToValueAtTime(.0001,t+o.dur);
  s.connect(f);f.connect(g);g.connect(o.bus||A.sfx);s.start(t,Math.random()*1.5);s.stop(t+o.dur+.05);A.v++;s.onended=()=>{A.v--};
}
const SFX={
  jump:()=>{tone({f:300,f2:660,dur:.17,type:'triangle',vol:.12});nz({dur:.09,vol:.05,type:'highpass',f:2600})},
  dj:()=>{nz({dur:.38,vol:.17,f:500,f2:3200,q:.8});tone({f:420,f2:980,dur:.22,vol:.09})},
  land:(v)=>{nz({dur:.13,vol:.07+(v||0)*.12,type:'lowpass',f:800,f2:180});tone({f:120,f2:55,dur:.13,vol:.1+(v||0)*.1})},
  step:()=>{nz({dur:.05,vol:.045+Math.random()*.02,f:LV&&LV.theme==='glass'?3400:700+Math.random()*600,q:1.3})},
  whip:()=>{nz({dur:.24,vol:.17,f:1100,f2:5400,q:1.3});tone({f:760,f2:240,dur:.16,type:'sawtooth',vol:.04,lp:2200})},
  whiphit:()=>{nz({dur:.1,vol:.2,f:1800,q:1});tone({f:200,f2:90,dur:.12,type:'square',vol:.08,lp:1500})},
  shoot:()=>{tone({f:980,f2:240,dur:.14,type:'square',vol:.055,lp:3200});nz({dur:.06,vol:.07,type:'highpass',f:3200})},
  seedhit:()=>{tone({f:520,f2:200,dur:.1,type:'triangle',vol:.09});nz({dur:.05,vol:.08,f:2600})},
  throw:()=>{nz({dur:.3,vol:.12,f:400,f2:1600,q:.8});tone({f:180,f2:360,dur:.2,type:'triangle',vol:.06})},
  boom:()=>{nz({dur:.95,vol:.55,type:'lowpass',f:2600,f2:70,q:.7});tone({f:130,f2:32,dur:.7,vol:.4})},
  hit:()=>{tone({f:240,f2:100,dur:.1,type:'square',vol:.07,lp:2000});nz({dur:.07,vol:.1,f:1700,q:1.2})},
  hitfly:()=>{tone({f:300,f2:110,dur:.16,vol:.12});nz({dur:.12,vol:.09,type:'lowpass',f:1400,f2:300})},
  kill:()=>{tone({f:330,f2:700,dur:.12,type:'square',vol:.05,lp:3000});tone({f:520,f2:1040,dur:.16,type:'square',vol:.04,lp:3000,delay:.08});nz({dur:.25,vol:.12,type:'lowpass',f:3000,f2:300})},
  killfly:()=>{tone({f:220,f2:60,dur:.35,type:'sawtooth',vol:.09,lp:900});nz({dur:.3,vol:.12,type:'lowpass',f:1800,f2:200})},
  roar:()=>{tone({f:110,f2:48,dur:1.1,type:'sawtooth',vol:.2,lp:700,a:.1});tone({f:97,f2:41,dur:1.1,type:'square',vol:.1,lp:500,a:.1});nz({dur:1,vol:.12,type:'lowpass',f:900,f2:150})},
  charge:()=>{tone({f:200,f2:800,dur:.5,type:'sawtooth',vol:.07,lp:1500,a:.2})},
  spawn:()=>{nz({dur:.35,vol:.1,f:700,f2:300,q:.7});tone({f:150,f2:300,dur:.3,type:'triangle',vol:.06})},
  hurt:()=>{tone({f:280,f2:80,dur:.34,type:'sawtooth',vol:.14,lp:1800});nz({dur:.15,vol:.14,f:900,q:.8})},
  pit:()=>{tone({f:700,f2:70,dur:.6,type:'triangle',vol:.12})},
  coin:()=>{const k=1+Math.random()*.06;tone({f:988*k,dur:.1,type:'square',vol:.04,lp:4000});tone({f:1480*k,dur:.2,type:'square',vol:.04,lp:4000,delay:.07})},
  orb:()=>{tone({f:520,f2:1300,dur:.3,vol:.1});tone({f:780,f2:1950,dur:.3,vol:.05,delay:.05})},
  heal:()=>{[440,554,659,880].forEach((f,i)=>tone({f,dur:.3,vol:.09,delay:i*.09}))},
  wave:()=>{tone({f:196,dur:.5,type:'sawtooth',vol:.09,lp:900,a:.05});tone({f:294,dur:.5,type:'sawtooth',vol:.07,lp:900,a:.05,delay:.18});tone({f:392,dur:.7,type:'sawtooth',vol:.07,lp:1100,a:.05,delay:.36})},
  clear:()=>{[523,659,784].forEach((f,i)=>tone({f,dur:.35,type:'triangle',vol:.09,delay:i*.1}))},
  open:()=>{[392,494,587,784,988].forEach((f,i)=>tone({f,dur:.5,type:'triangle',vol:.09,delay:i*.12}));nz({dur:1,vol:.12,type:'lowpass',f:300,f2:80})},
  empty:()=>{tone({f:130,dur:.08,type:'square',vol:.05,lp:800})},
  swap:()=>{tone({f:660,dur:.06,type:'square',vol:.04,lp:2500});tone({f:880,dur:.08,type:'square',vol:.04,lp:2500,delay:.05})},
  click:()=>{tone({f:520,f2:380,dur:.07,type:'triangle',vol:.08})},
  win:()=>{[523,659,784,1047,1319].forEach((f,i)=>tone({f,dur:.5,type:'triangle',vol:.1,delay:i*.14}))},
  lose:()=>{[330,262,196,130].forEach((f,i)=>tone({f,dur:.5,type:'sawtooth',vol:.09,lp:1200,delay:i*.22}))},
  pause:()=>{tone({f:400,f2:250,dur:.12,type:'triangle',vol:.07})},
  dash:()=>{nz({dur:.25,vol:.16,f:600,f2:3200,q:.7});tone({f:240,f2:620,dur:.18,type:'sawtooth',vol:.05,lp:1800})},
  shield:()=>{tone({f:520,f2:900,dur:.3,vol:.08});tone({f:780,f2:1300,dur:.3,vol:.05,delay:.05})},
  nova:()=>{nz({dur:.7,vol:.2,f:5000,f2:600,q:.5});tone({f:900,f2:200,dur:.6,vol:.12});[1200,1600,2000].forEach((f,i)=>tone({f,dur:.4,vol:.05,delay:i*.06}))},
  gem:()=>{tone({f:1300,dur:.25,vol:.08});tone({f:1950,dur:.35,vol:.06,delay:.06});tone({f:2600,dur:.4,vol:.04,delay:.12})},
  rocket:()=>{nz({dur:.5,vol:.22,type:'lowpass',f:2400,f2:300});tone({f:140,f2:60,dur:.4,type:'sawtooth',vol:.12,lp:900})},
  hop:()=>{tone({f:260,f2:480,dur:.12,type:'triangle',vol:.06});nz({dur:.05,vol:.05,f:900})},
  sweep:()=>{nz({dur:.3,vol:.2,f:500,f2:2400,q:.7});tone({f:150,f2:90,dur:.25,type:'sawtooth',vol:.07,lp:900})},
  tongue:()=>{tone({f:500,f2:1500,dur:.22,type:'sawtooth',vol:.06,lp:3000});nz({dur:.2,vol:.1,f:2000,f2:900})},
  droneCharge:()=>{tone({f:300,f2:1300,dur:.55,type:'sawtooth',vol:.05,lp:2600,a:.2})},
  bolt:()=>{tone({f:1200,f2:300,dur:.18,type:'square',vol:.06,lp:3500});nz({dur:.08,vol:.08,type:'highpass',f:3000})},
  alarm:()=>{[0,.18,.36,.54].forEach(d=>tone({f:d%.36?900:1200,dur:.14,type:'square',vol:.05,lp:3000,delay:d}))},
  pounce:()=>{nz({dur:.25,vol:.12,f:900,f2:2600});tone({f:400,f2:200,dur:.2,type:'sawtooth',vol:.06,lp:1500})},
  squeak:()=>{tone({f:1800,f2:2600,dur:.1,type:'square',vol:.04,lp:5000});tone({f:2200,f2:1500,dur:.1,type:'square',vol:.04,lp:5000,delay:.09})},
  stab:()=>{nz({dur:.14,vol:.18,f:2200,f2:600});tone({f:300,f2:120,dur:.14,type:'square',vol:.08,lp:1500})},
  spit:()=>{nz({dur:.25,vol:.15,type:'lowpass',f:1800,f2:300});tone({f:160,f2:80,dur:.25,type:'sawtooth',vol:.08,lp:700})},
  splash:()=>{nz({dur:.3,vol:.18,f:1200,f2:400,q:.6});tone({f:300,f2:120,dur:.18,vol:.07})},
  thud:()=>{tone({f:90,f2:40,dur:.22,vol:.28});nz({dur:.14,vol:.14,type:'lowpass',f:500,f2:120})},
  slam:()=>{tone({f:80,f2:28,dur:.6,vol:.4});nz({dur:.6,vol:.4,type:'lowpass',f:1400,f2:80});tone({f:200,f2:60,dur:.3,type:'sawtooth',vol:.08,lp:800})},
  beamCharge:()=>{tone({f:120,f2:900,dur:1.0,type:'sawtooth',vol:.08,lp:2400,a:.5});tone({f:240,f2:1800,dur:1.0,type:'sine',vol:.05,a:.6})},
  beam:()=>{tone({f:90,dur:1.4,type:'sawtooth',vol:.14,lp:600,a:.1});tone({f:540,f2:480,dur:1.4,type:'square',vol:.04,lp:1800,a:.1});nz({dur:1.4,vol:.16,f:3000,q:.5,a:.1})},
  bombLaunch:()=>{tone({f:200,f2:700,dur:.25,type:'triangle',vol:.08});nz({dur:.15,vol:.08,f:700,f2:2000})},
  bombBoom:()=>{nz({dur:.5,vol:.35,type:'lowpass',f:2000,f2:100});tone({f:100,f2:35,dur:.4,vol:.28})},
  rootCall:()=>{tone({f:70,f2:50,dur:.8,type:'sawtooth',vol:.12,lp:300})},
  rootErupt:()=>{nz({dur:.2,vol:.16,type:'lowpass',f:900,f2:200});tone({f:130,f2:60,dur:.15,type:'square',vol:.07,lp:600})},
  summon:()=>{[392,494,587,740,988].forEach((f,i)=>tone({f,dur:.5,type:'sine',vol:.08,delay:i*.07}));nz({dur:.8,vol:.1,f:500,f2:3000})},
  crumble:()=>{nz({dur:.4,vol:.22,type:'lowpass',f:1500,f2:150});tone({f:70+Math.random()*30,f2:40,dur:.3,vol:.12})},
  rockFall:()=>{nz({dur:.5,vol:.1,f:700,f2:200})},
  rockHit:()=>{nz({dur:.3,vol:.28,type:'lowpass',f:1200,f2:120});tone({f:100,f2:45,dur:.25,vol:.22})}
};
const lastS={};
function sfx(n,a){
  if(!AC||AC.state!=='running'||CFG.sfx===0)return;
  const now=performance.now();if(lastS[n]&&now-lastS[n]<(n==='coin'||n==='step'?40:22))return;lastS[n]=now;
  try{SFX[n]&&SFX[n](a)}catch(e){}
}

/* ---------- music ---------- */
const MZ=[
  {bpm:100,ch:[[60,64,67],[57,60,64],[53,57,60],[55,59,62]],bass:[48,45,41,43],pent:[72,74,76,79,81,84],arp:'pluck'},
  {bpm:82,ch:[[57,60,64],[53,57,60],[50,53,57],[52,56,59]],bass:[45,41,38,40],pent:[69,72,74,76,79,81],arp:'soft'},
  {bpm:112,ch:[[62,66,69],[59,62,66],[55,59,62],[57,61,64]],bass:[50,47,43,45],pent:[74,76,78,81,83,86],arp:'glass'},
  {bpm:136,ch:[[62,65,69],[58,62,65],[60,64,67],[57,61,64]],bass:[38,34,36,33],pent:[74,77,79,81,84,86],arp:'boss'}
];
const Mus={lv:0,step:0,bar:0,next:0,timer:null,int:0,tgt:0,on:false,tempo:1};
const ARPSEQ=[0,1,2,1,0,2,1,2];
function musicStart(i){
  if(!AC)return;Mus.lv=[0,1,2,1,2][i]||0;Mus.step=0;Mus.bar=0;Mus.next=AC.currentTime+.15;Mus.on=true;Mus.int=Mus.tgt=0;Mus.tempo=1;
  if(!Mus.timer)Mus.timer=setInterval(musicTick,30);
}
function musicStop(){Mus.on=false}
function musicTempo(v){Mus.tempo=v}
function musicBoss(on){
  if(!AC)return;
  if(on){Mus.lv=3;Mus.step=0;Mus.bar=0;Mus.next=AC.currentTime+.1;Mus.int=1;Mus.tgt=1;Mus.tempo=1;Mus.on=true;if(!Mus.timer)Mus.timer=setInterval(musicTick,30)}
  else{musicStart(G.lv);Mus.tgt=.3}
}
function audioSuspend(){if(AC&&AC.state==='running'){try{AC.suspend()}catch(e){}}}
function audioResume(){if(AC&&AC.state==='suspended'&&!document.hidden){try{AC.resume()}catch(e){}}}
function musicInt(v){Mus.tgt=v}
function musicTick(){
  if(!AC||AC.state!=='running'||!Mus.on||document.hidden)return;
  Mus.int+=(Mus.tgt-Mus.int)*.03;
  const M=MZ[Mus.lv],sp=60/(M.bpm*Mus.tempo)/4;
  while(Mus.next<AC.currentTime+.16){musicStep(M,Mus.step,Mus.next,sp);Mus.next+=sp;Mus.step=(Mus.step+1)%16;if(Mus.step===0)Mus.bar=(Mus.bar+1)%4}
  if(Mus.next<AC.currentTime-.5)Mus.next=AC.currentTime+.05;
}
function musicStep(M,s,t,sp){
  const ch=M.ch[Mus.bar],I=Mus.int,bus=A.mus;
  if(s===0){
    ch.forEach(n=>{tone({f:mtof(n-12),dur:sp*16.5,type:'triangle',vol:.05,a:sp*5,lp:900,bus,at:t});tone({f:mtof(n),dur:sp*16.5,type:'sine',vol:.032,a:sp*6,bus,at:t})});
  }
  if(M.arp==='boss'){
    if(s%4===0||s===6||s===10||s===14)tone({f:mtof(ch[(s>>2)%3]+12),dur:.2,type:'sawtooth',vol:.05,lp:2600,bus,at:t});
    if(s%2===1)tone({f:mtof(ch[(s>>1)%3]+24),dur:.1,type:'square',vol:.02,lp:4000,bus,at:t});
    if(s===0)tone({f:mtof(ch[0]+12),dur:sp*8,type:'sawtooth',vol:.04,a:.05,lp:1500,bus,at:t});
  }
  const dense=I>.28?2:4;
  if(s%dense===0&&M.arp!=='boss'){
    const n=ch[ARPSEQ[(s/2|0)%8]%3]+(M.arp==='soft'?0:12);
    if(M.arp==='pluck')tone({f:mtof(n),dur:.3,type:'triangle',vol:.055,lp:3600,bus,at:t});
    else if(M.arp==='soft')tone({f:mtof(n+12),dur:.55,type:'triangle',vol:.04,lp:2000,bus,at:t});
    else{tone({f:mtof(n+12),dur:.5,type:'sine',vol:.05,bus,at:t});tone({f:mtof(n+12)*2.76,dur:.18,type:'sine',vol:.014,bus,at:t})}
  }
  if(I>.85&&s%2===1&&M.arp!=='soft')tone({f:mtof(ch[(s>>1)%3]+24),dur:.14,type:'triangle',vol:.025,lp:5000,bus,at:t});
  const bs=M.arp==='boss'?[0,2,4,6,8,10,12,14]:(I>.45?[0,6,8,14]:[0,8]);
  if(bs.includes(s)){const f=mtof(M.bass[Mus.bar]);tone({f,dur:.42,type:'triangle',vol:.13,lp:700,bus,at:t});tone({f:f*2,dur:.2,type:'sine',vol:.03,bus,at:t})}
  const ks=I>.7?[0,4,8,12]:I>.2?[0,8]:[];
  if(ks.includes(s))tone({f:150,f2:42,dur:.17,type:'sine',vol:.2,bus,at:t});
  if(I>.5&&(s===4||s===12)){nz({dur:.12,vol:.07,f:1900,q:.8,bus,at:t});tone({f:190,f2:120,dur:.08,type:'triangle',vol:.04,bus,at:t})}
  if(I>.4&&s%2===0)nz({dur:.04,vol:.028,type:'highpass',f:7000,bus,at:t});
  if(I>.85&&s%2===1)nz({dur:.03,vol:.016,type:'highpass',f:8000,bus,at:t});
  if((s%4===0||s===6||s===14)&&Math.random()<.24*(1-I*.45)){
    const n=M.pent[(Math.random()*M.pent.length)|0];
    tone({f:mtof(n),dur:1.3,type:'sine',vol:.05,bus,at:t});tone({f:mtof(n)*2,dur:.6,type:'sine',vol:.014,bus,at:t});
  }
}
function ambStart(i){
  ambStop();if(!AC)return;
  const s=AC.createBufferSource();s.buffer=A.nb;s.loop=true;
  const f=AC.createBiquadFilter();f.type='bandpass';f.frequency.value=i===1?230:430;f.Q.value=.6;
  const g=AC.createGain();g.gain.value=i===1?.13:.09;
  const lfo=AC.createOscillator();lfo.frequency.value=.11;const lg=AC.createGain();lg.gain.value=.05;lfo.connect(lg);lg.connect(g.gain);
  s.connect(f);f.connect(g);g.connect(A.amb);s.start();lfo.start();
  A.amb1=[s,lfo];A.ambT=setInterval(()=>ambEvent(i),1700);
}
function ambStop(){
  if(A.amb1){A.amb1.forEach(n=>{try{n.stop()}catch(e){}});A.amb1=null}
  if(A.ambT){clearInterval(A.ambT);A.ambT=null}
}
function ambEvent(i){
  if(!AC||mode!=='play'||Math.random()<.55)return;
  if(i!==0&&i!==2)tone({f:1300+Math.random()*700,f2:520,dur:.3,vol:.06,bus:A.amb});
  else{const b=2300+Math.random()*1200,n=2+(Math.random()*3|0);for(let k=0;k<n;k++)tone({f:b,f2:b*(1.2+Math.random()*.3),dur:.09,vol:.035,delay:k*.12,bus:A.amb})}
}



