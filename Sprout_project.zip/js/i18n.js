'use strict';
/* Translation helper: Russian text is the key, English comes from data/lang_en.js */
function L(s){return CFG.lang==='en'?(EN[s]||s):s}
