'use strict';
/* ---------- enemies ---------- */
let eproj=[],haz=[];
const ED={
  beetle:{rig:'beetle',dw:128,hw:64,hh:58,hp:3,sp:58,sc:100,name:'Ржавый Жук',jump:1,jr:210,jh:140},
  fly:{rig:'fly',dw:140,hw:78,hh:66,hp:3,sp:0,sc:150,name:'Мухоловка-мутант',jump:1,jr:260,jh:170},
  drone:{rig:'drone',dw:92,hw:54,hh:64,hp:3,sp:0,sc:200,name:'Лифтовый дрон',fly:1},
  rat:{rig:'rat',dw:124,hw:70,hh:54,hp:2,sp:165,sc:120,name:'Крыса-мусороед',jump:1,jr:300,jh:200},
  spider:{rig:'spider',dw:152,hw:92,hh:74,hp:5,sp:62,sc:220,name:'Паук-тележка',jump:1,jr:200,jh:150},
  spit:{rig:'spit',dw:152,hw:96,hh:74,hp:6,sp:40,sc:260,name:'Гнилой плевун',jump:1,jr:180,jh:130},
  golem:{rig:'golem',dw:236,hw:150,hh:238,hp:80,sp:46,sc:3000,name:'Хранитель Лотоса',boss:1},
};
function go(e,s,t){e.state=s;e.st=t;e.stT=Math.max(t,.001)}
function prog(e){return clamp(1-e.st/e.stT,0,1)}
function pick(a){return a[(Math.random()*a.length)|0]}
function inBox(x0,x1,y0,y1){return P.x+12>Math.min(x0,x1)&&P.x-12<Math.max(x0,x1)&&P.y>y0&&P.y-78<y1}
function segHitsPlayer(x0,y,x1){return P.x+12>Math.min(x0,x1)&&P.x-12<Math.max(x0,x1)&&P.y>y-26&&P.y-78<y+26}
function mark(x,w,life){const y=floorBelow(x,0);addHaz({k:'mark',x,y:y===null?GY:y,w:w||80,t:0,life:life||1})}
function jumpTo(e,tx,ty,apexMin,maxV){
  const dy=e.y-ty,apex=Math.max(apexMin||60,dy+55),vy0=-Math.sqrt(2*GRAV*apex);
  const T=-vy0/GRAV+Math.sqrt(2*(apex-dy)/GRAV),mv=maxV||460;
  const qy=Math.min(e.y,ty)-10,ok=x=>floorBelow(x,qy)!==null&&floorBelow(x-34,qy)!==null&&floorBelow(x+34,qy)!==null;
  let vx=0;
  for(const k of [1,1.12,1.25,.9,.8,.7,.6,.5,.4,.3,.2]){const v=clamp((tx-e.x)/T*k,-mv,mv);if(ok(e.x+v*T)){vx=v;break}}
  e.vy=vy0;e.vx=vx;e.onGround=false;e.jumped=true;e.jcd=1.1;e.airT=T;
}
function gapLand(e,dir){
  for(let d=60;d<=(ED[e.type].jr||200)+80;d+=20){const x=e.x+dir*d,y=floorBelow(x,e.y-10);if(y!==null&&y<=e.y+90&&y>=e.y-120&&floorBelow(x-38,e.y-10)!==null&&floorBelow(x+38,e.y-10)!==null)return{x,y}}
  return null;
}
/* hunting: step to platforms toward the hero, jump gaps, never walk into pits */
function chase(e,dt,sp,jump){
  const D=ED[e.type];let tgt=P.x;
  if(jump&&e.onGround&&P.y<e.y-70){
    let best=null,bs=1e9;
    for(const p of LV.plats){
      if(p.y<e.y-30&&p.y>e.y-(D.jh||150)){
        const cx=p.x+p.w/2,s=Math.abs(cx-P.x)+Math.max(0,p.y-P.y)*1.3+Math.abs(cx-e.x)*.15;
        if(s<bs){bs=s;best=p}
      }
    }
    if(best){
      const nx=clamp(e.x,best.x+14,best.x+best.w-14);
      if(Math.abs(nx-e.x)<(D.jr||200)*.9){
        if(e.jcd<=0){jumpTo(e,clamp(P.x,best.x+14,best.x+best.w-14),best.y,70);sfx('hop');return}
        tgt=e.x;
      }else tgt=nx;
    }
  }
  const mv=Math.abs(tgt-e.x)>e.stopR,dir=tgt>e.x?1:-1;
  if(sp===0&&e.onGround&&e.jcd<=0&&mv){const tx=e.x+dir*Math.min(180,Math.abs(tgt-e.x)),fy=floorBelow(tx,e.y-10);if(fy!==null&&fy<=e.y+100){e.face=dir;jumpTo(e,tx,fy,70);sfx('hop');return}}
  e.face=mv&&Math.abs(tgt-P.x)>40?dir:(P.x>e.x?1:-1);
  let want=mv?dir:0;
  if(want&&e.onGround){
    const ax=e.x+want*(e.hw*.4+26);
    if(floorBelow(ax,e.y-4)===null){
      if(jump&&e.jcd<=0){const Lnd=gapLand(e,want);if(Lnd){jumpTo(e,Lnd.x,Lnd.y,80);sfx('hop')}else want=0}else want=0;
    }
  }
  if(e.onGround)e.vx=approach(e.vx,want*sp,1400*dt);
}
function hover(e,dt,tx,ty,mx){
  if(e.kb<=0){e.vx=approach(e.vx,clamp((tx-e.x)*1.6,-mx,mx),520*dt);e.vy=approach(e.vy,clamp((ty-e.y)*2,-150,150),520*dt)}
  else{e.vx=approach(e.vx,0,500*dt);e.vy=approach(e.vy,0,500*dt)}
  e.face=P.x>e.x?1:-1;
}
function spawnEnemy(type,ax,ay){
  const d=ED[type],DF=DIFF[CFG.diff];
  let x=ax===undefined?null:ax,y=ay===undefined?GY:ay;
  if(x===null&&type==='fly'&&Math.random()<.5){
    const c=LV.plats.filter(p=>p.x+p.w/2>cam-300&&p.x+p.w/2<cam+W+300&&Math.abs(p.x+p.w/2-P.x)>200&&!p.mv);
    if(c.length){const p=pick(c);x=p.x+p.w/2;y=p.y}
  }
  for(let a=0;a<30&&x===null;a++){
    const side=Math.random()<.5?-1:1;
    let cx=side<0?cam-70-rnd(0,260):cam+W+70+rnd(0,260);
    cx=clamp(cx,60,LV.world-260);
    const g=LV.ground.find(g=>cx>g.x+60&&cx<g.x+g.w-60);
    if(g&&Math.abs(cx-P.x)>260){x=cx;y=GY}
  }
  if(x===null){const g=LV.ground[LV.ground.length-1];x=g.x+g.w/2-100;y=GY}
  const rig=RIG[d.rig],hp=Math.max(1,Math.round(d.hp*DF.hp));
  const e={type,boss:!!d.boss,fly:!!d.fly,x,y:d.fly?(d.boss?GY-215:clamp(P.y-210,110,300)):y-6,vx:0,vy:0,dir:Math.random()<.5?-1:1,face:1,hw:d.hw,hh:d.hh,dw:d.dw,dh:d.dw*rig.h/rig.w,
    hp,t:rnd(0,6),flash:0,kb:0,speed:d.boss?d.sp*DF.sp:(d.sp+G.wave*2.5+G.lv*5)*DF.sp,onGround:false,dead:false,score:d.sc,ph:rnd(0,6),spawnT:d.boss?1.6:.6,landSq:0,pvy:0,
    state:'move',st:0,stT:1,atkCd:rnd(1.2,2.4),jcd:.6,stopR:d.boss?120:(d.base==='rat'||type==='rat'?24:22),hurtT:0,dying:null,tl:0,jumped:false,fired:0,volley:0,frozen:0};
  e.maxhp=e.hp;
  enemies.push(e);sfx('spawn');
  burst(x,e.y+6,16,['#79c943','#a8e85a','#7a5a30'],150,.7,200,3.5);
  if(d.boss){sfx('roar');addShake(12);go(e,'intro',3.6);ring(x,y,'#ffb347',220,.8)}
  return e;
}
function hitEnemy(e,dmg,kx,ky){
  if(e.dead||e.dying||e.spawnT>.25)return;
  e.hp-=dmg;e.flash=.16;e.hurtT=.28;
  if(!e.boss){e.kb=.28;e.vx=kx;e.vy=ky;if(e.fly){e.vx=kx*.5;e.vy=ky*.3}}
  if(e.state==='tel'&&!e.boss&&dmg>=2)go(e,'move',0);
  burst(e.x,e.y-e.hh*.5,9,['#ffb347','#ffe45c','#fff'],230,.4,300,3,true);
  leafBurst(e.x,e.y-e.hh*.5,3);
  const b=ED[e.type].base||e.type;
  sfx(b==='fly'||b==='spit'||b==='rat'?'hitfly':'hit');addShake(e.boss?2:3);stop(e.boss?.02:.035);dmgText(e.x,e.y-e.hh-4,dmg);
  if(e.hp<=0){e.hp=0;killEnemy(e)}
}
function killEnemy(e){
  if(e.boss){e.dying='boss';go(e,'dying',3.4);e.vx=0;e.vy=0;stop(.2);G.slow=.8;sfx('roar');addShake(14);return}
  if((ED[e.type].base||e.type)==='spider'){e.dying='boom';go(e,'dying',.95);e.vx=0;sfx('charge');return}
  finalizeKill(e);
}
function finalizeKill(e){
  e.dead=true;G.kills++;G.score+=e.score;G.killed[e.type]=1;
  const big=e.boss,D=ED[e.type],b=D.base||e.type;
  burst(e.x,e.y-e.hh*.5,big?90:22,['#ffb347','#ff7a2a','#ffe45c','#7a4a25'],big?520:280,.9,500,big?6:4,false);
  leafBurst(e.x,e.y-e.hh*.5,big?50:12);ring(e.x,e.y-e.hh*.5,'#ffd36b',big?260:80,.5);
  const rig=RIG[D.rig],fl=(b==='beetle'||b==='drone'||e.type==='golem')?1:(e.face>0?1:-1);
  spawnDebris(rig,e.x,e.y,e.dw/rig.w,fl,big?1.3:.8);
  sfx(b==='fly'||b==='spit'||b==='rat'?'killfly':'kill');addShake(big?18:5);stop(big?.25:.06);
  ftext(e.x,e.y-e.hh-10,'+'+e.score,'#ffe45c');
  const r=Math.random();
  const drop=(t,ox)=>{LV.items.push({t,x:e.x+ox,y:e.y-34,ph:Math.random()*6,got:false,drop:true})};
  if(big){for(let i=0;i<10;i++)drop('coin',(i-4.5)*26);drop('heart',-30);drop('heart',30);drop('orb',0);drop('orb',60);G.slow=1;musicBoss(false)}
  else if(b==='spider'){for(let i=0;i<4;i++)drop('coin',(i-1.5)*24)}
  else if(r<.45)drop('coin',0);else if(r<.72)drop('orb',0);else if(r<.82&&P.hp<P.maxHp)drop('heart',0);
}
function bigBoom(x,y,R){
  sfx('boom');addShake(13);stop(.07);ring(x,y,'#ff9a3a',R*1.2,.5);ring(x,y,'#fff',R*.7,.3);
  burst(x,y,40,['#ff9a3a','#ffe45c','#ff5a2a'],360,.7,300,4,true);leafBurst(x,y,8);
  if(Math.hypot(P.x-x,P.y-40-y)<R+10)hurtPlayer(1,x);
  for(const e of enemies){if(e.dead||e.dying||e.spawnT>0||e.boss)continue;if(Math.hypot(e.x-x,e.y-e.hh/2-y)<R+e.hw*.3)hitEnemy(e,2,(e.x>=x?1:-1)*300,-260)}
}
function addEProj(o){eproj.push(o)}
function addHaz(o){haz.push(o)}
function volleyBolts(e,n,spd,spread,aimX,aimY,sx,sy,kind){
  const base=Math.atan2(aimY-sy,aimX-sx);
  for(let i=0;i<n;i++){const a=base+(n>1?(i/(n-1)-.5)*spread:0);addEProj({k:kind||'bolt',x:sx,y:sy,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,life:2.6,r:9})}
}
function lob(sx,sy,tx,ty,T,g,k,r){addEProj({k,x:sx,y:sy,vx:(tx-sx)/T,vy:(ty-sy-.5*g*T*T)/T,life:T+2,r:r||12})}
/* ---------- AI ---------- */
const AI={};
function frict(e,dt,a){e.vx=approach(e.vx,0,(a||600)*dt)}
AI.beetle=(e,dt)=>{
  const dx=P.x-e.x,adx=Math.abs(dx),dy=P.y-e.y;
  if(e.kb>0){frict(e,dt);return}
  if(e.state==='tel'){e.vx=0;e.face=dx>0?1:-1;if(e.st<=0){go(e,'atk',.3);sfx('sweep');e.fired=0}return}
  if(e.state==='atk'){
    e.vx=e.face*50;
    if(!e.fired&&inBox(e.x,e.x+e.face*160,e.y-95,e.y)){e.fired=1;hurtPlayer(1,e.x);if(P.inv>0)P.vx=e.face*380}
    if(e.st<=0){go(e,'rec',.5);e.atkCd=2.4}return;
  }
  if(e.state==='rec'){frict(e,dt,900);if(e.st<=0)go(e,'move',0);return}
  chase(e,dt,e.speed,true);
  if(adx<150&&Math.abs(dy)<80&&e.atkCd<=0&&e.onGround){go(e,'tel',.45);sfx('charge')}
};
/* mouth of a flytrap in world space (sprite point .64/.44, turned with the head) */
function mouthPos(e,xf){
  const fl=e.face>0?1:-1,dw=e.dw,dh=e.dh,px=e.x,py=e.y-.6*dh;
  let hr=0;
  if(xf&&xf.head&&xf.head.r!==undefined)hr=xf.head.r;else if(e.state==='atk')hr=.35;else if(e.state==='tel')hr=-.35*prog(e);
  const r=hr*fl,vx=(.64-.5)*dw*fl,vy=(.44-.4)*dh;
  return{x:px+vx*Math.cos(r)-vy*Math.sin(r),y:py+vx*Math.sin(r)+vy*Math.cos(r)};
}
function hopAI(e,dt){
  const dx=P.x-e.x,adx=Math.abs(dx),dir=dx>0?1:-1;
  if(!e.onGround)return;
  if(e.jcd<=0&&adx<1200){
    if(P.y<e.y-70){chase(e,dt,0,true);e.jcd=Math.max(e.jcd,.5)}
    else{
      let done=false;
      for(const d of [150+rnd(0,70),110,70]){const tx=e.x+dir*d,fy=floorBelow(tx,e.y-10);if(fy!==null&&fy<=e.y+100&&floorBelow(tx+dir*24,e.y-10)!==null){jumpTo(e,tx,fy,70);sfx('hop');done=true;break}}
      if(!done){const Lnd=gapLand(e,dir);if(Lnd){jumpTo(e,Lnd.x,Lnd.y,80);sfx('hop')}else e.jcd=.4}
    }
  }
}
AI.fly=(e,dt)=>{
  const dx=P.x-e.x,adx=Math.abs(dx),dy=P.y-e.y,dir=dx>0?1:-1;
  if(e.kb>0){frict(e,dt,900);return}
  if(e.onGround){frict(e,dt,1100);e.face=dir}
  if(e.state==='tel'){if(e.st<=0){go(e,'atk',.5);sfx('tongue');e.fired=0}return}
  if(e.state==='atk'){
    const u=prog(e);e.tl=Math.sin(Math.min(1,u*1.4)*Math.PI*.5)*(u>.7?1-(u-.7)/.3:1)*300;
    const mp=mouthPos(e),mx=mp.x,my=mp.y;
    if(!e.fired&&segHitsPlayer(mx,my,mx+e.face*e.tl)){e.fired=1;hurtPlayer(1,e.x);P.vx=-e.face*480;P.kb=.25}
    if(e.st<=0){go(e,'rec',.45);e.atkCd=3;e.tl=0}return;
  }
  if(e.state==='rec'){if(e.st<=0)go(e,'move',0);return}
  if(!e.onGround)return;
  if(e.atkCd<=0&&adx>150&&adx<320&&Math.abs(dy)<90){go(e,'tel',.5);sfx('charge');return}
  hopAI(e,dt);
};
AI.drone=(e,dt)=>{
  hover(e,dt,P.x+Math.sin(e.t*.7)*170,clamp(P.y-165+Math.sin(e.t*1.4)*18,100,GY-130),175);
  if(e.state==='tel'){
    if(e.st<=0){const sx=e.x+e.face*34,sy=e.y-e.hh*.4;volleyBolts(e,1,360,0,P.x,P.y-45,sx,sy);sfx('bolt');go(e,'move',0);e.atkCd=2.3;e.recoil=.2}
  }else if(e.atkCd<=0&&Math.abs(P.x-e.x)<540){go(e,'tel',.55);sfx('droneCharge')}
  if(!e.called&&e.hp<=1&&e.maxhp>1&&enemies.length<9){
    e.called=true;e.alarm=1.6;sfx('alarm');ftext(e.x,e.y-e.dh-14,L('вызывает подмогу!'),'#ff9a6a');
    const g=LV.ground.find(g=>e.x>g.x+80&&e.x<g.x+g.w-80);
    if(g)spawnEnemy('rat',clamp(e.x+rnd(-80,80),g.x+80,g.x+g.w-80),GY);
  }
  if(e.alarm>0)e.alarm-=dt;if(e.recoil>0)e.recoil-=dt;
};
AI.rat=(e,dt)=>{
  const dx=P.x-e.x,adx=Math.abs(dx),dy=P.y-e.y,dir=dx>0?1:-1;
  if(e.kb>0){frict(e,dt);return}
  if(e.state==='tel'){e.vx=0;e.face=dir;if(e.st<=0){e.vx=dir*480;e.vy=-540;e.onGround=false;e.jumped=true;go(e,'atk',1.4);sfx('pounce')}return}
  if(e.state==='atk'){if(e.onGround&&e.st<1.25){go(e,'rec',.7);e.atkCd=2.2;burst(e.x,e.y,8,['#bcd88c','#9ac86a'],110,.4,150,3)}return}
  if(e.state==='rec'){frict(e,dt,1600);if(e.st<=0)go(e,'move',0);return}
  chase(e,dt,e.speed,true);
  if(e.onGround&&e.atkCd<=0&&adx>130&&adx<340&&Math.abs(dy)<70&&floorBelow(e.x+dir*240,e.y-10)!==null){go(e,'tel',.38);sfx('squeak')}
};
AI.spider=(e,dt)=>{
  const dx=P.x-e.x,adx=Math.abs(dx),dy=P.y-e.y;
  if(e.kb>0){frict(e,dt);return}
  if(e.state==='tel'){e.vx=0;e.face=dx>0?1:-1;if(e.st<=0){go(e,'atk',.28);sfx('stab');e.fired=0}return}
  if(e.state==='atk'){
    if(!e.fired&&inBox(e.x,e.x+e.face*205,e.y-95,e.y)){e.fired=1;hurtPlayer(1,e.x);if(P.inv>0)P.vx=e.face*340}
    if(e.st<=0){go(e,'rec',.55);e.atkCd=2.6}return;
  }
  if(e.state==='rec'){frict(e,dt,900);if(e.st<=0)go(e,'move',0);return}
  chase(e,dt,e.speed,true);
  if(adx<200&&Math.abs(dy)<90&&e.atkCd<=0&&e.onGround){go(e,'tel',.5);sfx('charge')}
};
function spitAI(n,rocks){return(e,dt)=>{
  const dx=P.x-e.x,adx=Math.abs(dx);
  if(e.kb>0){frict(e,dt);return}
  if(e.state==='tel'){e.vx=0;e.face=dx>0?1:-1;if(e.st<=0){go(e,'atk',.3);e.fired=0}return}
  if(e.state==='atk'){
    if(!e.fired){
      e.fired=1;const sx=e.x+e.face*e.hw*.4,sy=e.y-e.hh*.7;
      for(let i=0;i<n;i++){const tx=clamp(P.x+(i-(n-1)/2)*95,30,LV.world-30);lob(sx,sy,tx,P.y-30,.8+i*.12,1200,'acid',12);if(n>1)mark(tx,60,.9+i*.12)}
      sfx('spit');
    }
    if(e.st<=0){go(e,'rec',.6);e.atkCd=2.8}return;
  }
  if(e.state==='rec'){frict(e,dt,900);if(e.st<=0)go(e,'move',0);return}
  if(e.state==='roar'){
    e.vx=0;
    if(e.st<=0){go(e,'move',0);e.rockCd=7;for(let i=0;i<4;i++){const rx=clamp(P.x+rnd(-230,230),30,LV.world-30);addHaz({k:'rock',x:rx,t:-i*.28,warn:.95,y:-40,vy:0,fell:false})}}
    return;
  }
  chase(e,dt,e.speed,true);
  if(rocks){
    if(!e.roared&&e.hp<=e.maxhp/2){e.roared=true;e.rockCd=7;go(e,'roar',1.1);sfx('roar');addShake(8);return}
    if(e.roared){e.rockCd-=dt;if(e.rockCd<=0){go(e,'roar',1.0);sfx('roar')}}
  }
  if(e.atkCd<=0&&adx>110&&adx<560&&e.onGround){go(e,'tel',.7);sfx('charge')}
}}
AI.spit=spitAI(1,true);
/* --- level 3 variants --- */
/* --- level 4 variants --- */
/* --- level 5 variants --- */
/* ---------- bosses (one stage, every attack telegraphed and dodgeable) ---------- */
function bossIntro(e){
  if(e.state!=='intro')return false;
  e.vx=0;e.face=P.x>e.x?1:-1;if(Math.random()<.2)addShake(2);
  if(e.st<=0){go(e,'walk',0);e.atkCd=1.4}
  return true;
}
function startAtk(e,a,t){e.fired=0;e.volley=0;go(e,a,t)}
AI.golem=(e,dt)=>{
  const dx=P.x-e.x,adx=Math.abs(dx),dir=dx>0?1:-1,u=prog(e),cd=2.0;
  if(bossIntro(e))return;
  switch(e.state){
    case 'walk':{
      e.face=dir;let want=adx>e.stopR?dir:0;
      if(want&&e.onGround&&floorBelow(e.x+want*(e.hw*.5+30),e.y-4)===null){want=0;if(e.jcd<=0){e.jcd=2.2;startAtk(e,'leap',2.2);sfx('charge');break}}
      e.vx=approach(e.vx,want*e.speed,900*dt);
      if(Math.abs(e.vx)>8){const pp=e.ph;e.ph+=dt*(Math.abs(e.vx)/60)*4;if(Math.floor(e.ph/Math.PI)!==Math.floor(pp/Math.PI)){sfx('thud');addShake(3);burst(e.x+(Math.sin(e.ph)>0?50:-50),e.y,4,['#9a7a4a','#6a8a3a'],90,.4,200,3)}}
      if(e.atkCd<=0&&e.onGround){
        const o=[];if(adx<220)o.push('slam','slam','spikes');if(adx>=180&&adx<560)o.push('bombs','beam','spikes');if(adx>=380||P.y<e.y-150||floorBelow(P.x,GY-30)===null)o.push('leap','bombs');
        const a=pick(o)||'slam';startAtk(e,a,{slam:1.7,leap:2.2,bombs:2.3,beam:2.4,spikes:1.9}[a]);sfx(a==='beam'?'beamCharge':'charge');
      }
      break;
    }
    case 'slam':
      e.vx=0;
      if(u>.5&&!e.fired){e.fired=1;sfx('slam');addShake(14);for(const s of [-1,1])addHaz({k:'wave',x:e.x+s*85,y:GY,dir:s,life:2.4,v:380});ring(e.x,e.y,'#ffcf6a',150,.4);burst(e.x,e.y,16,['#9a7a4a','#6a8a3a','#fff'],280,.6,400,4)}
      if(e.st<=0){go(e,'walk',0);e.atkCd=cd}break;
    case 'leap':
      if(!e.fired&&u>.34){
        e.fired=1;let tx=clamp(P.x,e.x-620,e.x+620),fy=floorBelow(tx,e.y-10);
        if(fy===null){tx=e.x+dir*240;fy=floorBelow(tx,e.y-10)}
        if(fy!==null){jumpTo(e,tx,fy,170,560);e.leaping=true;mark(e.x+e.vx*e.airT,150,e.airT);sfx('roar')}else{go(e,'walk',0);e.atkCd=.4}
      }
      if(e.leaping&&e.onGround&&e.fired){
        e.leaping=false;e.vx=0;sfx('slam');addShake(16);ring(e.x,e.y,'#ffcf6a',190,.45);burst(e.x,e.y,22,['#9a7a4a','#6a8a3a','#fff'],320,.7,400,4);
        if(Math.abs(P.x-e.x)<135&&P.y>e.y-60)hurtPlayer(1,e.x);
        go(e,'rec',.9);
      }
      if(!e.leaping)e.vx=approach(e.vx,0,1200*dt);
      if(e.state==='leap'&&e.st<=0&&!e.leaping){go(e,'walk',0);e.atkCd=cd}
      break;
    case 'rec':e.vx=0;if(e.st<=0){go(e,'walk',0);e.atkCd=cd}break;
    case 'bombs':
      e.vx=0;
      if(u>.4&&e.fired<3&&e.volley<=0){
        const n=e.fired;e.fired++;e.volley=.3;
        const far=n%2===0,bx=e.x+(n%2?1:-1)*e.dw*(far?.43:.34),by=e.y-e.dh*(far?.8:.72);
        const T=1.15,tx=clamp(P.x+rnd(-140,140),40,LV.world-40);
        lob(bx,by,tx,GY-10,T,900,'bomb',14);mark(tx,110,T);sfx('bombLaunch');
      }
      if(e.volley>0)e.volley-=dt;
      if(e.st<=0){go(e,'walk',0);e.atkCd=cd}break;
    case 'beam':{
      e.vx=0;const bx=e.x+e.face*60,by=e.y-e.dh*.6;
      e.beam={x:bx,y:by,dir:e.face,len:1000,on:u>.5&&u<.8};
      if(e.beam.on){
        if(!e.fired){e.fired=1;sfx('beam')}
        if(P.inv<=0&&(P.x-bx)*e.face>0&&(P.x-bx)*e.face<1000&&P.y-104<by+22&&P.y>by-22)hurtPlayer(1,e.x);
        if(Math.random()<.5)burst(bx+e.face*rnd(60,900),by+rnd(-10,10),1,['#d8ff7a','#fff'],110,.35,0,3,true);
      }
      if(e.st<=0){e.beam=null;go(e,'walk',0);e.atkCd=cd+.3}break;
    }
    case 'spikes':
      e.vx=0;
      if(u>.3&&!e.fired){
        e.fired=1;sfx('rootCall');
        for(let i=0;i<6;i++){const x=e.x+dir*(120+i*90);if(x>20&&x<LV.world-20&&floorBelow(x,GY-30)!==null)addHaz({k:'root',x,y:GY,t:0,warn:.8+i*.08,act:.5,dir})}
      }
      if(e.st<=0){go(e,'walk',0);e.atkCd=cd}break;
  }
  if(e.state!=='beam')e.face=dir;
};
function dyingTick(e,dt){
  if(e.dying==='boss'){
    const u=prog(e);
    if(Math.random()<dt*16)burst(e.x+rnd(-e.hw/2,e.hw/2),e.y-rnd(20,e.hh),5,['#b6ff5a','#ffb347','#ff6a3a','#fff'],240,.6,200,4,true);
    if(Math.random()<dt*5){sfx('crumble');addShake(5);leafBurst(e.x+rnd(-80,80),e.y-rnd(40,e.hh*.9),4)}
    if(u>.7&&Math.random()<dt*6)ring(e.x+rnd(-60,60),e.y-rnd(40,e.hh*.8),'#ffcf6a',90,.4);
    e.beam=null;e.lz=null;
    if(e.fly&&e.y<GY-6)e.y=Math.min(GY-6,e.y+240*dt);
    if(e.st<=0){bigBoom(e.x,e.y-e.hh*.5,240);finalizeKill(e)}
  }else if(e.dying==='boom'){
    if(e.st<=0){bigBoom(e.x,e.y-40,125);finalizeKill(e)}
  }
}
function rescueEnemy(e){
  let best=null,bd=1e9;
  for(const g of LV.ground){const d=Math.max(g.x-e.x,0,e.x-(g.x+g.w));if(d<bd){bd=d;best=g}}
  if(!best)return;
  const mg=e.boss?140:80;
  e.x=clamp(e.x,best.x+mg,best.x+best.w-mg);e.y=GY-2;e.vx=0;e.vy=0;e.onGround=true;e.jumped=false;e.leaping=false;e.kb=0;
  if(e.boss&&e.state!=='dying'&&e.state!=='intro')go(e,'walk',0);
  ring(e.x,GY-10,'#9ac86a',80,.35);burst(e.x,GY-10,12,['#9ac86a','#cfe9a0','#fff'],160,.5,200,3);sfx('hop');
}
function updateEnemies(dt){
  for(const e of enemies){
    if(e.dead)continue;
    if(e.frozen>0){
      e.frozen-=dt;e.flash=0;e.vx=approach(e.vx,0,2500*dt);
      if(!e.fly){e.pvy=e.vy;moveBody(e,dt,e.hw*.3)}else{e.vy=approach(e.vy,0,2000*dt)}
      continue;
    }
    e.t+=dt;e.flash=Math.max(0,e.flash-dt);e.kb=Math.max(0,e.kb-dt);e.landSq=Math.max(0,e.landSq-dt*1.5);e.hurtT=Math.max(0,e.hurtT-dt);
    e.atkCd-=dt;e.jcd-=dt;e.st-=dt;
    if(e.spawnT>0){e.spawnT-=dt;if(e.boss&&Math.random()<dt*12)addShake(1.5);continue}
    if(e.dying){dyingTick(e,dt);if(!e.fly){e.vx=0;moveBody(e,dt,e.hw*.3)}continue}
    AI[e.type](e,dt);
    if(e.fly){e.x+=e.vx*dt;e.y+=e.vy*dt}
    else{
      if(e.onGround&&e.vx!==0&&!e.jumped){const ax=e.x+Math.sign(e.vx)*(e.hw*.35)+e.vx*dt;if(floorBelow(ax,e.y-4)===null)e.vx=0}
      e.pvy=e.vy;const wg=e.onGround;
      moveBody(e,dt,e.hw*.3);
      if(e.onGround){if(e.jumped)e.jumped=false;if(!wg&&e.pvy>200){e.landSq=Math.min(e.boss?.1:.2,e.pvy/2600);burst(e.x,e.y,5,['#9ac86a','#7a5a30'],80,.35,150,2.5)}}
      if(e.onGround&&e.solid&&e.solid.dx)e.x+=e.solid.dx;
    }
    if(!e.fly&&e.y>GY+34&&!e.onGround)rescueEnemy(e);
    if(e.y>H+200){e.dead=true;continue}
    e.x=clamp(e.x,20,LV.world-20);
    if(e.onGround&&e.vx!==0)e.ph+=dt*(Math.abs(e.vx)/60)*7;
    if(mode!=='play')continue;
    const px0=P.x-12,px1=P.x+12,py0=P.y-78,py1=P.y;
    if(px1>e.x-e.hw/2&&px0<e.x+e.hw/2&&py1>e.y-e.hh&&py0<e.y){
      if(!e.boss&&P.vy>120&&P.y<e.y-e.hh+(e.fly?30:26)){
        P.vy=-440;P.jumps=1;P.jcut=true;P.stretch=.15;hitEnemy(e,1,e.fly?0:(P.x<e.x?-120:120),e.fly?0:-200);ftext(e.x,e.y-e.hh-26,L('прыжок!'),'#cfffa0');
      }else if(e.state!=='tel'||e.boss)hurtPlayer(1,e.x);
    }
  }
  enemies=enemies.filter(e=>!e.dead);
  updateEProj(dt);updateHaz(dt);
}
function updateEProj(dt){
  for(const q of eproj){
    if(q.delay>0){q.delay-=dt;continue}
    q.life-=dt;
    const straight=q.k==='bolt'||q.k==='shard';
    if(straight){
      q.x+=q.vx*dt;q.y+=q.vy*dt;
      if(Math.random()<.6)parts.push({x:q.x,y:q.y,vx:rnd(-20,20),vy:rnd(-20,20),life:.25,max:.25,g:0,s:3,c:q.k==='shard'?'#9fe8ff':'#ffb347',add:true});
      if(Math.hypot(P.x-q.x,P.y-42-q.y)<q.r+20){hurtPlayer(1,q.x-Math.sign(q.vx));q.life=0;burst(q.x,q.y,8,['#ffb347','#fff'],180,.3,0,3,true)}
    }else{
      const g=q.k==='acid'?1200:q.k==='spore'?1000:900;
      q.vy+=g*dt;const py=q.y;q.x+=q.vx*dt;q.y+=q.vy*dt;
      if(Math.random()<.7)parts.push({x:q.x,y:q.y,vx:rnd(-20,20),vy:rnd(-20,20),life:.3,max:.3,g:0,s:q.k==='bomb'||q.k==='crate'?4:3,c:q.k==='bomb'||q.k==='crate'?'#ff9a3a':q.k==='spore'?'#ff9ae8':'#9dff5a',add:true});
      let hit=false,fy=GY;
      if(q.vy>0)for(const s of LV.solids){if(q.x>s.x&&q.x<s.x+s.w&&py<=s.y+2&&q.y>=s.y){hit=true;fy=s.y;break}}
      if(Math.hypot(P.x-q.x,P.y-42-q.y)<q.r+20){hit=true;fy=Math.min(fy,q.y);if(q.k!=='spore')hurtPlayer(1,q.x)}
      if(hit){
        q.life=0;
        if(q.k==='acid'){sfx('splash');burst(q.x,fy,14,['#9dff5a','#5acf2a','#d8ff7a'],200,.6,500,4);addHaz({k:'puddle',x:q.x,y:fy,w:100,life:3.6,t:0})}
        else if(q.k==='spore'){sfx('splash');burst(q.x,fy,16,['#ff9ae8','#d85ac8','#fff'],180,.7,-40,4,true);addHaz({k:'cloud',x:q.x,y:fy,w:130,life:4,t:0})}
        else{sfx('bombBoom');addShake(7);ring(q.x,fy-10,'#ff9a3a',100,.4);burst(q.x,fy-10,22,['#ff9a3a','#ffe45c','#ff5a2a'],260,.6,300,4,true);
          if(Math.abs(P.x-q.x)<85&&Math.abs(P.y-fy)<70)hurtPlayer(1,q.x);addHaz({k:'fire',x:q.x,y:fy,w:110,life:2.8,t:0})}
      }
    }
    if(q.y>H+60||q.x<-100||q.x>LV.world+100)q.life=0;
  }
  eproj=eproj.filter(q=>q.life>0);
}
function updateHaz(dt){
  for(const h of haz){
    h.t+=dt;
    if(h.k==='puddle'||h.k==='fire'){
      h.life-=dt;
      if(P.onGround&&Math.abs(P.x-h.x)<h.w/2&&Math.abs(P.y-h.y)<10)hurtPlayer(1,h.x);
      if(Math.random()<dt*10)burst(h.x+rnd(-h.w/2,h.w/2),h.y-4,1,h.k==='fire'?['#ff9a3a','#ffe45c']:['#9dff5a','#d8ff7a'],50,.5,-60,3,true);
    }else if(h.k==='cloud'){
      h.life-=dt;
      if(Math.abs(P.x-h.x)<h.w/2&&P.y>h.y-115&&P.y<h.y+10)hurtPlayer(1,h.x);
      if(Math.random()<dt*14)burst(h.x+rnd(-h.w/2,h.w/2),h.y-rnd(0,90),1,['#ff9ae8','#d85ac8'],30,.9,-20,5,true);
    }else if(h.k==='mark'){h.life-=dt}
    else if(h.k==='mine'){
      h.life-=dt;
      if(h.t>1&&Math.abs(P.x-h.x)<46&&Math.abs(P.y-h.y)<40){h.life=0;bigBoom(h.x,h.y-10,75)}
    }else if(h.k==='laser'){
      const ph=h.t%h.cyc;h.on=ph>h.cyc-1.2;h.warn=ph>h.cyc-2.1&&!h.on;
      if(h.on&&Math.abs(P.x-h.x)<18)hurtPlayer(1,h.x);
    }else if(h.k==='wave'){
      h.x+=h.dir*h.v*dt;h.life-=dt;
      if(Math.random()<.5)burst(h.x,h.y,1,['#9a7a4a','#fff'],90,.3,100,3);
      if(Math.abs(P.x-h.x)<30&&P.y>h.y-38)hurtPlayer(1,h.x-h.dir);
      if(floorBelow(h.x,GY-30)===null)h.life=0;
    }else if(h.k==='root'){
      if(h.t<h.warn){if(Math.random()<dt*20)burst(h.x+rnd(-14,14),h.y,1,['#9a7a4a','#6a8a3a'],60,.4,200,3)}
      else if(h.t<h.warn+h.act){
        if(!h.up){h.up=1;sfx('rootErupt');burst(h.x,h.y,8,['#9a7a4a','#6a8a3a','#fff'],200,.5,300,3)}
        if(Math.abs(P.x-h.x)<28&&P.y>h.y-100)hurtPlayer(1,h.x);
      }else h.life=0;
      if(h.life===undefined)h.life=1;
    }else if(h.k==='rock'){
      if(h.t<h.warn){h.life=1}
      else{
        if(!h.fell){h.fell=true;sfx('rockFall')}
        h.vy+=1500*dt;h.y+=h.vy*dt;h.life=1;
        const fy=floorBelow(h.x,0);
        if(Math.abs(P.x-h.x)<26&&P.y-80<h.y&&P.y>h.y-20)hurtPlayer(1,h.x);
        if(fy!==null&&h.y>=fy){h.life=0;sfx('rockHit');addShake(5);burst(h.x,fy,12,['#8a7a6a','#5a4a3a','#fff'],200,.5,400,4)}
        else if(fy===null&&h.y>H+50)h.life=0;
      }
      if(h.k==='rock'&&h.t<h.warn&&h.t>=0){const fy=floorBelow(h.x,0);if(fy!==null)h.mk=fy}
    }
    if(h.k==='rock'&&h.t<0)h.life=1;
  }
  haz=haz.filter(h=>h.life===undefined||h.life>0);
}
/* ---------- poses ---------- */
const POSE={};
const smo=k=>k*k*(3-2*k);
POSE.beetle=e=>{
  const xf={root:{x:0,y:0,sx:1,sy:1},body:{x:0,y:0,r:0},antL:{r:0},antR:{r:0},armL:{r:0,y:0},armR:{r:0,y:0},legL:{r:0,y:0},legR:{r:0,y:0}};
  const R=xf.root,B=xf.body,s=Math.sin(e.ph),mv=e.onGround&&Math.abs(e.vx)>8,DN=1.35,AY=11;
  xf.armL.r=-DN;xf.armR.r=DN;xf.armL.y=AY;xf.armR.y=AY;
  if(mv){B.y=-Math.abs(s)*4.5;B.r=s*.05;xf.armL.r=-DN+s*.28;xf.armR.r=DN-s*.28;xf.armL.y=AY-Math.max(0,s)*7;xf.armR.y=AY-Math.max(0,-s)*7;xf.legL.y=-Math.max(0,s)*9;xf.legL.r=s*.14;xf.legR.y=-Math.max(0,-s)*9;xf.legR.r=s*.14;R.x=Math.cos(e.ph)*1.5}
  else{B.y=Math.sin(e.t*2)*1.2;xf.armL.r=-DN+Math.sin(e.t*2.4)*.07;xf.armR.r=DN+Math.sin(e.t*2.4+1)*.07;B.r=Math.sin(e.t*1.3)*.012}
  xf.antL.r=Math.sin(e.t*3)*.16-e.vx/1400;xf.antR.r=Math.sin(e.t*3+1.7)*.16-e.vx/1400;
  if(!e.onGround){xf.armL.r=-.5;xf.armR.r=.5;xf.armL.y=2;xf.armR.y=2;xf.legL.r=-.2;xf.legR.r=.2;R.sy=1.05;R.sx=.97}
  if(e.state==='tel'){const u=prog(e);R.sy=1-.08*u;R.x=Math.sin(e.t*70)*1.2;xf.armL.r=-DN+(DN+.5)*u;xf.armR.r=DN-(DN+.5)*u;xf.armL.y=AY*(1-u);xf.armR.y=AY*(1-u)}
  else if(e.state==='atk'){const u=prog(e);xf.armL.r=.5-(DN+.5)*Math.min(1,u*1.6);xf.armR.r=-.5+(DN+.5)*Math.min(1,u*1.6);xf.armL.y=AY*Math.min(1,u*1.6);xf.armR.y=AY*Math.min(1,u*1.6);B.r=e.face*.12;R.x=e.face*7*Math.sin(u*Math.PI)}
  if(e.hurtT>.14){R.sx=1.08;R.sy=.92}
  if(e.landSq>0){R.sy*=1-e.landSq;R.sx*=1+e.landSq*.8}
  if(e.spawnT>0){const u=1-e.spawnT/.6;R.y=(1-u)*36;R.sy=.35+.65*u}
  return{xf,flip:1};
};
POSE.fly=e=>{
  const xf={root:{x:0,y:0,sx:1,sy:1},body:{x:0,y:0,r:0},head:{r:0,y:0},legL:{r:0,y:0},legR:{r:0,y:0}};
  const R=xf.root,Hd=xf.head;
  if(e.spawnT>0){const u=1-e.spawnT/.6;R.y=(1-u)*36;R.sy=.35+.65*u;return{xf,flip:e.face>0?1:-1}}
  if(e.onGround){
    xf.body.y=-Math.sin(e.t*2.2)*1.4;Hd.r=Math.sin(e.t*2.2)*.07;xf.legL.r=Math.sin(e.t*3)*.05;xf.legR.r=-Math.sin(e.t*3+1)*.05;
    if(Math.abs(P.x-e.x)<230)Hd.r+=Math.sin(e.t*13)*.08;
    if(e.jcd>0&&e.jcd<.3&&e.state==='move'){R.sy=.9;R.sx=1.06;Hd.r=-.14}
    R.sy*=1-e.landSq;R.sx*=1+e.landSq*.8;
  }else{Hd.r=.24;R.sy=1.06;R.sx=.95;xf.legL.r=-.38+Math.sin(e.t*14)*.05;xf.legR.r=.34-Math.sin(e.t*14)*.05;xf.body.r=clamp(e.vy/2500,-.1,.1)}
  if(e.state==='tel'){const u=prog(e);Hd.r=-.35*u;R.sy=1-.1*u;R.sx=1+.06*u}
  else if(e.state==='atk'){Hd.r=.35;R.x=8}
  else if(e.state==='rec'){Hd.r=.1}
  if(e.hurtT>.14)Hd.r-=.2;
  return{xf,flip:e.face>0?1:-1};
};
POSE.drone=e=>{
  const xf={root:{x:0,y:Math.sin(e.t*2.4)*4,sx:1,sy:1,r:clamp(e.vx/800,-.25,.25),rp:.5},body:{},rotor:{sx:.45+.55*Math.abs(Math.sin(e.t*40)),sy:1}};
  if(e.state==='tel'||e.state==='dive'){xf.root.x=Math.sin(e.t*60)*1.5}
  if(e.recoil>0)xf.root.x=-e.face*6*(e.recoil/.2);
  if(e.hurtT>.14)xf.root.r+=Math.sin(e.t*50)*.2;
  if(e.state==='dive')xf.root.r=e.face*.5;
  if(e.spawnT>0){const u=1-e.spawnT/.6;xf.root.sy=.4+.6*u}
  return{xf,flip:e.face>0?1:-1};
};
POSE.rat=e=>{
  const xf={root:{x:0,y:0,sx:1,sy:1},body:{x:0,y:0,r:0},head:{r:0,y:0},legsF:{r:0,y:0},legsB:{r:0,y:0}};
  const R=xf.root,B=xf.body,s=Math.sin(e.ph);
  if(e.spawnT>0){const u=1-e.spawnT/.6;R.y=(1-u)*30;R.sy=.35+.65*u;return{xf,flip:e.face>0?1:-1}}
  if(e.state==='atk'||!e.onGround){B.r=clamp(e.vy/1800,-.35,.4);xf.legsF.r=-.7;xf.legsB.r=.7;xf.head.r=-.1;R.sy=1.05;R.sx=.97}
  else if(e.state==='tel'){const u=prog(e);R.sy=1-.2*u;R.sx=1+.12*u;xf.head.r=.1*u;R.x=-3*u;xf.legsB.r=.3*u}
  else if(e.state==='rec'){R.sy=.92;xf.head.r=Math.sin(e.t*22)*.1;B.y=2}
  else if(Math.abs(e.vx)>10){xf.legsF.r=s*.6;xf.legsB.r=-s*.6;xf.legsF.y=-Math.max(0,s)*5;xf.legsB.y=-Math.max(0,-s)*5;B.y=-Math.abs(s)*3.5;B.r=s*.04;xf.head.r=Math.sin(e.ph*2)*.07}
  else{B.y=Math.sin(e.t*3)*1;xf.head.r=Math.sin(e.t*2)*.08}
  if(e.landSq>0){R.sy*=1-e.landSq;R.sx*=1+e.landSq*.8}
  if(e.hurtT>.14){R.sx=1.1;R.sy=.9}
  return{xf,flip:e.face>0?1:-1};
};
POSE.spider=e=>{
  const xf={root:{x:0,y:0,sx:1,sy:1},body:{x:0,y:0,r:0},legL:{r:0,y:0},legR:{r:0,y:0}};
  const R=xf.root,B=xf.body,s=Math.sin(e.ph);
  if(e.spawnT>0){const u=1-e.spawnT/.6;R.y=(1-u)*34;R.sy=.35+.65*u;return{xf,flip:e.face>0?1:-1}}
  if(Math.abs(e.vx)>8&&e.onGround){xf.legL.r=s*.26;xf.legR.r=-s*.26;xf.legL.y=-Math.max(0,s)*6;xf.legR.y=-Math.max(0,-s)*6;B.y=-Math.abs(s)*3;B.r=s*.025}
  else{B.y=Math.sin(e.t*2.4)*1;xf.legL.r=Math.sin(e.t*2)*.04;xf.legR.r=-Math.sin(e.t*2+1)*.04}
  if(e.state==='tel'||e.state==='cargo'){const u=prog(e);B.r=-.22*Math.min(1,u*2);R.y=-4;xf.legL.r=.25;xf.legR.r=-.25;R.x=Math.sin(e.t*50)*1.2*u}
  else if(e.state==='atk'||e.state==='stab'){const u=prog(e);R.x=18*Math.sin(u*Math.PI);B.r=.12;xf.legR.r=-.5*Math.sin(u*Math.PI)}
  if(e.state==='dash'){B.r=.1;xf.legL.r=Math.sin(e.t*40)*.3;xf.legR.r=-Math.sin(e.t*40)*.3}
  if(e.dying==='boom'){const u=prog(e);R.x=Math.sin(e.t*(40+60*u))*(1+3*u);R.sx=1+.07*u*Math.sin(e.t*30);R.sy=1+.05*u}
  if(e.hurtT>.14){R.sx=1.07;R.sy=.93}
  if(e.landSq>0){R.sy*=1-e.landSq;R.sx*=1+e.landSq*.8}
  return{xf,flip:e.face>0?1:-1};
};
POSE.spit=e=>{
  const xf={root:{x:0,y:0,sx:1,sy:1},body:{x:0,y:0,r:0},head:{r:0,y:0}};
  const R=xf.root,B=xf.body,s=Math.sin(e.ph);
  if(e.spawnT>0){const u=1-e.spawnT/.6;R.y=(1-u)*34;R.sy=.35+.65*u;return{xf,flip:e.face>0?1:-1}}
  if(Math.abs(e.vx)>6&&e.onGround){B.r=s*.045;B.y=-Math.abs(s)*3;xf.head.r=Math.sin(e.ph*2)*.07;R.sx=1+Math.abs(s)*.015}
  else{const br=Math.sin(e.t*2);R.sy=1+br*.016;xf.head.r=br*.05}
  if(e.state==='tel'||e.state==='spit3'||e.state==='rain'){const u=prog(e);xf.head.r=-.4*Math.min(1,u*2);R.sy=1-.06*u;R.x=-4*u}
  else if(e.state==='atk'){xf.head.r=.28;R.x=10}
  else if(e.state==='rec'){xf.head.r=.1}
  else if(e.state==='roar'||e.state==='rocks'){xf.head.r=-.5+Math.sin(e.t*40)*.04;R.sx=1.06;R.sy=.97;R.x=Math.sin(e.t*60)*1.5}
  if(!e.onGround){R.sy=1.05;xf.head.r=-.2}
  if(e.hurtT>.14){R.sx=1.07;R.sy=.93;xf.head.r+=.1}
  if(e.landSq>0){R.sy*=1-e.landSq}
  return{xf,flip:e.face>0?1:-1};
};
POSE.golem=e=>{
  const t=e.t,xf={root:{x:0,y:0,sx:1,sy:1,r:0,rp:1},body:{x:0,y:0,r:0,sx:1,sy:1},lotus:{r:0,sx:1,sy:1,y:0},vineL:{r:0},vineR:{r:0},armL:{r:0},armR:{r:0},legL:{r:0,y:0},legR:{r:0,y:0}};
  const R=xf.root,B=xf.body,Lo=xf.lotus,u=prog(e),fc=e.face;
  if(e.spawnT>0){const k=1-e.spawnT/1.6;R.y=(1-k)*140;R.sy=.5+.5*k;return{xf,flip:1}}
  const br=Math.sin(t*1.8);B.sy=1+br*.01;Lo.r=Math.sin(t*1.3)*.04;xf.vineL.r=Math.sin(t*1.6)*.07;xf.vineR.r=-Math.sin(t*1.6+.5)*.07;xf.armL.r=Math.sin(t*1.4)*.04;xf.armR.r=-Math.sin(t*1.4+1)*.04;
  const st=e.state;
  if(st==='walk'){
    if(Math.abs(e.vx)>8){const s=Math.sin(e.ph);xf.legL.r=s*.1;xf.legR.r=-s*.1;xf.legL.y=-Math.max(0,s)*5;xf.legR.y=-Math.max(0,-s)*5;B.y=-Math.abs(s)*4;B.r=s*.015+fc*.015;xf.armL.r=-s*.05;xf.armR.r=-s*.05}
  }else if(st==='intro'){const k=Math.min(1,u*1.5);xf.armL.r=1.6*smo(k)*(1-u*.6);xf.armR.r=-1.6*smo(k)*(1-u*.6);Lo.sx=Lo.sy=1+.2*Math.sin(u*Math.PI);B.x=Math.sin(t*50)*1.5}
  else if(st==='slam'){
    const k=smo(clamp(u/.42,0,1)),d=clamp((u-.5)/.1,0,1),rc=clamp((u-.65)/.35,0,1);
    const a=1.3*k*(1-d)-.1*d*(1-rc);
    xf.armL.r=a;xf.armR.r=-a;B.r=-fc*.1*k*(1-d)+fc*.08*d*(1-rc);B.sy=1+.03*k*(1-d)-.06*d*(1-rc);Lo.y=-5*k*(1-d);
  }else if(st==='leap'){
    const k=clamp(u/.34,0,1);
    if(!e.leaping&&!e.fired){R.sy=1-.14*k;R.sx=1+.07*k;xf.legL.r=.2*k;xf.legR.r=-.2*k;xf.armL.r=-.3*k;xf.armR.r=.3*k}
    else{R.sy=1.06;R.sx=.96;xf.armL.r=1.3;xf.armR.r=-1.3;xf.legL.r=.15;xf.legR.r=-.15;B.r=clamp(e.vy/3000,-.1,.12)*fc}
  }else if(st==='rec'){const k=1-prog(e);R.sy=1-.08*k;R.sx=1+.05*k;xf.armL.r=-.2*k;xf.armR.r=.2*k}
  else if(st==='bombs'){
    const k=smo(clamp(u/.35,0,1));
    xf.vineL.r=.4*k-.9*clamp((u-.4)*4,0,1)*Math.abs(Math.sin(u*14));xf.vineR.r=-.4*k+.9*clamp((u-.4)*4,0,1)*Math.abs(Math.sin(u*14));
    xf.armL.r=.5*k;xf.armR.r=-.5*k;B.r=-fc*.05*k;Lo.sx=Lo.sy=1+.12*k;
  }else if(st==='beam'){
    const k=smo(clamp(u/.45,0,1));xf.armL.r=.55*k;xf.armR.r=-.55*k;B.x=Math.sin(t*(u<.5?30:80))*(u<.5?1:2);B.sy=1-.03*k;Lo.sx=Lo.sy=1+.12*k;B.r=-fc*.05*k;
  }else if(st==='spikes'){
    const k=smo(clamp(u/.25,0,1)),d=clamp((u-.3)/.1,0,1);const a=1.3*k*(1-d)-.1*d;xf.armL.r=a;xf.armR.r=-a;B.sy=1+.02*k-.05*d*(1-clamp((u-.5)*3,0,1));B.r=-fc*.06*k*(1-d)
  }else if(st==='dying'){
    B.x=Math.sin(t*50)*(2+6*u);B.r=Math.sin(t*20)*.03*u;xf.armL.r=-.6*u;xf.armR.r=.6*u;Lo.r=-.5*u;Lo.y=14*u;Lo.sx=Lo.sy=1-.3*u;xf.vineL.r=-.8*u;xf.vineR.r=.8*u;R.sy=1-.1*u;R.y=8*u
  }
  if(e.hurtT>.1&&st!=='dying'){B.x+=Math.sin(t*90)*2;Lo.r+=.08}
  return{xf,flip:1};
};
/* ---------- drawing ---------- */
const DEFV={sx:1,sy:1};
let RDT=.016;
function smoothXF(o,xf,rate){
  const a=1-Math.exp(-RDT*(rate||18)),sm=o._sm||(o._sm={});
  for(const k in xf){
    const t=xf[k],s=sm[k]||(sm[k]={});
    for(const f in t){
      const c=s[f]===undefined?t[f]:s[f];
      if(Math.abs(t[f])>3||Math.abs(c)>3)s[f]=t[f];else s[f]=c+(t[f]-c)*a;
    }
    for(const f in s)if(!(f in t)){const d=DEFV[f]===undefined?0:DEFV[f];s[f]+=(d-s[f])*a}
  }
  return sm;
}
function drawEnemies(c0,c1){
  const add=Qe.glow;
  for(const e of enemies){
    if(e.x<c0-300||e.x>c1+300)continue;
    const D=ED[e.type],rig=RIG[D.rig],sc=e.dw/rig.w,pz=(POSE[e.type]||POSE[D.base])(e);
    const xf=smoothXF(e,pz.xf,e.frozen>0?1:18);
    let alpha=e.spawnT>0?clamp(1-e.spawnT/(e.boss?1.6:.6),0,1):1,flash=e.flash>0?Math.min(.8,e.flash*6):0,fc='255,255,255';
    if(e.state==='tel'&&!e.boss&&((e.st*12)|0)%2)flash=.4;
    if(e.dying==='boom'&&((e.t*(8+14*prog(e)))|0)%2)flash=.7;
    if(e.dying==='boss'&&((e.t*16)|0)%2)flash=.5;
    if(e.type==='drone'&&e.alarm>0&&((e.t*10)|0)%2)flash=.45;
    if(e.frozen>0){flash=.55;fc='120,210,255'}
    if(e.state==='stun'&&((e.t*8)|0)%2){flash=.25;fc='255,230,120'}
    if(!e.fly)drawShadow(e.x,e.y,e.hw*1.1,alpha);
    else if(Qe.shadows){const gy=floorBelow(e.x,e.y);if(gy!==null){ctx.globalAlpha=.3;ctx.drawImage(GL.shadow,e.x-40,gy-4,80,10);ctx.globalAlpha=1}}
    const B=e.dw>200?BUFS.xl:BUFS.l,oy=e.y+(e.fly?e.hh*.1:0);
    if(alpha<1||flash>0)drawBuffered(B,e.x,oy,alpha,flash,(g,cx,by)=>drawRig(g,rig,cx,by,sc,pz.flip,xf),fc);
    else drawRig(ctx,rig,e.x,oy,sc,pz.flip,xf);
    if(e.spawnT<=0)drawEnemyFX(e,xf,add);
    if(e.hp<e.maxhp&&!e.boss&&!e.dying){
      ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(e.x-22,e.y-e.dh-8,44,5);
      ctx.fillStyle='#e8543a';ctx.fillRect(e.x-21,e.y-e.dh-7,42*e.hp/e.maxhp,3);
    }
  }
  for(const h of haz)drawHaz(h);
  for(const q of eproj)drawEProj(q);
}
const EYE={rat:[[.782,.156,'r',1]],spider:[[.585,.566,'r',1.1]],spit:[[.598,.139,'r',1],[.691,.104,'r',.8]],beetle:[[.495,.423,'o',1],[.423,.433,'o',.55],[.577,.433,'o',.55]],drone:[[.609,.49,'o',1.1]]};
function eyeGlows(e,a,scale){
  const b=ED[e.type].base||e.type,L=EYE[b];if(!L)return;
  const flip=b==='beetle'?1:(e.face>0?1:-1),oy=e.y+(e.fly?e.hh*.1:0);
  ctx.globalCompositeOperation='lighter';
  for(const [fx,fy,c,s] of L){
    const x=e.x+(fx-.5)*e.dw*flip,y=oy-(1-fy)*e.dh,r=e.dw*.09*s*(scale||1);
    ctx.globalAlpha=a;ctx.drawImage(c==='r'?GL.red:GL.orange,x-r,y-r,r*2,r*2);
  }
  ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
}
function drawEnemyFX(e,xf,add){
  const dw=e.dw,pu=.7+.3*Math.sin(e.t*5+e.ph),b=ED[e.type].base||e.type;
  if(add&&!e.boss)eyeGlows(e,.38+.14*Math.sin(e.t*5+e.ph),1);
  if(false){
    const by=e.y-e.dh*.6+(xf.body.y||0);ctx.globalCompositeOperation='lighter';ctx.globalAlpha=pu*.65;
    ctx.drawImage(GL.orange,e.x-dw*.13,by-dw*.13,dw*.26,dw*.26);ctx.drawImage(GL.orange,e.x-dw*.22,by-dw*.05,dw*.1,dw*.1);ctx.drawImage(GL.orange,e.x+dw*.12,by-dw*.05,dw*.1,dw*.1);
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }else if(b==='fly'&&e.tl>4){
    const mp=mouthPos(e,xf),mx=mp.x,my=mp.y,tx=mx+e.face*e.tl,th=e.boss?16:9;
    ctx.strokeStyle='#b0243a';ctx.lineWidth=th;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(mx,my);ctx.quadraticCurveTo((mx+tx)/2,my+Math.sin(e.t*30)*8,tx,my);ctx.stroke();
    ctx.strokeStyle='#e8547a';ctx.lineWidth=th*.45;ctx.stroke();
    ctx.fillStyle='#8a1a30';ctx.beginPath();ctx.moveTo(tx,my);ctx.lineTo(tx-e.face*th*1.1,my-th);ctx.lineTo(tx-e.face*th*1.1,my+th);ctx.fill();
  }else if(b==='drone'&&add){
    ctx.globalCompositeOperation='lighter';
    const lx=e.x+e.face*e.dw*.26,ly=e.y-e.hh*.4,c=GL.orange;
    ctx.globalAlpha=e.state==='tel'?.5+.5*prog(e):0;ctx.drawImage(c,lx-22,ly-22,44,44);
    if(e.state==='tel'){ctx.globalAlpha=prog(e);ctx.drawImage(GL.yellow,lx-34,ly-34,68,68)}
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }else if(false){
    ctx.globalCompositeOperation='lighter';ctx.globalAlpha=(.5+.4*Math.sin(e.t*6))*(e.dying?1.5:1);
    ctx.drawImage(GL.red,e.x+e.face*e.dw*.2-14*(e.boss?2:1),e.y-e.hh*.38-14*(e.boss?2:1),28*(e.boss?2:1),28*(e.boss?2:1));ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }else if(false){
    ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.55;ctx.drawImage(GL.red,e.x+e.face*e.dw*.3-9,e.y-e.hh*.7-9,18,18);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  if(e.type==='golem'){
    const dh=e.dh,cx=e.x,cy=e.y-dh*.6+(xf.body.y||0);
    ctx.globalCompositeOperation='lighter';
    const ch=e.state==='beam'?clamp(prog(e)/.5,0,1.2):0,pz=.8+.2*Math.sin(e.t*5);
    ctx.globalAlpha=Math.min(1,.55*pz+ch);const r=44+ch*80;ctx.drawImage(GL.green,cx-r,cy-r,r*2,r*2);
    ctx.globalAlpha=.6+.3*pz;
    for(const [fx,fy] of [[-.43,.2],[-.34,.28],[.43,.2],[.34,.28]]){ctx.drawImage(GL.orange,cx+fx*e.dw-24,e.y-dh+dh*fy-24+(xf.body.y||0),48,48)}
    ctx.drawImage(GL.orange,cx-60,e.y-dh*.9-30+(xf.lotus.y||0),120,100);
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }
  if(e.beam){
    const bm=e.beam;ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
    const x2=bm.x+bm.dir*bm.len;
    if(bm.on){const j=Math.sin(e.t*90)*3;
      ctx.strokeStyle='rgba(120,255,60,.35)';ctx.lineWidth=46+j;ctx.beginPath();ctx.moveTo(bm.x,bm.y);ctx.lineTo(x2,bm.y);ctx.stroke();
      ctx.strokeStyle='rgba(210,255,140,.85)';ctx.lineWidth=22+j;ctx.stroke();ctx.strokeStyle='#fff';ctx.lineWidth=8;ctx.stroke()}
    else{ctx.strokeStyle='rgba(255,70,50,'+(.35+.3*Math.sin(e.t*30))+')';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(bm.x,bm.y);ctx.lineTo(x2,bm.y);ctx.stroke()}
    ctx.globalCompositeOperation='source-over';
  }
  if(e.dying==='boss'&&e.type!=='drone'){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=prog(e)*.5;ctx.drawImage(GL.white,e.x-e.hw,e.y-e.dh,e.hw*2,e.dh);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
  if(e.frozen>0){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.35;ctx.drawImage(GL.blue,e.x-e.hw*.7,e.y-e.hh,e.hw*1.4,e.hh);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over'}
}
function drawEProj(q){
  if(q.delay>0)return;
  ctx.globalCompositeOperation='lighter';
  if(q.k==='bolt'){ctx.drawImage(GL.orange,q.x-20,q.y-20,40,40);ctx.drawImage(GL.yellow,q.x-10,q.y-10,20,20)}
  else if(q.k==='shard'){ctx.drawImage(GL.blue,q.x-22,q.y-22,44,44)}
  else if(q.k==='acid'){ctx.drawImage(GL.green,q.x-24,q.y-24,48,48)}
  else if(q.k==='spore'){ctx.drawImage(GL.red,q.x-26,q.y-26,52,52)}
  else{ctx.drawImage(GL.orange,q.x-34,q.y-34,68,68);ctx.drawImage(GL.yellow,q.x-14,q.y-14,28,28)}
  ctx.globalCompositeOperation='source-over';
  if(q.k==='acid'){ctx.fillStyle='#5acf2a';ctx.beginPath();ctx.arc(q.x,q.y,10,0,7);ctx.fill();ctx.fillStyle='#b8ff7a';ctx.beginPath();ctx.arc(q.x-3,q.y-3,4,0,7);ctx.fill()}
  else if(q.k==='spore'){ctx.fillStyle='#d85ac8';ctx.beginPath();ctx.arc(q.x,q.y,11,0,7);ctx.fill();ctx.fillStyle='#ffc8f4';ctx.beginPath();ctx.arc(q.x-3,q.y-3,4,0,7);ctx.fill()}
  else if(q.k==='bolt'){ctx.fillStyle='#fff3b0';ctx.beginPath();ctx.arc(q.x,q.y,5,0,7);ctx.fill()}
  else if(q.k==='shard'){ctx.save();ctx.translate(q.x,q.y);ctx.rotate(Math.atan2(q.vy,q.vx));ctx.fillStyle='#bff2ff';ctx.beginPath();ctx.moveTo(14,0);ctx.lineTo(-8,-6);ctx.lineTo(-4,0);ctx.lineTo(-8,6);ctx.fill();ctx.restore()}
  else if(q.k==='crate'){ctx.save();ctx.translate(q.x,q.y);ctx.rotate(q.x*.05);ctx.fillStyle='#8a5a30';ctx.fillRect(-12,-12,24,24);ctx.strokeStyle='#3a2410';ctx.lineWidth=2;ctx.strokeRect(-12,-12,24,24);ctx.beginPath();ctx.moveTo(-12,-12);ctx.lineTo(12,12);ctx.stroke();ctx.restore()}
  else{ctx.fillStyle='#c42a3a';ctx.beginPath();ctx.moveTo(q.x,q.y+12);ctx.quadraticCurveTo(q.x-14,q.y-2,q.x,q.y-12);ctx.quadraticCurveTo(q.x+14,q.y-2,q.x,q.y+12);ctx.fill();ctx.fillStyle='#ffb347';ctx.beginPath();ctx.arc(q.x,q.y+5,5,0,7);ctx.fill()}
}
function drawHaz(h){
  if(h.k==='puddle'||h.k==='fire'){
    const a=Math.min(1,h.life*1.2),w=h.w*(.9+.1*Math.sin(h.t*6));
    ctx.globalAlpha=a*.85;ctx.fillStyle=h.k==='fire'?'#ff7a2a':'#4aae2a';ctx.beginPath();ctx.ellipse(h.x,h.y-3,w/2,7,0,0,7);ctx.fill();
    ctx.fillStyle=h.k==='fire'?'#ffd36b':'#a8f06a';ctx.beginPath();ctx.ellipse(h.x,h.y-4,w/3,4,0,0,7);ctx.fill();
    if(Qe.glow){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=a*.5;ctx.drawImage(h.k==='fire'?GL.orange:GL.green,h.x-w*.6,h.y-34,w*1.2,50);ctx.globalCompositeOperation='source-over'}
    ctx.globalAlpha=1;
  }else if(h.k==='cloud'){
    ctx.globalCompositeOperation='lighter';ctx.globalAlpha=Math.min(.55,h.life*.4);
    for(let i=0;i<4;i++)ctx.drawImage(GL.red,h.x-h.w/2+i*h.w/4-30+Math.sin(h.t*2+i)*8,h.y-95+Math.cos(h.t*1.6+i)*8,90,90);
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }else if(h.k==='mark'){
    const a=.18+.18*Math.sin(h.t*14);ctx.fillStyle='rgba(255,60,40,'+a+')';ctx.beginPath();ctx.ellipse(h.x,h.y-3,h.w/2,6,0,0,7);ctx.fill();
    ctx.strokeStyle='rgba(255,90,60,'+(a+.25)+')';ctx.lineWidth=2;ctx.stroke();
  }else if(h.k==='mine'){
    ctx.fillStyle='#2a2a2e';ctx.beginPath();ctx.ellipse(h.x,h.y-5,16,7,0,0,7);ctx.fill();ctx.fillStyle='#4a4a52';ctx.fillRect(h.x-10,h.y-12,20,7);
    const on=h.t>1?((h.t*5)|0)%2:0;ctx.fillStyle=on?'#ff3a2a':'#5a1a14';ctx.beginPath();ctx.arc(h.x,h.y-13,3.5,0,7);ctx.fill();
  }else if(h.k==='laser'){
    if(h.warn){ctx.fillStyle='rgba(255,60,50,'+(.25+.25*Math.sin(h.t*30))+')';ctx.fillRect(h.x-2,0,4,h.y)}
    else if(h.on){ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,70,40,.45)';ctx.fillRect(h.x-16,0,32,h.y);ctx.fillStyle='rgba(255,220,180,.9)';ctx.fillRect(h.x-5,0,10,h.y);ctx.globalCompositeOperation='source-over'}
    ctx.fillStyle='#2a2428';ctx.fillRect(h.x-12,0,24,10);ctx.fillRect(h.x-14,h.y-6,28,8);
  }else if(h.k==='wave'){
    ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.8;ctx.drawImage(GL.yellow,h.x-36,h.y-44,72,60);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
    ctx.fillStyle='#9a7a4a';ctx.beginPath();ctx.moveTo(h.x-22,h.y);ctx.lineTo(h.x-h.dir*6,h.y-34);ctx.lineTo(h.x+22,h.y);ctx.fill();
  }else if(h.k==='root'){
    if(h.t<h.warn){ctx.fillStyle='rgba(60,40,20,.55)';ctx.beginPath();ctx.ellipse(h.x,h.y-2,18+8*Math.sin(h.t*30),5,0,0,7);ctx.fill();ctx.fillStyle='rgba(255,60,40,'+(.15+.15*Math.sin(h.t*14))+')';ctx.beginPath();ctx.ellipse(h.x,h.y-3,26,6,0,0,7);ctx.fill()}
    else if(h.t<h.warn+h.act){
      const k=Math.min(1,(h.t-h.warn)/.12),hh=105*k*(1-clamp((h.t-h.warn-h.act+.15)/.15,0,1));
      ctx.fillStyle='#5a3a1c';ctx.beginPath();ctx.moveTo(h.x-16,h.y);ctx.quadraticCurveTo(h.x-6,h.y-hh*.6,h.x,h.y-hh);ctx.quadraticCurveTo(h.x+8,h.y-hh*.5,h.x+16,h.y);ctx.fill();
      ctx.strokeStyle='#5aa62f';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(h.x-8,h.y);ctx.quadraticCurveTo(h.x+4,h.y-hh*.5,h.x,h.y-hh*.9);ctx.stroke();
    }
  }else if(h.k==='rock'){
    const fy=floorBelow(h.x,0);
    if(!h.fell&&h.t>=0&&fy!==null){const k=clamp(h.t/h.warn,0,1);ctx.globalAlpha=.25+.4*k;ctx.fillStyle='#000';ctx.beginPath();ctx.ellipse(h.x,fy-2,10+26*k,4+5*k,0,0,7);ctx.fill();ctx.fillStyle='rgba(255,60,40,'+(.2+.15*Math.sin(h.t*14))+')';ctx.beginPath();ctx.ellipse(h.x,fy-3,34,6,0,0,7);ctx.fill();ctx.globalAlpha=1}
    if(h.fell){ctx.fillStyle='#6a5a4a';ctx.beginPath();ctx.moveTo(h.x-18,h.y-6);ctx.lineTo(h.x-6,h.y-22);ctx.lineTo(h.x+14,h.y-16);ctx.lineTo(h.x+20,h.y+4);ctx.lineTo(h.x,h.y+14);ctx.lineTo(h.x-16,h.y+8);ctx.fill();ctx.fillStyle='#8a7a68';ctx.beginPath();ctx.moveTo(h.x-6,h.y-22);ctx.lineTo(h.x+14,h.y-16);ctx.lineTo(h.x+2,h.y-6);ctx.fill()}
  }
}

