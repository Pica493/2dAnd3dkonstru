'use strict';
/* ---------- state ---------- */
let LV=null,P=null,cam=0,mode='menu';
let enemies=[],proj=[],parts=[],texts=[],fx=[],deb=[],flies=[],drift=[];
const G={lv:0,wave:0,ws:'prep',wt:0,queue:[],sq:0,open:false,time:0,score:0,coins:0,totalCoins:0,orbs:0,kills:0,trauma:0,hitstop:0,slow:0,fade:0,hurtFlash:0,banner:null,overT:0,
  up:{hp:5,en:100,dmg:0,spd:0,mag:0,reg:0,nHp:0,nEn:0},lvCoins:0,hint:0,wavePop:0,coinPop:0,kits:0,gems:0,killed:{},cleared:{},tbanner:null};
const DIFF=[{hp:.7,sp:.85,en:1.35,inv:1.9,cnt:.7,loot:1.25},{hp:1,sp:1,en:1,inv:1.4,cnt:1,loot:1},{hp:1.45,sp:1.15,en:.8,inv:1.1,cnt:1.35,loot:.85}];
const keys={},tch={left:0,right:0,jump:0,attack:0};
let jumpPrev=false;
const inp={left:false,right:false,jump:false,attack:false,jumpPressed:false};
const down=a=>{const b=CFG.binds[a];if(!b)return false;for(let i=0;i<b.length;i++)if(keys[b[i]])return true;return false};
function addShake(v){G.trauma=Math.min(1,G.trauma+v/16*(CFG.shake/100))}
function stop(t){G.hitstop=Math.max(G.hitstop,t)}
function loadProg(){try{const s=JSON.parse(store.get('sprout.prog')||'null');if(s){G.cleared=s.cleared||{};G.killed=s.killed||{};G.totalCoins=s.tc||0}}catch(e){}}
function saveProg(){store.set('sprout.prog',JSON.stringify({cleared:G.cleared,killed:G.killed,tc:G.totalCoins}))}
const WEAPS=[{id:'whip',from:0,ico:'whip',cost:0},{id:'pistol',from:0,ico:'pistol',cost:8},{id:'nade',from:0,ico:'nade',cost:35}];
const ABIL=[];
const has=a=>G.lv>=a.from;
const UNLOCK=[];

/* ---------- particles ---------- */
function burst(x,y,n,cols,sp,life,grav,size,add){
  n=Math.max(1,Math.round(n*Qe.pm));if(parts.length>700*Qe.pm+60)return;
  for(let i=0;i<n;i++){const a=Math.random()*6.283,v=rnd(.2,1)*sp;parts.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-sp*.25,life:rnd(.5,1)*life,max:life,g:grav,s:rnd(.6,1)*size,c:cols[(Math.random()*cols.length)|0],add:!!add})}
}
function leafBurst(x,y,n){
  n=Math.max(1,Math.round(n*Qe.pm));
  for(let i=0;i<n;i++){const a=Math.random()*6.283,v=rnd(60,220);parts.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-120,life:rnd(.6,1.1),max:1.1,g:420,s:rnd(3,5),c:['#79c943','#a8e85a','#4f9b2a'][(Math.random()*3)|0],leaf:true,rot:rnd(0,6),vr:rnd(-8,8)})}
}
function ring(x,y,col,max,life){fx.push({x,y,r:6,max,t:0,life:life||.4,c:col||'#b6ff5a'})}
function ftext(x,y,s,col){texts.push({x,y,s,col:col||'#fff',t:0})}
function dmgText(x,y,v,col){if(CFG.dmgnum)texts.push({x:x+rnd(-8,8),y,s:'-'+v,col:col||'#fff3a0',t:0,big:true})}
function banner(title,sub){G.banner={t:0,title,sub:sub||''}}
function spawnDebris(rig,x,y,scale,flip,power){
  const add=(c,cx,cy,w,h)=>{deb.push({c,x:x+cx,y:y+cy,vx:(cx*3+rnd(-60,60))*power,vy:-rnd(150,380)*power,r:0,vr:rnd(-7,7),life:rnd(.9,1.5),max:1.5,w,h,flip})};
  add(rig.base,0,-rig.h*scale*.5,rig.w*scale,rig.h*scale);
  for(const n in rig.parts){const p=rig.parts[n];if(n==='legB')continue;add(p.c,(p.x+p.c.width/2-rig.w/2)*scale*flip,(p.y+p.c.height/2-rig.h)*scale,p.c.width*scale,p.c.height*scale)}
}
/* ---------- bodies ---------- */
function moveBody(b,dt,hw){
  b.x+=b.vx*dt;
  const prev=b.y;
  b.vy=Math.min(b.vy+GRAV*dt,1100);
  b.y+=b.vy*dt;
  b.onGround=false;b.solid=null;
  if(b.vy>=0){
    for(const s of LV.solids){
      if(b.x+hw>s.x&&b.x-hw<s.x+s.w&&prev<=s.y+3&&b.y>=s.y){b.y=s.y;b.vy=0;b.onGround=true;b.solid=s;break}
    }
  }
}
function updatePlats(dt){
  for(const s of LV.plats){if(!s.mv)continue;const nx=s.x0+Math.sin(G.time*s.mv.sp+s.mv.ph)*s.mv.ax;s.dx=nx-s.x;s.x=nx}
}
/* ---------- game flow ---------- */
function resetRun(){G.up={hp:5,en:100,dmg:0,spd:0,mag:0,reg:0,nHp:0,nEn:0};G.coins=0;G.score=0;G.kits=0;G.gems=0}
function startLevel(i){
  hidePanel();
  LV=buildLevel(i);G.lv=i;buildLayers(LV.theme);
  P={x:110,y:GY,vx:0,vy:0,face:1,hp:G.up.hp,maxHp:G.up.hp,en:G.up.en,maxEn:G.up.en,onGround:false,jumps:0,coyote:0,buffer:0,inv:1.2,kb:0,wcd:0,whipOn:false,whipT:0,hit:new Set(),weapon:0,jcut:false,t:0,lastSafe:110,solid:null,
    runPh:0,lastStep:0,landSq:0,stretch:0,shootT:0,throwT:0,hurtT:0,djT:0,jetT:0,pvy:0,dead:false,henS:G.up.en,dashT:0,dashCd:0,shieldT:0,shieldHits:0,novaCd:0,medCd:0,allyT:0,ally:null,recoil:0};
  enemies=[];proj=[];parts=[];texts=[];fx=[];deb=[];eproj=[];haz=[];
  if(LV.lasers)for(const l of LV.lasers)addHaz({k:'laser',x:l.x,y:GY,t:l.ph*1.5,cyc:4.5});
  flies=[];for(let k=0;k<70;k++)flies.push({x:rnd(0,LV.world),y:rnd(60,470),ph:rnd(0,6.28),sp:rnd(.3,1)});
  const dr=THEME_DR[LV.theme]||THEME_DR.green;
  drift=[];for(let k=0;k<26;k++){const kind=dr[0];drift.push({x:rnd(0,W),y:rnd(0,H),vx:rnd(-30,-8),vy:kind==='ember'||kind==='bubble'?-rnd(18,50):rnd(14,40),r:rnd(0,6),vr:rnd(-3,3),s:rnd(3,6),c:dr[1][k%dr[1].length],kind})}
  G.wave=0;G.ws='prep';G.wt=4.2;G.queue=[];G.sq=0;G.open=false;G.kills=0;G.lvCoins=0;G.trauma=0;G.hurtFlash=0;G.overT=0;G.hint=0;G.hitstop=0;G.slow=0;G.fade=1;
  cam=0;mode='play';
  banner(L(LV.name),L(LV.sub));
  if(UNLOCK[i])G.tbanner={t:0,s:UNLOCK[i]};else G.tbanner=null;
  $('menu').style.display='none';$('langBtn').style.display='none';cv.style.display='block';$('pauseBtn').style.display='block';
  if(isTouch)$('touch').style.display='block';
  applyTouch();layout();
  if(AC){musicStart(i);musicInt(.3);ambStart(i)}
}
function toMenu(){
  mode='menu';hidePanel();cv.style.display='none';$('touch').style.display='none';$('pauseBtn').style.display='none';$('menu').style.display='block';$('langBtn').style.display='block';layout();
  ambStop();muffle(false);if(AC){musicStart(0)}
}
function hurtPlayer(dmg,fromX){
  if(P.inv>0||P.dashT>0||mode!=='play')return;
  if(P.shieldT>0){P.shieldHits--;P.inv=.5;sfx('shield');ring(P.x,P.y-40,'#7fd8ff',70,.3);burst(P.x,P.y-40,10,['#7fd8ff','#fff'],160,.4,0,3,true);if(P.shieldHits<=0)P.shieldT=0;return}
  P.hp-=dmg;P.inv=DIFF[CFG.diff].inv;P.kb=.2;P.jcut=true;P.hurtT=.4;
  const d=P.x>=fromX?1:-1;P.vx=d*300;P.vy=-300;
  addShake(11);G.hurtFlash=CFG.flash?.45:0;sfx('hurt');vib(60);stop(.07);
  burst(P.x,P.y-40,12,['#ffe45c','#fff'],220,.5,300,3,true);
  if(P.hp<=0){P.hp=0;mode='over';G.overT=0;P.dead=true;sfx('lose');leafBurst(P.x,P.y-40,30);spawnDebris(RIG.hero,P.x,P.y,HERO_H/RIG.hero.h,P.face>0?-1:1,.9);musicInt(0);vib([80,60,160])}
}
function pitFall(){
  P.hp-=1;sfx('pit');addShake(9);G.hurtFlash=CFG.flash?.4:0;vib(80);
  if(P.hp<=0){P.hp=0;mode='over';G.overT=0;P.dead=true;sfx('lose');musicInt(0);return}
  P.x=P.lastSafe;P.y=GY;P.vx=0;P.vy=0;P.inv=1.8;
}
/* ---------- player ---------- */
function dmgOf(w){const d=G.up.dmg;return w==='whip'?1+d:w==='pistol'?1+(d>=2?1:0)+(d>=3?1:0):w==='nade'?3+(d>>1):w==='rocket'?4+d:1+(d>>1)}
function updatePlayer(dt){
  const p=P,UP=G.up;p.t+=dt;
  const dir=(inp.right?1:0)-(inp.left?1:0);
  const slip=LV.slip&&p.onGround;
  const acc=p.onGround?(slip?640:3400):1900,fr=p.onGround?(slip?260:3800):420,MAXV=255*(1+.06*UP.spd);
  p.kb=Math.max(0,p.kb-dt);p.inv=Math.max(0,p.inv-dt);
  p.shootT=Math.max(0,p.shootT-dt);p.throwT=Math.max(0,p.throwT-dt);p.hurtT=Math.max(0,p.hurtT-dt);p.djT=Math.max(0,p.djT-dt);p.jetT=Math.max(0,p.jetT-dt);
  p.dashCd=Math.max(0,p.dashCd-dt);p.novaCd=Math.max(0,p.novaCd-dt);p.medCd=Math.max(0,p.medCd-dt);p.shieldT=Math.max(0,p.shieldT-dt);p.recoil=Math.max(0,p.recoil-dt*5);
  p.landSq=Math.max(0,p.landSq-dt*1.3);p.stretch=Math.max(0,p.stretch-dt*1.6);
  if(p.dashT>0){
    p.dashT-=dt;p.vx=p.face*640;p.vy=-30;
    if(Math.random()<.9)parts.push({x:p.x-p.face*10,y:p.y-30-rnd(-20,20),vx:-p.face*40,vy:rnd(-20,20),life:.3,max:.3,g:0,s:rnd(4,8),c:'#9dff7a',add:true});
  }else if(p.kb<=0){
    if(dir){if(dir*p.vx<MAXV)p.vx+=dir*acc*dt;else p.vx=approach(p.vx,dir*MAXV,fr*dt);p.face=dir}
    else p.vx=approach(p.vx,0,fr*dt);
  }
  if(inp.jumpPressed)p.buffer=.13;else p.buffer=Math.max(0,p.buffer-dt);
  if(p.onGround){p.coyote=.1}else{p.coyote-=dt;if(p.coyote<=0&&p.jumps===0)p.jumps=1}
  if(p.buffer>0){
    if(p.onGround||p.coyote>0){p.vy=-660;p.jumps=1;p.coyote=0;p.onGround=false;p.buffer=0;p.jcut=false;p.stretch=.2;sfx('jump');burst(p.x,p.y,6,['#cfe9a0','#9ac86a'],90,.4,200,2.5)}
    else if(p.jumps<2){p.vy=-570;p.jumps=2;p.buffer=0;p.jcut=false;p.djT=.42;p.jetT=.55;sfx('dj');burst(p.x,p.y,16,['#7fd8ff','#ffffff','#ffb347'],150,.5,100,3,true);ring(p.x,p.y-4,'#9fe4ff',46,.3)}
  }
  if(!inp.jump&&p.vy<-260&&!p.jcut){p.vy*=.55;p.jcut=true}
  p.pvy=p.vy;const wasG=p.onGround;
  moveBody(p,dt,10);
  if(p.onGround&&p.solid&&p.solid.dx)p.x+=p.solid.dx;
  if(p.onGround){
    if(!wasG&&p.pvy>260){p.landSq=Math.min(.26,p.pvy/3400);sfx('land',Math.min(1,p.pvy/900));burst(p.x,p.y,7,['#cfe9a0','#9ac86a','#ffffff'],110,.45,120,2.8)}
    p.jumps=0;
    if(p.solid&&p.solid.ground&&p.x>p.solid.x+60&&p.x<p.solid.x+p.solid.w-60)p.lastSafe=p.x;
    const sp=Math.abs(p.vx);
    if(sp>25){
      p.runPh+=dt*(sp/255)*15;
      const k=Math.floor(p.runPh/Math.PI);
      if(k!==p.lastStep){p.lastStep=k;if(sp>90)sfx('step');}
    }
  }
  const lim=G.open?LV.world-40:LV.world-215;
  p.x=clamp(p.x,16,lim);
  if(p.y>H+110)pitFall();
  if(p.jetT>0&&Math.random()<.7)burst(p.x,p.y-2,1,['#ffb347','#7fd8ff'],70,.3,-100,2.5,true);
  p.wcd-=dt;
  p.en=Math.min(p.maxEn,p.en+7*DIFF[CFG.diff].en*(1+.18*UP.reg)*dt);
  p.henS+=(p.en-p.henS)*(1-Math.exp(-dt*8));
  if(inp.attack&&p.wcd<=0&&mode==='play')fire();
  p.aimHold=Math.max(0,(p.aimHold||0)-dt);
  p.aimT=(p.weapon===1&&(inp.attack||p.aimHold>.2))?(p.aimT||0)+dt:0;
  if(p.whipOn){
    p.whipT+=dt;
    if(p.whipT>.22&&p.whipT<.37){
      const x0=p.x,x1=p.x+p.face*152,lo=Math.min(x0,x1),hi=Math.max(x0,x1);
      for(const e of enemies){
        if(e.dead||p.hit.has(e)||e.spawnT>.25||e.dying)continue;
        const ext=Math.max(e.hh,e.dh*.9);
        if(e.x+e.hw/2+6>lo&&e.x-e.hw/2-6<hi&&e.y>p.y-150&&e.y-ext<p.y+8){
          p.hit.add(e);sfx('whiphit');hitEnemy(e,dmgOf('whip'),p.face*(e.boss?160:380),-230);
        }
      }
    }
    if(p.whipT>.7)p.whipOn=false;
  }
  if(p.allyT>0){
    p.allyT-=dt;const a=p.ally;
    if(a){
      a.t+=dt;a.x+=(p.x-p.face*55-a.x)*(1-Math.exp(-dt*4));a.y+=(p.y-115+Math.sin(a.t*2.4)*8-a.y)*(1-Math.exp(-dt*4));a.cd-=dt;
      if(a.cd<=0){
        let best=null,bd=520;for(const e of enemies){if(e.dead||e.spawnT>0||e.dying)continue;const d=Math.hypot(e.x-a.x,e.y-e.hh/2-a.y);if(d<bd){bd=d;best=e}}
        if(best){const ax=best.x-a.x,ay=best.y-best.hh*.5-a.y,L2=Math.hypot(ax,ay)||1;proj.push({k:'abolt',x:a.x,y:a.y,vx:ax/L2*560,vy:ay/L2*560,life:1,dmg:1+(UP.dmg>>1)});a.cd=.5;sfx('shoot')}else a.cd=.2;
      }
    }
    if(p.allyT<=0)p.ally=null;
  }
}
function useAbility(id){
  if(!P||mode!=='play')return;
  const a=ABIL.find(x=>x.id===id);if(!a||!has(a))return;
  const need=()=>{sfx('empty');ftext(P.x,P.y-110,L('нужны кристаллы'),'#9fd8ff')};
  if(id==='dash'){if(P.dashCd>0)return;P.dashT=.2;P.dashCd=a.cd;P.inv=Math.max(P.inv,.3);sfx('dash');ring(P.x,P.y-30,'#9dff7a',50,.25)}
  else if(id==='med'){if(P.medCd>0)return;if(G.kits<=0||P.hp>=P.maxHp){sfx('empty');ftext(P.x,P.y-110,L(G.kits<=0?L('нет аптечек'):L('здоровье полное')),'#ffd36b');return}G.kits--;P.hp=Math.min(P.maxHp,P.hp+2);P.medCd=a.cd;sfx('heal');ring(P.x,P.y-40,'#ff8a8a',60,.4);burst(P.x,P.y-40,14,['#ff6a6a','#fff'],140,.6,0,3,true)}
  else if(id==='nova'){
    if(P.novaCd>0)return;if(G.gems<1){need();return}
    G.gems--;P.novaCd=a.cd;sfx('nova');addShake(6);ring(P.x,P.y-40,'#7fd8ff',340,.6);ring(P.x,P.y-40,'#fff',200,.4);burst(P.x,P.y-40,40,['#7fd8ff','#fff','#bfeaff'],360,.8,0,4,true);
    for(const e of enemies){if(e.dead||e.spawnT>0||e.dying)continue;if(Math.hypot(e.x-P.x,e.y-e.hh/2-P.y)<360)e.frozen=e.boss?1.0:3.2}
    for(const q of eproj)if(Math.hypot(q.x-P.x,q.y-P.y)<360)q.life=0;
  }else if(id==='shield'){if(P.shieldT>0)return;if(G.gems<2){need();return}G.gems-=2;P.shieldT=7;P.shieldHits=3;sfx('shield');ring(P.x,P.y-40,'#7fd8ff',80,.4)}
  else if(id==='ally'){if(P.allyT>0)return;if(G.gems<3){need();return}G.gems-=3;P.allyT=a.cd;P.ally={x:P.x,y:P.y-90,cd:.4,t:0};sfx('summon');ring(P.x,P.y-90,'#9dff7a',90,.5)}
}
function fire(){
  const p=P,m=muzzle(p);
  if(p.weapon===0){p.whipOn=true;p.whipT=0;p.hit.clear();p.wcd=.78;sfx('whip')}
  else if(p.weapon===1){
    if(p.en>=8){p.en-=8;p.wcd=.24;p.shootT=.18;p.recoil=1;p.aimHold=.5;proj.push({k:'seed',x:m.x,y:m.y,vx:p.face*680,vy:0,life:.9,dmg:dmgOf('pistol')});sfx('shoot');burst(m.x,m.y,5,['#d8ff7a','#fff'],120,.2,0,2.5,true);parts.push({x:p.x,y:m.y,vx:-p.face*rnd(30,70),vy:-rnd(120,200),life:.6,max:.6,g:700,s:2.4,c:'#e8c84a'})}
    else{p.wcd=.3;sfx('empty');ftext(p.x,p.y-110,L('нет энергии'),'#ffd36b')}
  }else if(p.weapon===2){
    if(p.en>=35){p.en-=35;p.wcd=.8;p.throwT=.3;proj.push({k:'nade',x:p.x+p.face*14,y:p.y-62,vx:p.face*300+p.vx*.3,vy:-380,life:1.1,dmg:dmgOf('nade'),rot:0});sfx('throw')}
    else{p.wcd=.4;sfx('empty');ftext(p.x,p.y-110,L('нужно 35 энергии'),'#ffd36b')}
  }
}
function setWeapon(n){
  if(!P)return;const list=WEAPS.filter(has);
  const w=((n%3)+3)%3;
  if(!has(WEAPS[w])){if(n>P.weapon){P.weapon=0}return}
  if(w!==P.weapon){P.weapon=w;sfx('swap')}
}
function nextWeapon(d){let w=P.weapon;for(let i=0;i<3;i++){w=((w+d)%3+3)%3;if(has(WEAPS[w]))break}setWeapon(w)}
/* ---------- projectiles ---------- */
function explode(x,y,R,dmg){
  R=R||130;dmg=dmg||3;
  sfx('boom');addShake(14);stop(.08);vib(40);
  ring(x,y,'#b6ff5a',R,.5);ring(x,y,'#ffffff',R*.6,.3);
  burst(x,y,42,['#b6ff5a','#ffe45c','#7fd13b','#fff'],370,.8,300,4,true);
  leafBurst(x,y,16);
  for(const e of enemies){
    if(e.dead)continue;
    const dx=e.x-x,dy=(e.y-e.hh/2)-y;
    if(Math.hypot(dx,dy)<R+e.hw*.3){hitEnemy(e,dmg,(dx>=0?1:-1)*(e.boss?150:420),-340)}
  }
}
function updateProj(dt){
  for(const q of proj){
    q.life-=dt;
    if(q.k==='seed'||q.k==='abolt'){
      q.x+=q.vx*dt;q.y+=q.vy*dt;
      if(Math.random()<.8)parts.push({x:q.x,y:q.y,vx:rnd(-20,20),vy:rnd(-20,20),life:.25,max:.25,g:0,s:3,c:q.k==='abolt'?'#9fe8ff':'#d8ff7a',add:true});
      const px=q.x-q.vx*dt,py=q.y-q.vy*dt,mnx=Math.min(px,q.x)-4,mxx=Math.max(px,q.x)+4,mny=Math.min(py,q.y)-4,mxy=Math.max(py,q.y)+4;
      for(const e of enemies){
        if(e.dead||e.spawnT>.25)continue;
        const ext=Math.max(e.hh,e.dh*.9);
        if(mxx>e.x-e.hw/2-4&&mnx<e.x+e.hw/2+4&&mxy>e.y-ext-8&&mny<e.y+6){sfx('seedhit');hitEnemy(e,q.dmg,Math.sign(q.vx)*(e.boss?80:260),-160);q.life=0;break}
      }
    }else if(q.k==='rocket'){
      q.x+=q.vx*dt;
      parts.push({x:q.x-Math.sign(q.vx)*14,y:q.y,vx:rnd(-30,30),vy:rnd(-30,30),life:.4,max:.4,g:0,s:rnd(3,6),c:Math.random()<.5?'#ffb347':'#aaa',add:Math.random()<.5});
      let boom=q.life<=0;
      for(const e of enemies){if(!e.dead&&e.spawnT<=.25&&q.x>e.x-e.hw/2-6&&q.x<e.x+e.hw/2+6&&q.y>e.y-Math.max(e.hh,e.dh*.9)-6&&q.y<e.y+6){boom=true;break}}
      if(boom){explode(q.x,q.y,105,q.dmg);q.life=-1}
    }else{
      q.vy+=GRAV*.8*dt;q.x+=q.vx*dt;const py=q.y;q.y+=q.vy*dt;q.rot+=dt*10;
      if(Math.random()<.6)parts.push({x:q.x,y:q.y,vx:rnd(-20,20),vy:rnd(-20,20),life:.3,max:.3,g:0,s:3,c:'#9dffb0',add:true});
      let boom=q.life<=0;
      if(q.vy>0)for(const s of LV.solids){if(q.x>s.x&&q.x<s.x+s.w&&py<=s.y&&q.y>=s.y){boom=true;break}}
      for(const e of enemies){if(!e.dead&&e.spawnT<=.25&&q.x>e.x-e.hw/2-6&&q.x<e.x+e.hw/2+6&&q.y>e.y-Math.max(e.hh,e.dh*.9)-6&&q.y<e.y+6){boom=true;break}}
      if(boom){explode(q.x,q.y,130,q.dmg);q.life=-1}
    }
    if(q.x<cam-100||q.x>cam+W+100||q.y>H+100)q.life=-1;
  }
  proj=proj.filter(q=>q.life>0);
}
/* ---------- effects & update ---------- */
function updateFX(dt){
  let j=0;
  for(let i=0;i<parts.length;i++){const p=parts[i];p.life-=dt;if(p.life<=0)continue;p.vy+=p.g*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.leaf)p.rot+=p.vr*dt;parts[j++]=p}
  parts.length=j;
  for(const t of texts){t.t+=dt;t.y-=34*dt}
  texts=texts.filter(t=>t.t<1.1);
  for(const f of fx)f.t+=dt;
  fx=fx.filter(f=>f.t<f.life);
  for(const d of deb){d.life-=dt;d.vy+=GRAV*.7*dt;d.x+=d.vx*dt;d.y+=d.vy*dt;d.r+=d.vr*dt;d.vx*=Math.pow(.4,dt)}
  deb=deb.filter(d=>d.life>0);
  G.trauma=Math.max(0,G.trauma-dt*1.8);G.hurtFlash=Math.max(0,G.hurtFlash-dt);G.fade=Math.max(0,G.fade-dt*1.6);
  G.wavePop=Math.max(0,G.wavePop-dt*2.5);G.coinPop=Math.max(0,G.coinPop-dt*4);
  if(G.banner){G.banner.t+=dt;if(G.banner.t>2.6)G.banner=null}
  if(G.tbanner){G.tbanner.t+=dt;if(G.tbanner.t>5)G.tbanner=null}
  const n=Math.min(drift.length,Math.round(Qe.leaves||0));
  for(let i=0;i<n;i++){const d=drift[i];d.x+=d.vx*dt+Math.sin(G.time*1.3+i)*14*dt;d.y+=d.vy*dt;d.r+=d.vr*dt;if(d.y>H+10){d.y=-10;d.x=rnd(0,W+200)}if(d.y<-14){d.y=H+10;d.x=rnd(0,W)}if(d.x<-20)d.x=W+20}
}
function update(dt){
  G.time+=dt;G.hint+=dt;
  updatePlats(dt);
  updatePlayer(dt);updateEnemies(dt);updateProj(dt);updateItems(dt);updateWaves(dt);updateFX(dt);
  const tx=clamp(P.x-W*.42+P.face*50+P.vx*.14,0,LV.world-W);
  cam+=(tx-cam)*(1-Math.exp(-dt*4.2));
}

