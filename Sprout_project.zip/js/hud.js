'use strict';
/* ---------- HUD ---------- */
let ICM=null,HUDHIT=[];
function ico(n,x,y,s,a){
  const m=ICM&&ICM[n];if(!m||!IMG.icons)return;
  if(a!==undefined)ctx.globalAlpha=a;
  ctx.drawImage(IMG.icons,m[0],m[1],m[2],m[3],x-s/2,y-s/2,s,s);
  if(a!==undefined)ctx.globalAlpha=1;
}
function keyLabel(a){const b=CFG.binds[a];return b&&b[0]?keyName(b[0]):''}
function slot(x,y,r,name,sel,opts){
  opts=opts||{};
  const ringIcon=['nade'].indexOf(name)>=0;
  const dim=opts.dim?.45:1;
  if(ringIcon){ctx.globalAlpha=dim;ico(name,x,y,r*2+10);ctx.globalAlpha=1}
  else{
    ctx.globalAlpha=dim;ctx.fillStyle='rgba(18,26,14,.85)';ctx.beginPath();ctx.arc(x,y,r,0,7);ctx.fill();
    ctx.lineWidth=3;ctx.strokeStyle='#6a7a3a';ctx.stroke();ico(name,x,y,r*(name==='pistol'||name==='whip'?1.8:1.55));ctx.globalAlpha=1;
  }
  if(sel){ctx.lineWidth=4;ctx.strokeStyle='#ffd84a';ctx.beginPath();ctx.arc(x,y,r+2,0,7);ctx.stroke()}
  if(opts.cd>0){
    ctx.fillStyle='rgba(0,0,0,.6)';ctx.beginPath();ctx.moveTo(x,y);ctx.arc(x,y,r,-Math.PI/2,-Math.PI/2+Math.PI*2*opts.cd,false);ctx.closePath();ctx.fill();
  }
  if(opts.label){
    ctx.fillStyle='#2b1a0d';rrect(ctx,x-10,y+r-5,20,15,4);ctx.fill();ctx.strokeStyle='#8a6a30';ctx.lineWidth=1.5;ctx.stroke();
    ctx.fillStyle='#ffe9a8';ctx.font='bold 11px Trebuchet MS,sans-serif';ctx.textAlign='center';ctx.fillText(opts.label,x,y+r+6);
  }
  if(opts.badge!==undefined){
    ctx.fillStyle='rgba(10,16,24,.9)';ctx.beginPath();ctx.arc(x+r*.7,y-r*.7,9,0,7);ctx.fill();
    ico(opts.badgeIco||'gem',x+r*.7-5,y-r*.7,11);ctx.fillStyle='#fff';ctx.font='bold 10px Trebuchet MS,sans-serif';ctx.textAlign='center';ctx.fillText(String(opts.badge),x+r*.7+4,y-r*.7+3.5);
  }
}
function drawHUD(){
  HUDHIT.length=0;
  ico('portrait',46,46,88);
  const low=P.hp<=1&&mode==='play',pulse=low?1+.12*Math.abs(Math.sin(G.time*6)):1;
  for(let i=0;i<P.maxHp;i++){
    const x=104+i*30,full=i<P.hp,sz=26*(full&&low?pulse:1);
    if(full)ico('heart',x,28,sz+6);
    else{heart(ctx,x,15,24);ctx.fillStyle='rgba(30,12,12,.8)';ctx.fill();ctx.lineWidth=2;ctx.strokeStyle='#3a1a1a';ctx.stroke()}
  }
  const ex=112,ey=52,ew=Math.min(210,P.maxEn*1.5);
  ico('leaf',ex-16,ey+7,24);
  ctx.fillStyle='rgba(16,22,12,.85)';rrect(ctx,ex-2,ey-2,ew+4,16,6);ctx.fill();
  ctx.fillStyle='#8a6a10';rrect(ctx,ex,ey,Math.max(4,ew*P.henS/P.maxEn),12,5);ctx.fill();
  ctx.fillStyle=P.en<8?'#d8742a':'#ffd93a';rrect(ctx,ex,ey,Math.max(4,ew*P.en/P.maxEn),12,5);ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.35)';ctx.fillRect(ex+3,ey+2,Math.max(0,ew*P.en/P.maxEn-6),3);
  ctx.font='bold 14px Trebuchet MS,sans-serif';ctx.textAlign='left';
  let cx0=100;const cp=1+G.coinPop*.3,txt=(s,x,col)=>{ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillText(s,x+1,91);ctx.fillStyle=col||'#fff3c0';ctx.fillText(s,x,90)};
  ico('coin',cx0+6,84,18*cp);txt(String(G.coins),cx0+19);cx0+=19+ctx.measureText(String(G.coins)).width+14;
  if(false){ico('gem',cx0+6,84,18);txt(String(G.gems),cx0+19,'#bfe8ff');cx0+=19+ctx.measureText(String(G.gems)).width+14}
  if(false){ico('medkit',cx0+6,84,20);txt(String(G.kits),cx0+19,'#cfe9a0');cx0+=19+ctx.measureText(String(G.kits)).width+14}
  txt(L('очки ')+G.score,cx0,'#cfe9a0');
  const bx=W-212,by=14;
  ctx.fillStyle='rgba(18,22,16,.88)';rrect(ctx,bx,by,198,46,10);ctx.fill();ctx.lineWidth=3;ctx.strokeStyle='#5d4c30';ctx.stroke();
  ctx.fillStyle='#e9e1c4';ctx.beginPath();ctx.arc(bx+28,by+21,11,0,7);ctx.fill();ctx.fillRect(bx+21,by+27,14,8);
  ctx.fillStyle='#1b1b14';ctx.beginPath();ctx.arc(bx+24,by+21,3,0,7);ctx.fill();ctx.beginPath();ctx.arc(bx+32,by+21,3,0,7);ctx.fill();
  const wv=G.ws==='prep'?Math.min(LV.waves,G.wave+1):G.wave;
  ctx.save();ctx.translate(bx+52,by+30);const wp=1+G.wavePop*.25;ctx.scale(wp,wp);
  ctx.fillStyle='#f0e8cc';ctx.font='bold 20px Trebuchet MS,sans-serif';ctx.textAlign='left';
  ctx.fillText(G.ws==='done'?L('ВОЛНЫ ✓'):L('ВОЛНА')+'  '+wv+'/'+LV.waves,0,0);ctx.restore();
  if(G.ws==='prep'&&G.wave>0){ctx.font='12px Trebuchet MS,sans-serif';ctx.fillStyle='#bfe59a';ctx.textAlign='center';ctx.fillText(L('следующая через ')+Math.ceil(G.wt),bx+99,by+62)}
  // weapons & abilities
  const wl=WEAPS.map((w,i)=>({w,i})).filter(o=>has(o.w)),al=ABIL.filter(has);
  const wr=isTouch?25:28,gap=isTouch?62:72,wy=isTouch?H-40:H-56;
  const x0w=isTouch?W/2-(wl.length-1)*gap/2:60;
  wl.forEach((o,j)=>{
    const x=x0w+j*gap;
    slot(x,wy,wr,o.w.ico,P.weapon===o.i,{label:isTouch?'':String(o.i+1),dim:o.w.cost>0&&P.en<o.w.cost});
    HUDHIT.push({x,y:wy,r:wr+6,fn:()=>setWeapon(o.i)});
  });
  const ar=isTouch?21:22,ay=wy-(isTouch?58:64),x0a=isTouch?W/2-(al.length-1)*52/2:44;
  al.forEach((a,j)=>{
    const x=x0a+j*52;
    let cd=0,badge,dim=false,fn=()=>useAbility(a.id);
    if(a.id==='dash')cd=P.dashCd/a.cd;
    else if(a.id==='med'){cd=P.medCd/a.cd;badge=G.kits;dim=G.kits<=0||P.hp>=P.maxHp}
    else if(a.id==='nova'){cd=P.novaCd/a.cd}
    else if(a.id==='shield'){cd=P.shieldT>0?0:0}
    else if(a.id==='ally'){cd=0}
    if(a.gem){badge=a.gem;dim=G.gems<a.gem}
    const act=(a.id==='shield'&&P.shieldT>0)||(a.id==='ally'&&P.allyT>0);
    slot(x,ay,ar,a.ico,act,{cd:Math.min(1,cd),badge:a.id==='med'?badge:badge,badgeIco:a.id==='med'?'medkit':'gem',dim,label:isTouch?'':keyLabel(a.id==='ally'?'ally':a.id)});
    HUDHIT.push({x,y:ay,r:ar+6,fn});
  });
  const mw=150,mh=72,mx=W-mw-14,my=isTouch?78:H-mh-14;
  ctx.fillStyle='rgba(12,26,22,.82)';rrect(ctx,mx,my,mw,mh,8);ctx.fill();ctx.lineWidth=3;ctx.strokeStyle='#5d7a58';ctx.stroke();
  const sx=(mw-16)/LV.world,sy=(mh-16)/H;
  ctx.fillStyle='#4a8a60';
  for(const s of LV.solids){ctx.fillRect(mx+8+s.x*sx,my+8+s.y*sy,Math.max(2,s.w*sx),s.ground?3:2)}
  ctx.fillStyle='#e04a3a';for(const e of enemies)ctx.fillRect(mx+8+e.x*sx-2,my+8+(e.y-10)*sy-2,4,4);
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(mx+8+P.x*sx,my+8+(P.y-20)*sy,3,0,7);ctx.fill();
  ctx.fillStyle=G.open?'#8dff6a':'#d9d9c0';const fx0=mx+8+(LV.world-100)*sx;ctx.fillRect(fx0,my+8+(GY-26)*sy,1.5,12);ctx.fillRect(fx0,my+8+(GY-26)*sy,6,4);
  const boss=enemies.find(e=>e.boss);
  if(boss){
    const by2=isTouch?H-132:H-96;
    ctx.fillStyle='rgba(0,0,0,.6)';rrect(ctx,W/2-150,by2,300,16,6);ctx.fill();
    ctx.fillStyle='#e8543a';rrect(ctx,W/2-147,by2+3,Math.max(4,294*Math.max(0,boss.hp)/boss.maxhp),10,4);ctx.fill();
    ctx.fillStyle='#fff';ctx.font='bold 12px Trebuchet MS,sans-serif';ctx.textAlign='center';ctx.fillText(L(ED[boss.type].name).toUpperCase(),W/2,by2-4);
  }
  if(G.hurtFlash>0){ctx.globalAlpha=Math.min(1,G.hurtFlash*1.6);ctx.drawImage(GL.hurt,0,0);ctx.globalAlpha=1}
  if(CFG.hints&&G.hint<10&&G.lv===0&&mode==='play'){
    ctx.globalAlpha=clamp(10-G.hint,0,1);ctx.textAlign='center';ctx.font='bold 15px Trebuchet MS,sans-serif';
    const t=L(isTouch?L('◀ ▶ бег · ⤒ прыжок (в воздухе ещё раз) · ✦ атака · ⟳ оружие'):L('← → бег · Пробел прыжок (в воздухе ещё раз) · J атака · 1 2 3 оружие'));
    ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillText(t,W/2+1,H-141);ctx.fillStyle='#fff3c0';ctx.fillText(t,W/2,H-142);ctx.globalAlpha=1;
  }
  if(G.tbanner){
    const b=G.tbanner,a=clamp(b.t<.5?b.t*2:(5-b.t),0,1);
    ctx.globalAlpha=a;ctx.font='bold 17px Trebuchet MS,sans-serif';ctx.textAlign='center';const s=L(b.s),w=ctx.measureText(s).width+30;
    ctx.fillStyle='rgba(16,30,14,.85)';rrect(ctx,W/2-w/2,214,w,32,10);ctx.fill();ctx.strokeStyle='#8fd14f';ctx.lineWidth=2;ctx.stroke();
    ctx.fillStyle='#e9f7c8';ctx.fillText(s,W/2,236);ctx.globalAlpha=1;
  }
  if(CFG.fps){ctx.font='bold 12px monospace';ctx.textAlign='left';ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(8,H-20,118,16);ctx.fillStyle='#9dff7a';ctx.fillText('FPS '+Math.round(fpsS)+' · '+Qe.tier,12,H-8)}
}

