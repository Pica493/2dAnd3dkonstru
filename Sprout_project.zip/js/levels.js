'use strict';
/* ---------- themes & levels ---------- */
const THEMES={
  green:{slab1:'#8a5530',slab2:'#5a3219',line:'rgba(40,20,10,.55)',blot:'#c0652a',rivet:'#3a2110',moss:'#5aa62f',moss2:'#8fdc4a',vine:'#3e8c2b',leaf:'#79c943'},
  dark:{slab1:'#4a3830',slab2:'#2b1f1b',line:'rgba(0,0,0,.6)',blot:'#9a4a22',rivet:'#17100d',moss:'#2f7a58',moss2:'#5fe0b0',vine:'#256b4a',leaf:'#4fd0a0'},
  metro:{metro:true,slab1:'#5e554a',slab2:'#2f2a26',wag1:'#4d6e76',wag2:'#2a3f46',line:'rgba(0,0,0,.55)',blot:'#9a4a22',rivet:'#17100d',moss:'#3a7a3a',moss2:'#7fd05a',vine:'#2f7a3a',leaf:'#6fcf4f'},
  glass:{glass:true,slab1:'rgba(205,242,252,.95)',slab2:'rgba(120,184,208,.95)',line:'rgba(255,255,255,.65)',blot:'rgba(255,255,255,.5)',rivet:'#6aa0b5',moss:'#58b58a',moss2:'#9af0c0',vine:'#3f9c7a',leaf:'#8be6b8'}
};

/* ---------- levels ---------- */
THEMES.swamp={slab1:'#5a4630',slab2:'#2c2318',line:'rgba(0,0,0,.5)',blot:'#7a8a2a',rivet:'#1a1a10',moss:'#6a9a2a',moss2:'#b8f050',vine:'#4a7a1e',leaf:'#9ad040'};
THEMES.core={metro:false,slab1:'#46465a',slab2:'#1c1c28',line:'rgba(255,70,50,.55)',blot:'#ff5a3a',rivet:'#ff6a4a',moss:'#8a2a2a',moss2:'#ff7a4a',vine:'#6a2a2a',leaf:'#ff8a5a'};
const LEVELS=[
  {name:'Крыши Зелёного Города',sub:'Уровень 1',theme:'green',dark:false,slip:false,world:3000,sky:'#7fc6ee',waves:10,bossWave:false,
   desc:'Учимся прыгать и махать хлыстом. Ржавые Жуки и Мухоловки. 10 волн.',
   pool:[['beetle',[2,2,3,2,3,3,4,3,4,5]],['fly',[0,1,0,2,1,2,2,3,2,4]]],
   ground:[[0,900],[1040,1900],[2040,3000]],
   plats:[[230,385,170],[470,315,190],[760,385,150],[1180,380,200],[1450,300,200],[1700,380,160],[1560,205,170],[2150,385,180],[2380,310,200],[2620,385,170],[2480,215,160]]},
  {name:'Ржавое Метро',sub:'Уровень 2',theme:'metro',dark:true,slip:false,world:3600,sky:'#0c1614',bgKey:'bg2',waves:10,bossWave:false,
   desc:'Тёмная станция. Дроны, крысы, пауки и плевуны. Босс: Начальник станции.',
   pool:[['rat',[2,2,1,3,2,3,2,3,3,4]],['drone',[0,1,1,1,2,2,2,3,3,3]],['spider',[0,0,1,1,1,2,2,2,3,3]],['spit',[0,0,0,1,1,1,2,2,2,3]]],
   ground:[[0,820],[980,1700],[1880,2600],[2780,3600]],
   plats:[[120,390,260,'w'],[520,310,200,'l'],[860,400,140,'l'],[1060,360,260,'w'],[1380,290,200,'l'],[1640,380,240,'w'],[1960,330,200,'l'],[2200,250,160,'l'],[2300,390,260,'w'],[2650,380,170,'l'],[2860,320,240,'w'],[3150,225,170,'l'],[3250,390,200,'l']],
   props:[{t:'col',x:70},{t:'col',x:640},{t:'col',x:1020},{t:'col',x:1520},{t:'col',x:2000},{t:'col',x:2480},{t:'col',x:2900},{t:'col',x:3420},{t:'bench',x:430},{t:'bench',x:1300},{t:'bench',x:2150},{t:'bench',x:3200},{t:'crate',x:300},{t:'crate',x:1180},{t:'crate',x:2380},{t:'crate',x:3000},{t:'lamp',x:260,y:80},{t:'lamp',x:620,y:90},{t:'lamp',x:1010,y:80},{t:'lamp',x:1420,y:90},{t:'lamp',x:1820,y:80},{t:'lamp',x:2220,y:90},{t:'lamp',x:2620,y:80},{t:'lamp',x:3020,y:90},{t:'lamp',x:3420,y:80}]},
  {name:'Арена Хранителя',sub:'Уровень 3',theme:'green',dark:false,slip:false,world:1800,sky:'#8fd0e8',bgKey:'bg6',arena:true,boss:'golem',waves:1,bossWave:true,
   desc:'Священная арена. Одна волна: битва с Хранителем Лотоса.',
   pool:[],
   ground:[[0,520],[680,1120],[1280,1800]],
   plats:[[150,390,170],[330,310,150],[760,380,150],[900,290,150],[1190,390,150],[1350,310,170],[1540,390,150]]}
];
const THEME_DR={green:['leaf',['#a8e85a','#e8c84a','#79c943']],metro:['dust',['#ffb36a','#ffd9a0']]};
function buildLevel(i){
  const d=LEVELS[i],L=Object.assign({},d);
  L.index=i;
  L.ground=d.ground.map((g,k)=>({x:g[0],y:GY,w:g[1]-g[0],ground:true,id:'g'+k}));
  L.plats=d.plats.map((p,k)=>({x:p[0],y:p[1],w:p[2],id:'p'+k,style:p[3]||0,mv:p[4]||null,x0:p[0],dx:0}));
  L.solids=L.ground.concat(L.plats);
  L.pits=[];
  for(let k=0;k<L.ground.length-1;k++){const a=L.ground[k],b=L.ground[k+1];L.pits.push({x:a.x+a.w,w:b.x-a.x-a.w})}
  L.solids.forEach((s,k)=>{s.art=makeSolid(s,d.theme,i*977+k*131+7)});
  const it=[];
  L.ground.forEach(g=>{for(let x=g.x+(g.x===0?260:150);x<g.x+g.w-110;x+=320)it.push({t:'coin',x,y:GY-34})});
  L.plats.forEach((p,k)=>{
    if(p.mv)return;
    for(let q=1;q<=3;q++)it.push({t:'coin',x:p.x+p.w*q/4,y:p.y-32});
    if(p.y<=230){it.push({t:'heart',x:p.x+p.w/2,y:p.y-34});it.push({t:'orb',x:p.x+p.w/2-34,y:p.y-52})}
    else if(k%3===1)it.push({t:'orb',x:p.x+p.w/2,y:p.y-62});
  });
  L.pits.forEach(p=>{for(let q=0;q<3;q++){const u=(q+1)/4;it.push({t:'coin',x:p.x+p.w*u,y:GY-70-Math.sin(u*Math.PI)*70})}});
  it.forEach((o,k)=>{o.ph=k*.7;o.got=false});
  L.items=it;
  return L;
}

function makeSolid(s,theme,seed){
  const r=rng(seed),P=2,pad=26,hang=s.ground?34:100,bodyH=s.ground?70:(s.style==='w'?58:24),top=20;
  const cw=s.w+pad*2,ch=top+bodyH+hang;
  const c=document.createElement('canvas');c.width=cw*P;c.height=ch*P;
  const g=c.getContext('2d');g.scale(P,P);
  const th=THEMES[theme];
  const gr=g.createLinearGradient(0,top,0,top+bodyH);gr.addColorStop(0,(s.style==='w'&&th.wag1)||th.slab1);gr.addColorStop(1,(s.style==='w'&&th.wag2)||th.slab2);
  g.fillStyle=gr;rrect(g,pad,top,s.w,bodyH,s.ground?3:6);g.fill();
  g.save();rrect(g,pad,top,s.w,bodyH,s.ground?3:6);g.clip();
  g.strokeStyle=th.line;g.lineWidth=1.5;
  for(let x=pad+30;x<pad+s.w-10;x+=36+r()*44){g.beginPath();g.moveTo(x,top);g.lineTo(x,top+bodyH);g.stroke()}
  if(s.ground)for(let y=top+22;y<top+bodyH;y+=24){g.beginPath();g.moveTo(pad,y);g.lineTo(pad+s.w,y);g.stroke()}
  for(let i=0;i<s.w/14;i++){g.globalAlpha=.18+r()*.3;g.fillStyle=th.blot;g.beginPath();g.ellipse(pad+r()*s.w,top+4+r()*bodyH,5+r()*14,3+r()*7,0,0,7);g.fill()}
  g.globalAlpha=1;
  if(th.glass){g.fillStyle='rgba(255,255,255,.35)';for(let x=pad-40;x<pad+s.w;x+=90){g.beginPath();g.moveTo(x,top+bodyH);g.lineTo(x+30,top);g.lineTo(x+46,top);g.lineTo(x+16,top+bodyH);g.fill()}}
  g.fillStyle=th.rivet;for(let x=pad+9;x<pad+s.w-4;x+=26){g.beginPath();g.arc(x,top+bodyH-7,1.9,0,7);g.fill()}
  if(s.style==='w'){for(let x=pad+16;x<pad+s.w-30;x+=48){const lit=r()<.7;g.fillStyle='#0b1316';rrect(g,x-2,top+10,34,24,4);g.fill();g.fillStyle=lit?'#ffae52':'#1e2a2e';rrect(g,x,top+12,30,20,3);g.fill();if(lit){g.fillStyle='rgba(255,230,160,.5)';g.fillRect(x+2,top+14,26,6)}}}
  g.fillStyle='rgba(0,0,0,.28)';g.fillRect(pad,top+bodyH-5,s.w,5);
  g.restore();
  // moss
  g.fillStyle=th.moss;g.fillRect(pad-2,top-1,s.w+4,6);g.fillStyle='rgba(255,255,210,.4)';g.fillRect(pad,top-1,s.w,1.5);if(th.metro&&s.ground){g.fillStyle='#d9b52c';g.fillRect(pad,top+6,s.w,4);g.fillStyle='#1a1a14';for(let x=pad;x<pad+s.w;x+=14)g.fillRect(x,top+6,6,4)}
  for(let x=pad-4;x<pad+s.w+6;x+=5){g.beginPath();g.arc(x,top+3,4+r()*4,Math.PI,0);g.fill()}
  g.fillStyle=th.moss2;
  for(let x=pad;x<pad+s.w;x+=9+r()*10){g.beginPath();g.arc(x,top+1,2+r()*3,Math.PI,0);g.fill()}
  g.fillStyle=th.moss;
  for(let x=pad+6;x<pad+s.w-4;x+=11+r()*22){const dl=5+r()*(s.ground?20:11);g.beginPath();g.moveTo(x-4,top+4);g.quadraticCurveTo(x,top+4+dl,x+4,top+4);g.fill()}
  // grass blades + flowers
  for(let x=pad+4;x<pad+s.w-4;x+=7+r()*12){leaf(g,x,top+2,8+r()*9,2.5,-Math.PI/2+(r()-.5)*.9,r()<.5?th.leaf:th.moss2)}
  for(let x=pad+16;x<pad+s.w-10;x+=60+r()*80){
    g.fillStyle='#fff';for(let k=0;k<5;k++){g.beginPath();g.arc(x+Math.cos(k*1.256)*2.6,top-3+Math.sin(k*1.256)*2.6,1.9,0,7);g.fill()}
    g.fillStyle='#ffd84a';g.beginPath();g.arc(x,top-3,1.5,0,7);g.fill();
  }
  // hanging vines
  const nv=Math.floor(s.w/34)+1;
  for(let i=0;i<nv;i++){
    const vx=pad+8+r()*(s.w-16),len=20+r()*(hang-26),sw=(r()-.5)*14;
    g.strokeStyle=th.vine;g.lineWidth=2+r();g.lineCap='round';
    g.beginPath();g.moveTo(vx,top+bodyH-4);g.quadraticCurveTo(vx+sw,top+bodyH-4+len*.5,vx+sw*.4,top+bodyH-4+len);g.stroke();
    for(let yy=9;yy<len;yy+=11){const side=(yy/11|0)%2?1:-1;leaf(g,vx+sw*(yy/len)*.8,top+bodyH-4+yy,9,3.4,side>0?.3:Math.PI-.3,r()<.5?th.leaf:th.moss2)}
  }
  return {c,pad,top,cw,ch};
}


