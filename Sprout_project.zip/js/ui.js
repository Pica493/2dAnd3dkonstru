'use strict';
/* ---------- waves ---------- */
function buildQueue(n){
  const DF=DIFF[CFG.diff];let q=[];
  if(n===LV.waves&&LV.bossWave)q=[LV.boss];
  else{
    for(const [t,arr] of LV.pool){let c=arr[Math.min(n,arr.length)-1];if(c>0)c=Math.max(1,Math.round(c*DF.cnt));for(let i=0;i<c;i++)q.push(t)}
    for(let i=q.length-1;i>0;i--){const j=(Math.random()*(i+1))|0;[q[i],q[j]]=[q[j],q[i]]}
  }
  G.queue=q;
}
function updateWaves(dt){
  const bossWave=()=>G.wave===LV.waves&&LV.bossWave;
  if(G.ws==='prep'){
    G.wt-=dt;
    if(G.wt<=0){
      G.wave++;G.wavePop=1;buildQueue(G.wave);G.ws='fight';G.sq=.2;
      banner(L('ВОЛНА')+' '+G.wave,bossWave()?L('Босс')+': '+L(ED[LV.boss].name)+'!':'');sfx('wave');
      if(bossWave())musicBoss(true);else{if(Mus.lv===3)musicStart(G.lv);musicInt(Math.min(.9,.62+G.wave*.03))}
    }
  }else if(G.ws==='fight'){
    if(G.queue.length){
      G.sq-=dt;
      if(G.sq<=0&&enemies.length<9){spawnEnemy(G.queue.shift());G.sq=.6}
    }else if(enemies.length===0){
      if(G.wave>=LV.waves){G.ws='done';G.open=true;banner(L('Ворота открыты!'),L('Бегите вправо к выходу'));sfx('open');musicInt(.3)}
      else{G.ws='prep';G.wt=3;P.en=Math.min(P.maxEn,P.en+30);ftext(P.x,P.y-110,L('волна пройдена'),'#cfffa0');sfx('clear');musicInt(.3)}
    }
  }
  if(G.open&&P.x>LV.world-120&&mode==='play')winLevel();
}
/* ---------- win / shop ---------- */
function winLevel(){
  mode='won';sfx('win');musicInt(0);vib([40,40,90]);
  G.cleared[G.lv]=true;saveProg();
  showShop(G.lv>=LEVELS.length-1);
}
function showShop(last){
  const html='<h2>'+L(last?'Путь пройден!':'Уровень пройден!')+'</h2>'+
   '<p>'+L(LV.name)+'</p>'+
   '<div class="stat"><span>'+L('Очки')+'</span><b>'+G.score+'</b></div>'+
   '<div class="stat"><span>'+L('Собрано монет')+'</span><b>'+G.lvCoins+'</b></div>'+
   '<div class="stat"><span>'+L('Побеждено врагов')+'</span><b>'+G.kills+'</b></div>';
  const btns=[];
  if(!last)btns.push({text:L('Дальше')+': '+L(LEVELS[G.lv+1].name),cls:'green',fn:()=>startLevel(G.lv+1)});
  btns.push({text:L('Сыграть уровень заново'),fn:()=>startLevel(G.lv)});
  btns.push({text:L('В главное меню'),fn:toMenu});
  showPanel(html,btns);
}
function showOver(){
  showPanel('<h2>'+L('Спраут выключился…')+'</h2><p>'+L('Очки')+': <b>'+G.score+'</b> · '+L('Дошли до волны')+' <b>'+Math.max(1,G.wave)+'/10</b></p><p><small>'+L('Ростки ещё живы. Попробуйте ещё раз!')+'</small></p>',
    [{text:L('Заново'),cls:'green',fn:()=>startLevel(G.lv)},{text:L('В главное меню'),fn:toMenu}]);
}
/* ---------- panels ---------- */
function hidePanel(){$('panel').style.display='none';$('pbox').classList.remove('bookbox')}
function showPanel(html,btns){
  const box=$('pbox');box.classList.remove('bookbox');box.innerHTML=html;
  (btns||[]).forEach(b=>{
    const el=document.createElement('button');el.className='btn'+(b.cls?' '+b.cls:'');el.textContent=b.text;if(b.dis)el.disabled=true;
    el.addEventListener('click',()=>{initAudio();sfx('click');b.fn()});box.appendChild(el);
  });
  $('panel').style.display='flex';
}
function levelSelect(){
  const btns=LEVELS.map((l,i)=>({text:(G.cleared[i]?'✓ ':'')+L(l.sub)+': '+L(l.name),cls:'green',fn:()=>{resetRun();startLevel(i)}}));
  btns.push({text:L('Назад'),fn:hidePanel});
  showPanel('<h2>'+L('Выберите уровень')+'</h2><p><small>'+L('Продержитесь 10 волн, победите босса и откройте ворота к Ядру Города.')+'</small></p>'+
    LEVELS.map(l=>'<p style="text-align:left;margin:4px 0"><b>'+L(l.sub)+'.</b> <small>'+L(l.desc)+'</small></p>').join(''),btns);
}
function exitPanel(){
  showPanel('<h2>'+L('До встречи, садовник!')+'</h2><p>'+L('Закройте вкладку, чтобы выйти из игры.')+'</p>',[{text:L('Вернуться'),fn:hidePanel}]);
}
function pauseGame(){
  if(mode!=='play')return;
  mode='paused';muffle(true);sfx('pause');pauseMenu();
}
function pauseMenu(){
  showPanel('<h2>'+L('Пауза')+'</h2>',[{text:L('Продолжить'),cls:'green',fn:resume},{text:L('Настройки'),fn:()=>settingsPanel('audio',pauseMenu)},{text:L('Заново'),fn:()=>startLevel(G.lv)},{text:L('В главное меню'),fn:toMenu}]);
}
function resume(){hidePanel();muffle(false);if(mode==='paused')mode='play'}
/* ---------- collection book ---------- */
const ETXT={
  beetle:'Робот-уборщик старого мира. Мох и цветы проросли сквозь его корпус, но щётки всё ещё подметают руины.',
  fly:'Хищное растение, сросшееся с обломками механизмов. Живёт на крышах и охотится на всё, что движется.',
  drone:'Патрульный дрон лифтовых шахт. Хозяева давно исчезли, а он всё кружит над станцией.',
  rat:'Крыса, которая выжила среди мусора и ржавчины. Половина её тела обросла металлом.',
  spider:'Механический паук-грузчик. Таскает на спине контейнер и уже не помнит, что в нём лежит.',
  spit:'Огромный мутант из затопленных тоннелей. Живёт в темноте и любит сырость.',
  golem:'Хранитель Лотоса, древний страж Ядра Города. Вырос из камня, лиан и механики и оберегает последний сад.'
};
const silC={};
function monsterSrc(type,unl){
  const key=type+(unl?'':'?');if(silC[key])return silC[key];
  const src=IMGV[ED[type].rig]||IMG[ED[type].rig],w=src.width,h=src.height,c=mkCanvas(w,h),g=c.getContext('2d');
  g.drawImage(src,0,0);
  if(!unl){
    g.globalCompositeOperation='source-in';g.fillStyle='#000';g.fillRect(0,0,w,h);
    g.globalCompositeOperation='source-over';g.fillStyle='#e8dcc0';g.font='bold '+Math.round(Math.min(w,h)*.5)+'px Trebuchet MS,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('?',w/2,h/2);
  }
  return silC[key]=c;
}
function sizedCanvas(src,hh){
  const k=hh/src.height,c=document.createElement('canvas');c.width=Math.max(1,Math.round(src.width*k*2));c.height=Math.round(hh*2);
  c.style.width=(c.width/2)+'px';c.style.height=hh+'px';c.style.maxWidth='100%';c.getContext('2d').drawImage(src,0,0,c.width,c.height);return c;
}
function iconCanvas(name,size){const m=ICM[name],c=document.createElement('canvas');c.width=c.height=size*2;c.style.width=c.style.height=size+'px';c.getContext('2d').drawImage(IMG.icons,m[0],m[1],m[2],m[3],0,0,c.width,c.height);return c}
let bookPage=0;
function bookPages(){const pg=[{t:'hero'}];LEVELS.forEach((l,i)=>pg.push({t:'lv',i}));return pg}
function collectionPanel(page){
  if(typeof page==='number')bookPage=page;
  const pages=bookPages(),pgx=pages[bookPage],box=$('pbox');
  box.classList.add('bookbox');box.innerHTML='';
  const D=(cls,html)=>{const e=document.createElement('div');if(cls)e.className=cls;if(html!==undefined)e.innerHTML=html;return e};
  const book=D('book'),left=D('bpage'),right=D('bpage');
  if(pgx.t==='hero'){
    left.innerHTML='<h3>'+L('Спраут')+'</h3>';
    const hc=sizedCanvas(IMG.head,100);hc.className='bimg';left.appendChild(hc);
    left.appendChild(D('','<p>'+L('Последний робот-садовник. Просыпается в мире, где природа поглотила города, и идёт к Ядру, чтобы запустить очистку воды.')+'</p>'));
    right.innerHTML='<h3>'+L('Оружие')+'</h3>';
    const nm={whip:'Хлыст-лиана',pistol:'Семенной пистолет',nade:'Био-граната'};
    for(const w of WEAPS){const row=D('brow');row.appendChild(iconCanvas(w.ico,44));row.appendChild(D('','<b>'+L(nm[w.id])+'</b>'));right.appendChild(row)}
  }else{
    const lv=LEVELS[pgx.i],ok=!!G.cleared[pgx.i],types=lv.pool.map(p=>p[0]).concat(lv.boss?[lv.boss]:[]);
    left.innerHTML='<h3>'+L(lv.sub)+'</h3><h4>'+L(lv.name)+'</h4><p>'+L(lv.desc)+'</p><p class="bst">'+(ok?'✓ '+L('Уровень пройден'):L('Пройдите уровень, чтобы узнать всех обитателей'))+'</p>';
    right.innerHTML='<h3>'+L('Обитатели')+'</h3>';
    const grid=D('bgrid');
    for(const t of types){
      const Dd=ED[t],unl=ok||G.killed[t],card=D('bcard'+(Dd.boss?' boss':''));
      card.appendChild(sizedCanvas(monsterSrc(t,unl),72));
      card.appendChild(D('','<b>'+(unl?L(Dd.name):'???')+'</b><small>'+(unl?L(ETXT[t]):L('Не изучен'))+'</small>'));
      grid.appendChild(card);
    }
    right.appendChild(grid);
  }
  book.appendChild(left);book.appendChild(D('bspine'));book.appendChild(right);box.appendChild(book);
  const nav=D('bnav'),pv=document.createElement('button'),nx=document.createElement('button'),cl=document.createElement('button');
  pv.className=nx.className='btn';pv.textContent='‹';nx.textContent='›';cl.className='btn green';cl.textContent=L('Закрыть');
  const span=document.createElement('span');span.textContent=(bookPage+1)+' / '+pages.length;
  nav.appendChild(pv);nav.appendChild(span);nav.appendChild(nx);box.appendChild(nav);box.appendChild(cl);
  const turn=d=>{const n=bookPage+d;if(n<0||n>=pages.length)return;sfx('swap');collectionPanel(n)};
  pv.onclick=()=>turn(-1);nx.onclick=()=>turn(1);cl.onclick=()=>{sfx('click');hidePanel()};
  $('panel').style.display='flex';
}
/* ---------- settings UI ---------- */
let rebind=null;
const ACT=[['left','Влево'],['right','Вправо'],['jump','Прыжок'],['attack','Атака'],['w1','Хлыст'],['w2','Бластер'],['w3','Граната'],['w4','Ракетница'],['next','След. оружие'],['pause','Пауза']];
function keyName(c){const m={ArrowLeft:'←',ArrowRight:'→',ArrowUp:'↑',ArrowDown:'↓',Space:L('Пробел'),Escape:'Esc',ShiftLeft:'Shift',ShiftRight:'Shift'};return m[c]||c.replace('Key','').replace('Digit','')}
function settingsPanel(tab,back){
  tab=tab||'audio';settingsPanel.back=back||settingsPanel.back||hidePanel;settingsPanel.tab=tab;
  const box=$('pbox');box.classList.remove('bookbox');box.innerHTML='<h2>'+L('Настройки')+'</h2>';
  const tabs=document.createElement('div');tabs.className='tabs';
  [['audio',L('Звук')],['gfx',L('Графика')],['game',L('Игра')],['ctl',L('Управление')]].forEach(([k,t])=>{
    const b=document.createElement('button');b.className='tab'+(k===tab?' on':'');b.textContent=L(t);b.onclick=()=>{rebind=null;sfx('click');settingsPanel(k)};tabs.appendChild(b);
  });
  box.appendChild(tabs);
  const body=document.createElement('div');body.className='sbody';box.appendChild(body);
  const row=(label,ctl,hint)=>{const r=document.createElement('div');r.className='srow';const s=document.createElement('span');s.innerHTML=L(label)+(hint?'<small>'+L(hint)+'</small>':'');r.appendChild(s);r.appendChild(ctl);body.appendChild(r);return r};
  const slider=(label,key,min,max,step,fmt,on,hint)=>{
    const w=document.createElement('span');w.style.cssText='display:flex;align-items:center;gap:8px;width:52%;justify-content:flex-end';
    const i=document.createElement('input');i.type='range';i.min=min;i.max=max;i.step=step;i.value=CFG[key];
    const v=document.createElement('span');v.className='rv';v.textContent=fmt?fmt(CFG[key]):CFG[key];
    i.oninput=()=>{CFG[key]=+i.value;v.textContent=fmt?fmt(CFG[key]):CFG[key];saveCfg();on&&on()};
    i.onchange=()=>{if(key==='sfx')sfx('coin')};
    w.appendChild(i);w.appendChild(v);row(label,w,hint);
  };
  const toggle=(label,key,on,hint)=>{
    const b=document.createElement('button');const set=()=>{b.className='sw'+(CFG[key]?' on':'');b.textContent=L(CFG[key]?L('Вкл'):L('Выкл'))};set();
    b.onclick=()=>{CFG[key]=!CFG[key];set();saveCfg();sfx('click');on&&on()};row(label,b,hint);
  };
  const choice=(label,key,opts,on,hint)=>{
    const w=document.createElement('div');w.className='seg';
    const ref=()=>{[...w.children].forEach((c,i)=>{c.className='sw'+(CFG[key]===opts[i][0]?' on':'')})};
    opts.forEach(([v,t])=>{const b=document.createElement('button');b.textContent=L(t);b.onclick=()=>{CFG[key]=v;saveCfg();ref();sfx('click');on&&on()};w.appendChild(b)});
    ref();row(label,w,hint);
  };
  const pct=v=>v+'%';
  if(tab==='audio'){
    slider(L('Общая громкость'),'master',0,100,1,pct,applyVolumes);
    slider(L('Музыка'),'music',0,100,1,pct,applyVolumes);
    slider(L('Звуковые эффекты'),'sfx',0,100,1,pct,applyVolumes);
    slider(L('Окружение'),'amb',0,100,1,pct,applyVolumes,L('ветер, птицы, капли'));
  }else if(tab==='gfx'){
    choice(L('Качество'),'quality',[['auto',L('Авто')],['low',L('Низкое')],['med',L('Среднее')],['high',L('Высокое')]],()=>{autoTier=isTouch?'med':'high';applyQuality()},L('Авто само снижает качество при тормозах'));
    slider(L('Разрешение'),'res',50,100,5,pct,applyQuality,L('ниже — быстрее на слабых телефонах'));
    slider(L('Частицы'),'part',20,100,10,pct,applyQuality);
    slider(L('Тряска экрана'),'shake',0,150,10,pct);
    toggle(L('Лучи света'),'rays',applyQuality);toggle(L('Светлячки'),'flies',applyQuality);
    toggle(L('Листва на переднем плане'),'fg',applyQuality);toggle(L('Тени персонажей'),'shadows',applyQuality);
    toggle(L('Свечение'),'glow',applyQuality);toggle(L('Туман'),'mist',applyQuality);
    toggle(L('Красная вспышка при уроне'),'flash');toggle(L('Счётчик FPS'),'fps');
    if(document.documentElement.requestFullscreen){const b=document.createElement('button');b.className='sw';b.textContent=L('Открыть');b.onclick=()=>{try{document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen()}catch(e){}};row(L('Полный экран'),b)}
  }else if(tab==='game'){
    choice(L('Язык / Language'),'lang',[['ru',L('Русский')],['en','English']],()=>{applyLang();settingsPanel('game')});
    choice(L('Сложность'),'diff',[[0,L('Легко')],[1,L('Обычно')],[2,L('Сложно')]],()=>settingsPanel('game'));
    const dd=[[L('врагов меньше (×0.7), здоровье ×0.7, медленнее, энергия быстрее, больше добычи')],[L('обычное количество и здоровье врагов')],[L('врагов больше (×1.35), здоровье ×1.45, быстрее, энергия медленнее, меньше добычи')]][CFG.diff][0];
    const dr=document.createElement('div');dr.className='srow';dr.style.cssText='font-size:.85em;opacity:.85';dr.textContent=L(dd);body.appendChild(dr);
    toggle(L('Подсказки управления'),'hints');toggle(L('Цифры урона'),'dmgnum');
    toggle(L('Пауза при сворачивании'),'autopause');toggle(L('Вибрация'),'vibr',()=>vib(40));
    const rs=document.createElement('button');rs.className='sw';rs.textContent=L('Сбросить');rs.onclick=()=>{G.cleared={};G.killed={};saveProg();sfx('click');settingsPanel('game')};row(L('Прогресс коллекции'),rs);
  }else{
    if(isTouch){
      slider(L('Размер кнопок'),'touchSize',70,140,5,pct,applyTouch);
      slider(L('Прозрачность кнопок'),'touchOp',20,100,5,pct,applyTouch);
      toggle(L('Левша (кнопки зеркально)'),'lefty',applyTouch);
    }
    ACT.forEach(([a,t])=>{
      const b=document.createElement('button');b.className='sw';b.style.minWidth='110px';
      b.textContent=rebind&&rebind.a===a?L('нажмите клавишу…'):CFG.binds[a].map(keyName).join(' / ');
      b.onclick=()=>{rebind={a,b};sfx('click');b.textContent=L('нажмите клавишу…')};row(t,b);
    });
    const r=document.createElement('button');r.className='sw';r.textContent=L('Сбросить');r.onclick=()=>{CFG.binds=JSON.parse(JSON.stringify(DEFBIND));saveCfg();sfx('click');settingsPanel('ctl')};row(L('Клавиши по умолчанию'),r);
  }
  const bk=document.createElement('button');bk.className='btn green';bk.textContent=L('Назад');bk.onclick=()=>{rebind=null;sfx('click');settingsPanel.back()};box.appendChild(bk);
  $('panel').style.display='flex';
}
function applyTouch(){
  const t=$('touch');t.style.setProperty('--ts',CFG.touchSize/100);t.style.setProperty('--to',CFG.touchOp/100);t.classList.toggle('lefty',CFG.lefty);
  $('tdash').style.display='none';
}
function applyLang(){
  document.documentElement.lang=CFG.lang;
  const names=[[L('Играть'),'play'],[L('Настройки'),'set'],[L('Коллекция'),'col'],[L('Выход'),'exit']];
  document.querySelectorAll('#menu .hot span').forEach((s,i)=>{s.textContent=L(names[i][0])});
  $('rot').textContent=L('Поверните телефон горизонтально, чтобы играть');
  $('pauseBtn').setAttribute('aria-label',L('Пауза'));
  const lb=$('langBtn');if(lb)lb.textContent=CFG.lang==='ru'?'RU · EN':'EN · RU';
}

