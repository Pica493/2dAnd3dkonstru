'use strict';
/* ---------- world props & pits ---------- */
function drawProps(c0,c1){
  if(!LV.props)return;
  for(const o of LV.props){
    if(o.x<c0-60||o.x>c1+60)continue;
    if(o.t==='col'){
      const gr=ctx.createLinearGradient(o.x-24,0,o.x+24,0);gr.addColorStop(0,'#4a463e');gr.addColorStop(.5,'#6a6558');gr.addColorStop(1,'#3a362f');
      ctx.fillStyle=gr;ctx.fillRect(o.x-24,0,48,GY);
      ctx.fillStyle='#2e2a24';ctx.fillRect(o.x-30,GY-14,60,14);ctx.fillRect(o.x-30,0,60,16);
      ctx.fillStyle='rgba(120,60,30,.35)';ctx.fillRect(o.x-18,40,6,GY-60);ctx.fillRect(o.x+8,90,5,GY-140);
      ctx.fillStyle='#c0392b';ctx.beginPath();ctx.arc(o.x,170,17,0,7);ctx.fill();ctx.fillStyle='#fbeec1';ctx.font='bold 21px Trebuchet MS,sans-serif';ctx.textAlign='center';ctx.fillText('M',o.x,178);
      ctx.strokeStyle='#2f7a3a';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(o.x-14,16);ctx.quadraticCurveTo(o.x-20,150,o.x-12,300);ctx.moveTo(o.x+10,16);ctx.quadraticCurveTo(o.x+16,90,o.x+8,200);ctx.stroke();
    }else if(o.t==='bench'){
      ctx.fillStyle='#4a3420';ctx.fillRect(o.x-36,GY-26,72,6);ctx.fillRect(o.x-36,GY-48,72,5);ctx.fillRect(o.x-32,GY-26,5,26);ctx.fillRect(o.x+27,GY-26,5,26);
      ctx.fillStyle='#6a4a2a';ctx.fillRect(o.x-36,GY-26,72,2);
    }else if(o.t==='crate'){
      ctx.fillStyle='#6b4a28';ctx.fillRect(o.x-22,GY-44,44,44);ctx.strokeStyle='#3a2410';ctx.lineWidth=3;ctx.strokeRect(o.x-22,GY-44,44,44);
      ctx.beginPath();ctx.moveTo(o.x-22,GY-44);ctx.lineTo(o.x+22,GY);ctx.moveTo(o.x+22,GY-44);ctx.lineTo(o.x-22,GY);ctx.stroke();
      ctx.fillStyle='#8a5a30';ctx.fillRect(o.x+26,GY-30,24,30);ctx.strokeRect(o.x+26,GY-30,24,30);
    }else if(o.t==='lamp'){
      ctx.strokeStyle='#2a2622';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(o.x,0);ctx.lineTo(o.x,o.y);ctx.stroke();
      ctx.fillStyle='#3a342c';ctx.beginPath();ctx.moveTo(o.x-12,o.y+14);ctx.lineTo(o.x-6,o.y);ctx.lineTo(o.x+6,o.y);ctx.lineTo(o.x+12,o.y+14);ctx.fill();
      const fl=.85+.15*Math.sin(G.time*9+o.x);
      ctx.fillStyle='#ffd27a';ctx.beginPath();ctx.ellipse(o.x,o.y+14,10,4,0,0,7);ctx.fill();
      ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.6*fl;ctx.drawImage(GL.orange,o.x-90,o.y-70,180,180);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
    }
  }
}

/* ---------- animation poses ---------- */
function floorBelow(x,y){let best=null;for(const s of LV.solids){if(x>s.x&&x<s.x+s.w&&s.y>=y-4&&(best===null||s.y<best))best=s.y}return best}
function drawShadow(x,fy,w,a){
  if(!Qe.shadows)return;const gy=floorBelow(x,fy);if(gy===null)return;
  const h=Math.max(0,gy-fy),k=1-Math.min(1,h/260);
  ctx.globalAlpha=.55*a*k;ctx.drawImage(GL.shadow,x-w*(.5+h/700),gy-4,w*(1+h/350),10);ctx.globalAlpha=1;
}

