'use strict';
/* ---------- quality & gfx assets ---------- */
let K=1,Qe={},autoTier=isTouch?'med':'high';
const QP={
  low:{pm:.35,dpr:1,flies:12,fg:false,rays:false,glow:false,shadows:false,mist:false,leaves:0,mid:false},
  med:{pm:.7,dpr:1.5,flies:34,fg:true,rays:true,glow:true,shadows:true,mist:false,leaves:10,mid:true},
  high:{pm:1,dpr:2,flies:70,fg:true,rays:true,glow:true,shadows:true,mist:true,leaves:22,mid:true}
};
function applyQuality(){
  const t=CFG.quality==='auto'?autoTier:CFG.quality,b=QP[t]||QP.med;
  Qe={tier:t,pm:b.pm*CFG.part/100,dpr:Math.min(b.dpr,window.devicePixelRatio||1)*CFG.res/100,flies:CFG.flies?b.flies:0,
    fg:b.fg&&CFG.fg,rays:b.rays&&CFG.rays,glow:b.glow&&CFG.glow,shadows:b.shadows&&CFG.shadows,mist:b.mist&&CFG.mist,leaves:b.leaves,mid:b.mid};
  layout();
}
const GL={},IMGV={};
function mkCanvas(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return c}
function mkGlow(rgb,size){
  const c=mkCanvas(size,size),g=c.getContext('2d'),r=size/2,gr=g.createRadialGradient(r,r,0,r,r,r);
  gr.addColorStop(0,'rgba('+rgb+',1)');gr.addColorStop(.3,'rgba('+rgb+',.5)');gr.addColorStop(.65,'rgba('+rgb+',.14)');gr.addColorStop(1,'rgba('+rgb+',0)');
  g.fillStyle=gr;g.fillRect(0,0,size,size);return c;
}
function initGfx(){
  initHero();
  GL.yellow=mkGlow('255,240,130',96);GL.green=mkGlow('150,255,90',96);GL.orange=mkGlow('255,170,60',96);
  GL.red=mkGlow('255,70,50',96);GL.white=mkGlow('255,255,255',96);GL.blue=mkGlow('120,210,255',96);GL.mist=mkGlow('225,240,235',128);
  let c=mkCanvas(128,32),g=c.getContext('2d');g.scale(1,.25);const gr=g.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,'rgba(0,0,0,.85)');gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);GL.shadow=c;
  c=mkCanvas(W,H);g=c.getContext('2d');let v=g.createRadialGradient(W/2,H/2,H*.5,W/2,H/2,H*1.05);v.addColorStop(0,'rgba(0,18,6,0)');v.addColorStop(1,'rgba(0,18,6,.6)');g.fillStyle=v;g.fillRect(0,0,W,H);GL.vig=c;
  c=mkCanvas(W,H);g=c.getContext('2d');v=g.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.95);v.addColorStop(0,'rgba(230,30,30,0)');v.addColorStop(1,'rgba(230,30,30,.95)');g.fillStyle=v;g.fillRect(0,0,W,H);GL.hurt=c;
  c=mkCanvas(360,H);g=c.getContext('2d');v=g.createLinearGradient(0,0,170,H);v.addColorStop(0,'rgba(255,244,180,.2)');v.addColorStop(1,'rgba(255,244,180,0)');
  g.fillStyle=v;g.beginPath();g.moveTo(0,0);g.lineTo(90,0);g.lineTo(330,H);g.lineTo(170,H);g.fill();GL.ray=c;
  const DEFS={
    hero:[[{n:'legL',x0:.20,y0:.60,x1:.56,y1:1,px:.38,py:.62,g:'back'},{n:'legR',x0:.46,y0:.60,x1:.84,y1:1,px:.62,py:.62,g:'back'},{n:'head',x0:.04,y0:0,x1:.96,y1:.40,px:.5,py:.38,g:'front'}],.5,.62],
    beetle:[[{n:'antL',x0:.36,y0:0,x1:.52,y1:.2,px:.47,py:.19,g:'back'},{n:'antR',x0:.52,y0:0,x1:.68,y1:.2,px:.56,py:.19,g:'back'},{n:'armL',x0:0,y0:.12,x1:.31,y1:.62,px:.3,py:.4,g:'back'},{n:'armR',x0:.69,y0:.12,x1:1,y1:.62,px:.7,py:.4,g:'back'},{n:'legL',x0:.27,y0:.56,x1:.53,y1:1,px:.4,py:.58,g:'back'},{n:'legR',x0:.47,y0:.56,x1:.73,y1:1,px:.6,py:.58,g:'back'}],.5,.6],
    fly:[[{n:'legL',x0:0,y0:.44,x1:.26,y1:1,px:.25,py:.47,g:'back'},{n:'legR',x0:.62,y0:.54,x1:1,y1:1,px:.64,py:.62,g:'back'},{n:'head',x0:.46,y0:.05,x1:.84,y1:.64,px:.5,py:.4,g:'front'}],.45,.7],
    golem:[[{n:'legL',x0:.10,y0:.53,x1:.52,y1:1,px:.38,py:.55,g:'back',m:10,ks:'t',ki:16},{n:'legR',x0:.48,y0:.53,x1:.90,y1:1,px:.62,py:.55,g:'back',m:10,ks:'t',ki:16},{n:'vineL',x0:0,y0:0,x1:.34,y1:.31,px:.33,py:.12,g:'front',m:10,ks:'r',ki:12},{n:'vineR',x0:.66,y0:0,x1:1,y1:.31,px:.67,py:.12,g:'front',m:10,ks:'l',ki:12},{n:'armL',x0:0,y0:.31,x1:.30,y1:.72,px:.28,py:.34,g:'front',m:10,ks:'r',ki:16},{n:'armR',x0:.70,y0:.31,x1:1,y1:.72,px:.72,py:.34,g:'front',m:10,ks:'l',ki:16},{n:'lotus',x0:.27,y0:.06,x1:.65,y1:.31,px:.46,py:.30,g:'front',m:10,ks:'b',ki:10}],.5,.55],
    drone:[[{n:'rotor',x0:0,y0:0,x1:1,y1:.17,px:.5,py:.13,g:'front'}],.5,.6],
    rat:[[{n:'legsB',x0:0,y0:.5,x1:.46,y1:1,px:.3,py:.5,g:'back'},{n:'legsF',x0:.46,y0:.5,x1:.86,y1:1,px:.62,py:.5,g:'back'},{n:'head',x0:.55,y0:.05,x1:1,y1:.58,px:.58,py:.42,g:'front'}],.45,.6],
    spider:[[{n:'legL',x0:0,y0:.45,x1:.4,y1:1,px:.36,py:.5,g:'back'},{n:'legR',x0:.6,y0:.45,x1:1,y1:1,px:.64,py:.5,g:'back'}],.5,.55],
    spit:[[{n:'head',x0:.42,y0:0,x1:1,y1:.72,px:.5,py:.55,g:'front'}],.45,.7]
  };
  const LIMS={beetle:{armL:[1.6,14],armR:[1.6,14],legL:[.2,9],legR:[.2,9],antL:[.25,2],antR:[.25,2]},golem:{armL:[.5,6],armR:[.5,6],vineL:[.3,3],vineR:[.3,3],legL:[.2,5],legR:[.2,5],lotus:[.3,6]},fly:{head:[.35,4],legL:[.3,4],legR:[.3,4]},rat:{head:[.2,4],legsF:[.5,5],legsB:[.5,5]},spider:{legL:[.3,6],legR:[.3,6]},spit:{head:[.5,4]},hero:{legL:[.2,5],legR:[.2,5],head:[.12,3]}};
  const mk=(name,base,img)=>{const d=DEFS[base];IMGV[name]=img;RIG[name]=makeRig(img,d[0],d[1],d[2]);const L=LIMS[base]||{};for(const n in RIG[name].parts){const q=L[n];if(q){RIG[name].parts[n].lim=q[0];RIG[name].parts[n].limY=q[1]}}};
  for(const k in DEFS)mk(k,k,IMG[k]);
  mk('heroW','hero',IMG.heroW);
  ICM=ICMAP;
}
/* skeletal rigs built from slices of the concept sprites */
const RIG={};
function makeRig(img,defs,bpx,bpy){
  const w=img.width,h=img.height,m0=8;
  const base=mkCanvas(w,h);base.getContext('2d').drawImage(img,0,0);
  const rig={w,h,base,parts:{},back:[],front:[],bpx:bpx*w,bpy:bpy*h};
  for(const d of defs){
    const m=d.m!==undefined?d.m:m0;
    const x0=Math.max(0,Math.floor(d.x0*w)-m),y0=Math.max(0,Math.floor(d.y0*h)-m),x1=Math.min(w,Math.ceil(d.x1*w)+m),y1=Math.min(h,Math.ceil(d.y1*h)+m);
    const c=mkCanvas(x1-x0,y1-y0),g=c.getContext('2d');g.drawImage(img,x0,y0,x1-x0,y1-y0,0,0,x1-x0,y1-y0);
    if(d.tint){g.globalCompositeOperation='source-atop';g.fillStyle='rgba(10,18,8,'+d.tint+')';g.fillRect(0,0,c.width,c.height)}
    rig.parts[d.n]={c,x:x0,y:y0,px:d.px*w,py:d.py*h,lim:.16,limY:4};
    (d.g==='front'?rig.front:rig.back).push(d.n);
  }
  const bg=base.getContext('2d');
  for(const d of defs)if(d.clear!==false){
    let X0=Math.floor(d.x0*w),Y0=Math.floor(d.y0*h),X1=Math.ceil(d.x1*w),Y1=Math.ceil(d.y1*h);const ks=d.ks||'',ki=d.ki||0;
    if(ks.indexOf('r')>=0)X1-=ki;if(ks.indexOf('l')>=0)X0+=ki;if(ks.indexOf('t')>=0)Y0+=ki;if(ks.indexOf('b')>=0)Y1-=ki;
    bg.clearRect(X0,Y0,X1-X0+1,Y1-Y0+1);
  }
  return rig;
}
function drawRig(g,rig,cx,by,scale,flip,xf){
  const iv=1/scale;
  g.save();g.translate(cx,by);g.scale(flip*scale,scale);g.translate(-rig.w/2,-rig.h);
  const R=xf.root;
  if(R){
    g.translate((R.x||0)*iv,(R.y||0)*iv);
    if(R.sx||R.sy){g.translate(rig.w/2,rig.h);g.scale(R.sx||1,R.sy||1);g.translate(-rig.w/2,-rig.h)}
    if(R.r){const py=(R.rp===undefined?1:R.rp)*rig.h;g.translate(rig.w/2,py);g.rotate(R.r);g.translate(-rig.w/2,-py)}
  }
  const part=n=>{
    const p=rig.parts[n],t=xf[n]||null;g.save();
    g.translate(p.px+(t&&t.x?t.x*iv:0),p.py+(t&&t.y?Math.max(-p.limY,Math.min(p.limY,t.y))*iv:0));
    if(t&&t.r)g.rotate(Math.max(-p.lim,Math.min(p.lim,t.r)));if(t&&(t.sx||t.sy))g.scale(t.sx||1,t.sy||1);
    g.drawImage(p.c,p.x-p.px,p.y-p.py);g.restore();
  };
  for(const n of rig.back)part(n);
  g.save();
  const B=xf.body;
  if(B){g.translate(rig.bpx+(B.x||0)*iv,rig.bpy+(B.y||0)*iv);if(B.r)g.rotate(B.r);if(B.sx||B.sy)g.scale(B.sx||1,B.sy||1);g.translate(-rig.bpx,-rig.bpy)}
  g.drawImage(rig.base,0,0);
  for(const n of rig.front)part(n);
  g.restore();g.restore();
}
function mkBuf(w,h){const c=mkCanvas(Math.ceil(w*K),Math.ceil(h*K));return {c,g:c.getContext('2d'),w,h}}
let BUFS=null;
function drawBuffered(B,x,y,alpha,flash,fn,fc){
  const g=B.g;g.setTransform(K,0,0,K,0,0);g.clearRect(0,0,B.w,B.h);fn(g,B.w/2,B.h-12);
  if(flash>0){g.globalCompositeOperation='source-atop';g.fillStyle='rgba('+(fc||'255,255,255')+','+flash+')';g.fillRect(0,0,B.w,B.h);g.globalCompositeOperation='source-over'}
  ctx.globalAlpha=alpha;ctx.drawImage(B.c,x-B.w/2,y-(B.h-12),B.w,B.h);ctx.globalAlpha=1;
}
/* layers rendered once per level */
function makeMid(theme){if(theme==='metro')theme='dark';
  const c=mkCanvas(1800,H),g=c.getContext('2d'),r=rng(33);
  const col=theme==='dark'?'#07100e':theme==='glass'?'#6fa896':theme==='swamp'?'#17300f':theme==='core'?'#2a0c0c':'#1d4a22',rim=theme==='dark'?'#1e4a3a':theme==='glass'?'#c6f2e0':theme==='swamp'?'#6a9a2a':theme==='core'?'#ff5a3a':'#4f9a2e';
  for(let i=0;i<46;i++){
    const x=r()*1800,rad=34+r()*80,y=H+14-r()*30;
    for(const dx of [0,-1800,1800]){
      g.globalAlpha=.55;g.fillStyle=col;g.beginPath();g.ellipse(x+dx,y,rad*1.5,rad*.75,0,Math.PI,0);g.fill();
      g.globalAlpha=.4;g.strokeStyle=rim;g.lineWidth=2.5;g.beginPath();g.ellipse(x+dx,y,rad*1.5,rad*.75,0,Math.PI*1.1,Math.PI*1.9);g.stroke();
    }
  }
  g.globalAlpha=1;return c;
}
function makeVines(theme){
  if(theme==='metro')theme='dark';
  const c=mkCanvas(1800,H),g=c.getContext('2d'),r=rng(34);
  const col=theme==='dark'?'#07100e':theme==='glass'?'#6fa896':theme==='swamp'?'#17300f':theme==='core'?'#2a0c0c':'#1d4a22';
  for(let i=0;i<34;i++){
    const x=r()*1800,len=50+r()*170;
    for(const dx of [0,-1800,1800]){
      g.globalAlpha=.5;g.strokeStyle=col;g.lineWidth=3+r()*2;g.beginPath();g.moveTo(x+dx,-4);g.quadraticCurveTo(x+dx+(r()-.5)*30,len*.5,x+dx+(r()-.5)*20,len);g.stroke();
      for(let y=14;y<len;y+=17)leaf(g,x+dx,y,15,5,(y/17|0)%2?.4:Math.PI-.4,col);
    }
  }
  g.globalAlpha=1;return c;
}
function makeFG(theme){if(theme==='metro')theme='dark';
  const c=mkCanvas(2400,H),g=c.getContext('2d'),r=rng(91);
  const cols=theme==='dark'?['#040b09','#0b1a14']:theme==='glass'?['#3f7d6c','#5aa38a']:['#0e3a14','#1a5a1c','#2a7a22'];
  g.shadowBlur=22;
  for(let i=0;i<16;i++){
    const x=r()*2400,bot=r()<.5,side=bot?H+8:-8,sz=bot?44+r()*52:56+r()*70,col=cols[(r()*cols.length)|0];
    g.shadowColor=col;g.fillStyle=col;
    for(const dx of [0,-2400,2400]){
      for(let k=0;k<3;k++){const a=(side>0?-Math.PI/2:Math.PI/2)+(k-1)*.6+(r()-.5)*.2;leaf(g,x+dx,side,sz,sz*.26,a,col)}
    }
  }
  g.shadowBlur=0;return c;
}
function buildLayers(theme){
  LV.mid=makeMid(theme);LV.vines=makeVines(theme);LV.fg=makeFG(theme);
}

